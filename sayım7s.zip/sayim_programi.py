#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
HASTANE ENVANTER SAYIM SİSTEMİ  (sayim_programi.py)
====================================================

MİMARİ ÖZET
-----------
  Android telefon (Chrome, mobil veri)
        |  https (Cloudflare Tunnel adresi)
        v
  Cloudflare  <--- cloudflared.exe (hastane bilgisayarından DIŞARIYA bağlanır, port açılmaz)
        |
        v
  Flask sunucusu (127.0.0.1:PORT, bu program içinde)
        |
        v
  Sayim.xlsx + Fotograflar/ + kayitlar.jsonl (ana kayıt) + Yedek/

  * Masaüstü yönetim arayüzü (tkinter) yalnızca bu bilgisayarda çalışır, internete açılmaz.
  * Sürüm 2: arama/süzgeç/sıralama, istatistik kartları, fotoğraf önizleme, CSV/yedek, Excel'de Özet sayfası,
    telefonda canlı tekrar kontrolü ve "Son kayıtlarım" listesi, zaman damgalı döner yedekler.
  * Sürüm 9: sabit adresli (named) Cloudflare tüneli, Cloudflare Access desteği, genel kilidin herkesi dışarıda bırakmasının
    önlenmesi (tanıdık cihaz çerezi), Excel yazımı write_only kipiyle ~11 kat hızlı, 'Tüm Kayıtlar' sunucu tarafı süzme/sayfalama.
  * Sürüm 8: kayitlar.jsonl'da yarım kalan son satırın sonraki kaydı yutmasının önlenmesi, silme/ekleme yazma hatasında
    fotoğraf ve silinenler tutarlılığı, Durdur->Başlat tünel yarışı (sahipsiz cloudflared), Türkçe İ/ı ile kullanıcı listesi,
    QR izinli site yazımı ve DNS rebinding sertleştirmesi, fotoğraf piksel sınırı, harfli PIN klavyesi, zayıf PIN uyarısı,
    eski cloudflared uyarısı, isteğe bağlı ikinci yedek klasörü (USB/ağ).
  * Sürüm 7: hatalı-giriş sınırlayıcıya zaman penceresi (eski hatalar düşer), QR adresi çekerken yerel/özel ağ adreslerine
    bağlanmayı engelleme, telefonun yeniden girişte "Son kayıtlarım/BENİM" kayıtlarını kaybetmemesi, telefonda okutma
    zamanının saklanması, silinen kaydı geri getirme penceresi, Ayarlar'da QR siteleri/künye şablonu, Özet'te Türkçe
    büyük/küçük harf birleştirme, büyük listelerde tablo yenileme sıklığının azaltılması, yazma hatasında geri alma.
  * Telefon formu tek sayfadır; internet kesilirse kayıtlar telefonda (IndexedDB) bekler
    ve bağlantı gelince otomatik gönderilir.

KURULUM
-------
  pip install flask openpyxl pillow qrcode
  (isteğe bağlı, fotoğraftan okuma için: pip install opencv-python-headless pytesseract;
   etiket yazısını okumak için ayrıca Tesseract OCR programı: https://github.com/UB-Mannheim/tesseract/wiki)
  (isteğe bağlı, 'Künye Eşleştir' ile eski .xls listeleri okumak için: pip install xlrd)
  cloudflared (tünel aracı) PROGRAMA GÖMÜLÜDÜR: cloudflared_gomulu.py dosyası bu programla AYNI klasörde
  durmalıdır; ilk "Sistemi Başlat"ta arac\\cloudflared.exe olarak otomatik çıkarılır, ayrıca dosya koymak gerekmez.
  Başka sürüm kullanmak için üstteki "Tünel Aracı" düğmesinden dosya seçin
  (indirme: https://github.com/cloudflare/cloudflared/releases/latest  ->  cloudflared-windows-amd64.exe).

ÇALIŞTIRMA
----------
  python sayim_programi.py
  "Sistemi Başlat" düğmesine basın -> ekranda https adresi ve QR kod çıkar.
  Telefonla QR'ı okutun, adı soyadı ve ekrandaki Sayım PIN'i ile giriş yapın.

CİHAZ ÜZERİNDEKİ QR / KÜNYE ETİKETİ (sürüm 3)
--------------------------------------------
  Formda "📷 QR Oku" -> cihazdaki QR okutulur -> künye no, seri no (S/N), marka, model ve cihaz adı
  otomatik dolar. QR bir web adresiyse sayfa bu bilgisayardan açılıp tablo okunur (Künye No, S/N, Marka, Model,
  Tanım). Adres yalnızca belirli sitelerle sınırlanmak istenirse ayarlar.json içinde
  "qr_izinli_siteler": "alanadi.gov.tr, baska.gov.tr" yazın.
  Fotoğraf çekilince etiketteki QR otomatik okunur (önce telefon, olmazsa bilgisayar); QR okunamazsa ve Tesseract kuruluysa
  etiketteki künye no yazıdan okunup künye sayfasından (ayarlar.json: "qr_sayfa_sablonu") bilgiler tamamlanır.

TEK .EXE YAPMA
--------------
  pip install pyinstaller
  pyinstaller --onefile --noconsole --hidden-import cloudflared_gomulu --name SayimProgrami sayim_programi.py
  (cloudflared_gomulu.py aynı klasörde iken derleyin; tünel aracı .exe'nin içine girer.)
"""

import io
import os
import copy
import csv
import re
import lzma
import base64
import tempfile
import importlib.util
import sys
import json
import time
import uuid
import hmac
import shutil
import socket
import secrets
import hashlib
import logging
import http.client
import ipaddress
import threading
import subprocess
import unicodedata
import webbrowser
import urllib.error
import urllib.parse
import urllib.request
from html.parser import HTMLParser
from collections import Counter
from datetime import datetime
from logging.handlers import RotatingFileHandler

import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from tkinter import font as tkfont

try:
    from flask import Flask, request, session, jsonify, Response, send_file
    from itsdangerous import URLSafeTimedSerializer
    from werkzeug.serving import make_server
    from openpyxl import Workbook, load_workbook
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    from openpyxl.utils import get_column_letter
    from openpyxl.cell import WriteOnlyCell
    from PIL import Image, ImageOps, ImageDraw
    import qrcode
except ImportError as _hata:
    # Çift tıklayınca pencere sessizce kapanmasın: eksik kütüphaneyi ekranda göster
    _mesaj = ("Eksik kütüphane: %s\n\nÇözüm: Komut İstemi'ni (cmd) açıp şunu çalıştırın:\n\n"
              "py -m pip install flask openpyxl pillow qrcode\n\nSonra programı yeniden açın." % _hata)
    try:
        with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "baslangic_hatasi.txt"), "w", encoding="utf-8") as _f:
            _f.write(_mesaj)
    except Exception:
        pass
    try:
        _kok = tk.Tk()
        _kok.withdraw()
        messagebox.showerror("Sayım Programı – Eksik kütüphane", _mesaj)
    except Exception:
        print(_mesaj)
        input("Kapatmak için Enter'a basın...")
    sys.exit(1)

try:    # isteğe bağlı: fotoğraftan QR okuma (OpenCV) ve yazı okuma (Tesseract)
    import cv2
    import numpy as np
except Exception:
    cv2 = np = None
try:
    import pytesseract
except Exception:
    pytesseract = None

try:
    from PIL import ImageTk
except Exception:  # bazı sistemlerde ImageTk yoktur; QR görseli gösterilemez ama program çalışır
    ImageTk = None

# ----------------------------------------------------------------------------
# GENEL AYARLAR VE LOG
# ----------------------------------------------------------------------------
BASE_DIR = os.path.dirname(os.path.abspath(sys.executable if getattr(sys, "frozen", False) else __file__))
AYAR_YOLU = os.path.join(BASE_DIR, "ayarlar.json")
LOG_YOLU = os.path.join(BASE_DIR, "sayim_log.txt")
ARAC_KLASORU = os.path.join(BASE_DIR, "arac")
GOMULU_MODUL = "cloudflared_gomulu"
GOMULU_BOYUT = 38058632
GOMULU_SHA256 = "988758588a6fc8706aa26f5b34ee41c5902175f874998a93c1c954d8aabfecba"
GOMULU_SURUM = "2022.3.0"      # cloudflared_gomulu.py içindeki sürüm (cloudflared.exe --version ile doğrulandı)
CF_INDIR_SAYFA = "https://github.com/cloudflare/cloudflared/releases/latest"
CF_INDIR_64 = "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-windows-amd64.exe"
CF_INDIR_32 = "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-windows-386.exe"
MAX_FOTO = 10 * 1024 * 1024  # 10 MB
MAX_PIKSEL = 60_000_000      # bundan büyük çözünürlüklü resim bellekte açılmaz (telefon zaten 1280 px'e küçültüp yollar)

log = logging.getLogger("sayim")


def log_kur():
    log.setLevel(logging.INFO)
    if not log.handlers:
        h = RotatingFileHandler(LOG_YOLU, maxBytes=1_000_000, backupCount=3, encoding="utf-8")
        h.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
        log.addHandler(h)
    logging.getLogger("werkzeug").setLevel(logging.WARNING)


FOTO_MODLARI = ("sor", "serbest", "zorunlu")
AYAR_NOTU = ""   # ayar_yukle bir düzeltme yaptıysa arayüzde kısa not olarak gösterilir

VARSAYILAN_AYAR = {
    "kayit_klasoru": os.path.join(BASE_DIR, "SayimVerileri"),
    "port": 5000,
    "pin": None,
    "kullanicilar": "",          # boşsa herkes ad yazarak girer; doluysa ad bu listede olmalı (virgülle ayırın)
    "yerel_ag": False,           # True: aynı Wi-Fi'daki telefonlar da bilgisayarın IP'sinden erişebilir
    "tunel_protokol": "auto",    # auto / http2 / quic (ağ engelliyorsa http2 deneyin)
    "foto_modu": "sor",          # sor: fotoğrafsız kayıtta sorar / serbest: sormaz / zorunlu: fotoğrafsız kayıt yapılamaz
    "gizli_anahtar": None,
    "qr_sayfa_sablonu": "http://sbu2.saglik.gov.tr/QR/QR.aspx?kno={kunye}",   # yalnızca künye no bilinen durumlarda (fotoğraf yazısı, düz barkod) bilgi sayfası
    "cloudflared_kaynak": "gomulu",   # gomulu: programın içindeki sürüm / ozel: kullanıcının seçtiği dosya (aşağıdaki yol)
    "cloudflared_ozel": "",           # "Tünel Aracı" düğmesiyle seçilen dosyanın arac klasörüne kopyalanmış yolu
    "ikinci_yedek_klasoru": "",  # isteğe bağlı: ikinci konuma (USB disk / ağ klasörü) otomatik yedek; boş = kapalı
    "tunel_modu": "gecici",      # gecici: ücretsiz, her açılışta adres değişir / sabit: Cloudflare hesabınızdaki adlandırılmış (named) tünel
    "sabit_tunel_token": "",     # sabit mod: Cloudflare panelinin verdiği tünel anahtarı (eyJ... ile başlar)
    "sabit_adres": "",           # sabit mod: panelde tanımladığınız adres, örn. https://sayim.alanadiniz.com
    "access_zorunlu": False,     # Cloudflare Access kullanıyorsanız: Access'ten geçmeyen tünel isteklerini reddet (ek güvenlik katmanı)
    "qr_izinli_siteler": "",     # QR bir web adresi içeriyorsa sayfa bu bilgisayardan okunur; boşsa her adres, doluysa yalnızca bu alan adları (virgülle)
}


def ayar_yukle():
    global AYAR_NOTU
    ayar = dict(VARSAYILAN_AYAR)
    degisti = False
    try:
        if os.path.exists(AYAR_YOLU):
            with open(AYAR_YOLU, "r", encoding="utf-8-sig") as f:
                ayar.update(json.load(f))
    except Exception as e:
        log.error("Ayar dosyası okunamadı: %s", e)
        try:
            shutil.copy2(AYAR_YOLU, AYAR_YOLU + ".bozuk")   # kullanıcının dosyası sessizce ezilmesin
        except Exception:
            pass
        AYAR_NOTU = "ayarlar.json okunamadı; varsayılan ayarlar kullanıldı (eski dosya: ayarlar.json.bozuk)"
        degisti = True
    if not ayar.get("pin"):
        ayar["pin"] = str(secrets.randbelow(900000) + 100000)
        degisti = True
    if not ayar.get("gizli_anahtar"):
        ayar["gizli_anahtar"] = secrets.token_hex(32)
        degisti = True
    if ayar.get("foto_modu") not in FOTO_MODLARI:
        ayar["foto_modu"] = "sor"
        degisti = True
    if ayar.get("tunel_modu") not in ("gecici", "sabit"):
        ayar["tunel_modu"] = "gecici"
        degisti = True
    # Program başka bir bilgisayara/klasöre taşındıysa eski mutlak yol geçersiz kalır: varsayılana dön
    kk = str(ayar.get("kayit_klasoru") or "")
    if not kk or not os.path.isdir(os.path.dirname(os.path.abspath(kk))):
        eski = kk
        ayar["kayit_klasoru"] = VARSAYILAN_AYAR["kayit_klasoru"]
        log.warning("Kayıt klasörü bulunamadı (%s); varsayılana dönüldü: %s", eski, ayar["kayit_klasoru"])
        if not AYAR_NOTU:
            AYAR_NOTU = "Kayıt klasörü bulunamadı, program klasöründeki SayimVerileri kullanılıyor"
        degisti = True
    if degisti or not os.path.exists(AYAR_YOLU):
        ayar_kaydet(ayar)
    return ayar


def ayar_kaydet(ayar):
    try:
        with open(AYAR_YOLU, "w", encoding="utf-8") as f:
            json.dump(ayar, f, ensure_ascii=False, indent=2)
    except Exception as e:
        log.error("Ayar dosyası yazılamadı: %s", e)
        raise


# ----------------------------------------------------------------------------
# TÜNEL ARACI (cloudflared): gömülü sürüm + isteğe bağlı kullanıcı dosyası
# ----------------------------------------------------------------------------
def sha256_dosya(yol):
    h = hashlib.sha256()
    with open(yol, "rb") as f:
        for blok in iter(lambda: f.read(1024 * 1024), b""):
            h.update(blok)
    return h.hexdigest()


def gomulu_var():
    """Gömülü cloudflared (cloudflared_gomulu.py) bu bilgisayarda kullanılabilir mi? (yalnızca Windows)"""
    if sys.platform != "win32":
        return False
    try:
        return importlib.util.find_spec(GOMULU_MODUL) is not None
    except Exception:
        return False


def arac_klasorleri():
    """Önce program klasöründeki 'arac', yazılamıyorsa geçici klasör."""
    return [ARAC_KLASORU, os.path.join(tempfile.gettempdir(), "SayimProgrami_arac")]


def gomulu_cikar():
    """Gömülü cloudflared'i diske çıkarır; zaten çıkarılmış ve doğruysa dokunmaz. Dönüş: exe yolu ya da None."""
    if not gomulu_var():
        return None
    for klasor in arac_klasorleri():
        hedef = os.path.join(klasor, "cloudflared.exe")
        try:
            if os.path.isfile(hedef) and os.path.getsize(hedef) == GOMULU_BOYUT and sha256_dosya(hedef) == GOMULU_SHA256:
                return hedef
        except OSError:
            pass
    hata = None
    try:
        modul = importlib.import_module(GOMULU_MODUL)
        ham = lzma.decompress(base64.b64decode("".join(str(modul.VERI).split())))
        if len(ham) != GOMULU_BOYUT or hashlib.sha256(ham).hexdigest() != GOMULU_SHA256:
            raise ValueError("Gömülü cloudflared doğrulanamadı (dosya bozuk veya değiştirilmiş)")
        for klasor in arac_klasorleri():
            hedef = os.path.join(klasor, "cloudflared.exe")
            try:
                os.makedirs(klasor, exist_ok=True)
                gecici = hedef + ".yeni"
                with open(gecici, "wb") as f:
                    f.write(ham)
                os.replace(gecici, hedef)
                log.info("Gömülü cloudflared çıkarıldı: %s", hedef)
                return hedef
            except OSError as e:
                hata = e
                log.warning("cloudflared %s klasörüne çıkarılamadı: %s", klasor, e)
    except Exception as e:
        hata = e
        log.error("Gömülü cloudflared çıkarılamadı: %s", e)
    if hata:
        raise RuntimeError(f"Gömülü cloudflared çıkarılamadı: {hata}")
    return None


_TOKEN_RE = re.compile(r"eyJ[A-Za-z0-9+/=_\-]{30,}")
SABIT_BAGLI_RE = re.compile(r"(registered tunnel connection|connection [0-9a-f-]{8,} registered)", re.I)
SABIT_TOKEN_HATA_RE = re.compile(r"(unauthorized|invalid tunnel secret|tunnel token is not valid|failed to unmarshal tunnel token"
                                 r"|tunnel not found|error parsing tunnel)", re.I)
TUNEL_MOD_ADLARI = {"gecici": "Geçici adres (ücretsiz, her açılışta değişir)",
                    "sabit": "Sabit adres (Cloudflare hesabı + alan adı gerekir)"}


def token_ayikla(metin):
    """Cloudflare panelindeki komutun tamamı da yapıştırılabilir; içinden tünel anahtarı (eyJ... ile başlar) ayıklanır."""
    m = _TOKEN_RE.search(str(metin or ""))
    return m.group(0) if m else ""


def sabit_adres_duzelt(a):
    a = str(a or "").strip().rstrip("/")
    if a and not re.match(r"^https?://", a, re.I):
        a = "https://" + a
    return a


def sabit_tunel_hatasi(ayar):
    """Sabit adres ayarı eksik/hatalıysa kullanıcıya gösterilecek açıklama; sorun yoksa boş metin."""
    if not token_ayikla(ayar.get("sabit_tunel_token")):
        return "Sabit adres için Cloudflare tünel anahtarı (token) gerekli. Ayarlar → TÜNEL ADRESİ bölümüne yapıştırın."
    if not re.fullmatch(r"https://[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)+(:\d{1,5})?", sabit_adres_duzelt(ayar.get("sabit_adres"))):
        return "Sabit adres https://alanadi.com biçiminde olmalı (Cloudflare'de tanımladığınız Public hostname)."
    return ""


def surum_ay_farki(surum, simdi=None):
    """cloudflared sürüm adı (YYYY.M.P) bugüne göre kaç ay eski? Okunamazsa None."""
    m = re.match(r"^(\d{4})\.(\d{1,2})\.", str(surum or "") + ".")
    if not m:
        return None
    simdi = simdi or datetime.now()
    return (simdi.year - int(m.group(1))) * 12 + (simdi.month - int(m.group(2)))


def eski_surum_uyarisi(surum, simdi=None, esik_ay=12):
    """Cloudflare yalnızca son sürümden en çok 1 yıl önceki cloudflared sürümlerini destekler; eskiyse uyarı metni döner."""
    ay = surum_ay_farki(surum, simdi)
    if ay is None or ay <= esik_ay:
        return ""
    yas = f"{ay // 12} yıl {ay % 12} ay" if ay >= 12 else f"{ay} ay"
    return (f"Tünel aracı (cloudflared {surum}) yaklaşık {yas} eski; Cloudflare yalnızca son 1 yıl içindeki sürümleri "
            "destekler. “☁ Tünel Aracı” düğmesinden güncel (64 bit) sürümü seçmeniz önerilir.")


def cloudflared_surum(yol, zaman_asimi=12):
    """cloudflared --version çalıştırır. Dönüş: (sürüm ya da None, açıklama)."""
    try:
        r = subprocess.run([yol, "--version"], capture_output=True, text=True, encoding="utf-8", errors="replace",
                           timeout=zaman_asimi, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        metin = ((r.stdout or "") + " " + (r.stderr or "")).strip()
        m = re.search(r"cloudflared version\s+(\S+)", metin)
        if m and r.returncode == 0:
            return m.group(1), metin.splitlines()[0][:200]
        return None, (metin or f"çıkış kodu {r.returncode}")[:200]
    except Exception as e:
        return None, str(e)[:200]


# ----------------------------------------------------------------------------
# YARDIMCI FONKSİYONLAR
# ----------------------------------------------------------------------------
def temiz(s, n=200):
    """Kontrol karakterlerini temizler, kırpar ve uzunluğu sınırlar."""
    s = re.sub(r"[\x00-\x1f\x7f]", " ", str(s if s is not None else ""))
    return s.strip()[:n]


def guvenli_ad(s):
    """Dosya adı için güvenli (ASCII) metin üretir."""
    s = unicodedata.normalize("NFKD", str(s)).encode("ascii", "ignore").decode("ascii")
    s = re.sub(r"[^A-Za-z0-9_-]+", "_", s).strip("_")[:40]
    return s or "kunyesiz"


def kunye_anahtar(s):
    return str(s or "").strip().upper()


def yerel_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("10.255.255.255", 1))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"


def dosya_ac(yol):
    """Dosya/klasörü işletim sisteminin varsayılan programıyla açar."""
    try:
        if sys.platform == "win32":
            os.startfile(yol)  # noqa
        elif sys.platform == "darwin":
            subprocess.Popen(["open", yol])
        else:
            subprocess.Popen(["xdg-open", yol])
    except Exception as e:
        log.error("Açılamadı %s: %s", yol, e)
        messagebox.showerror("Hata", f"Açılamadı:\n{yol}\n\n{e}")


# ----------------------------------------------------------------------------
# VERİ DEPOSU: kayitlar.jsonl (ana kayıt) + Excel + fotoğraflar + yedek
# ----------------------------------------------------------------------------
BASLIKLAR = ["No", "Tarih-Saat", "Marka", "Model", "Cihaz Adı", "Künye No", "Seri No",
             "Birim/Oda", "Sayımı Yapan", "Fotoğraf", "Tekrar"]
GENISLIKLER = [6, 19, 18, 18, 28, 22, 24, 22, 22, 16, 8]
ALAN_ADLARI = ("marka", "model", "cihaz_adi", "kunye_no", "seri_no", "birim", "sayan")
SARI = PatternFill("solid", fgColor="FFFF99")
BASLIK_DOLGU = PatternFill("solid", fgColor="0B5ED7")
ALT_BASLIK_DOLGU = PatternFill("solid", fgColor="DCE6F7")
INCE = Side(style="thin", color="C8D0DC")


Image.MAX_IMAGE_PIXELS = MAX_PIKSEL


def resim_boyut_denetle(im):
    """Çok yüksek çözünürlüklü resim tamamen açılırsa yüzlerce MB bellek yer; açmadan önce reddedilir."""
    w, h = im.size
    if w * h > MAX_PIKSEL:
        raise ValueError("Fotoğrafın çözünürlüğü çok yüksek")


_ZAYIF_PINLER = {"123456", "1234567", "12345678", "123456789", "1234567890", "654321", "123123", "112233", "121212",
                 "123321", "159753", "696969", "password", "qwerty", "sayim", "hastane", "admin", "parola"}


def pin_zayif_mi(pin):
    """Tahmin edilmesi çok kolay PIN: tek/iki rakamdan oluşan, ardışık (123456, 987654) ya da bilinen listede olan."""
    p = str(pin or "").strip().lower()
    if len(set(p)) <= 2 or p in _ZAYIF_PINLER:
        return True
    if p.isdigit():
        fark = [int(b) - int(a) for a, b in zip(p, p[1:])]
        return all(x == 1 for x in fark) or all(x == -1 for x in fark)
    return False


def csv_guvenli(v):
    """CSV'yi Excel'de açınca '=' ile başlayan hücrelerin formül gibi çalışmasını engeller."""
    v = "" if v is None else str(v)
    return "'" + v if v[:1] in ("=", "+", "-", "@", "\t", "\r") else v


def say_birlestir(kayitlar, alan):
    """Büyük/küçük harf farkını yok sayarak bir alandaki değerleri sayar -> [(ad, adet), ...] çoktan aza."""
    sayac, gorunen = Counter(), {}
    for r in kayitlar:
        ad = str(r.get(alan) or "").strip()
        a = etiket_norm(ad) or ad.upper()      # "ameliyathane" = "AMELİYATHANE" (Türkçe İ/ı farkı gruplamayı bölmesin)
        sayac[a] += 1
        gorunen.setdefault(a, ad)
    return [(gorunen[a] or "(boş)", n) for a, n in sayac.most_common()]


# ----------------------------------------------------------------------------
# KÜNYE EŞLEŞTİRME: sunucuda toplanan künyeleri verilen Excel listesinde bulup yeşile boyar
# ----------------------------------------------------------------------------
ESLESME_YESIL = PatternFill("solid", fgColor="92D050")
ESLESME_UZANTILAR = (".xlsx", ".xlsm", ".xls", ".csv", ".txt")


class XlrdYok(RuntimeError):
    """Eski .xls biçimini okumak için gereken xlrd kütüphanesi kurulu değil."""
    MESAJ = ("Eski .xls biçimini okumak için 'xlrd' kütüphanesi gerekli.\n\n"
             "Komut İstemi'nde şunu çalıştırın:\n    py -m pip install xlrd\n\n"
             "ya da dosyayı .csv / .xlsx olarak kaydedip onu seçin.")

    def __init__(self):
        super().__init__(self.MESAJ)


def xlrd_kur(zaman_asimi=180):
    """xlrd'yi pip ile kurmayı dener (internet gerekir). Döner: (başarılı, açıklama)."""
    if getattr(sys, "frozen", False):
        return False, "Tek .exe sürümünde kurulum yapılamaz; dosyayı .csv veya .xlsx olarak kaydedin."
    try:
        r = subprocess.run([sys.executable, "-m", "pip", "install", "xlrd"], capture_output=True, text=True,
                           timeout=zaman_asimi, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        if r.returncode == 0:
            importlib.invalidate_caches()
            import xlrd  # noqa
            return True, "xlrd kuruldu."
        return False, (r.stderr or r.stdout or "pip hata verdi").strip()[-400:]
    except Exception as e:
        return False, str(e)


def kunye_norm(v):
    """Excel hücresindeki (sayı/metin) ve telefondan gelen künyeyi karşılaştırılabilir metne çevirir.
    1021495470 = '1021495470' = 1021495470.0 = ' 10214 95470 ' ; baştaki sıfırlar yok sayılır."""
    if v is None or isinstance(v, bool):
        return ""
    if isinstance(v, float) and v == int(v):
        v = int(v)
    s = re.sub(r"[\s\u200b-\u200f\u2060\ufeff]+", "", str(v)).upper().lstrip("'`´")   # boşluk, NBSP, görünmez karakter, Excel metin öneki
    if re.fullmatch(r"\d+[.,]0+", s):
        s = re.split(r"[.,]", s)[0]
    return s.lstrip("0") if s.isdigit() else s


def _baslik_bul(satirlar):
    """İlk 20 satırda 'Künye No' başlığını arar -> (satır_no, sütun_no) (1 tabanlı) ya da None."""
    for rn, satir in enumerate(satirlar, 1):
        if rn > 20:
            break
        for cn, v in enumerate(satir, 1):
            if isinstance(v, str):
                h = re.sub(r"[\s\u200b-\u200f\ufeff.:_\-]+", "", tum_arama_norm(v))     # boşluk/NBSP/nokta farkı yok sayılır
                if h in ("kunyeno", "kunye", "kunyenumarasi", "kunyenu") or h.startswith("kunyeno"):
                    return rn, cn
    return None


def _xls_to_workbook(yol):
    """Eski .xls dosyasını (xlrd ile) bellekte yeni bir openpyxl çalışma kitabına çevirir (değerler korunur)."""
    try:
        import xlrd
    except ImportError:
        raise XlrdYok()
    kitap = xlrd.open_workbook(yol, formatting_info=False)
    wb = Workbook()
    wb.remove(wb.active)
    for i in range(kitap.nsheets):
        sh = kitap.sheet_by_index(i)
        ws = wb.create_sheet(re.sub(r"[\[\]\*\?/\\:]", "_", sh.name)[:31] or "Sayfa%d" % (i + 1))
        for r in range(sh.nrows):
            satir = []
            for c in range(sh.ncols):
                hc = sh.cell(r, c)
                t, v = hc.ctype, hc.value
                if t in (xlrd.XL_CELL_EMPTY, xlrd.XL_CELL_BLANK):
                    v = None
                elif t == xlrd.XL_CELL_DATE:
                    try:
                        v = xlrd.xldate.xldate_as_datetime(v, kitap.datemode)
                    except Exception:
                        pass
                elif t == xlrd.XL_CELL_NUMBER and v == int(v):
                    v = int(v)
                elif t == xlrd.XL_CELL_BOOLEAN:
                    v = bool(v)
                elif t == xlrd.XL_CELL_ERROR:
                    v = None
                satir.append(v)
            ws.append(satir)
    return wb


def _metin_oku(yol):
    """CSV/TXT dosyasını kodlamayı kendisi bularak okur (utf-8 / Windows-1254 Türkçe / latin-1)."""
    with open(yol, "rb") as f:
        ham = f.read()
    for kod in ("utf-8-sig", "cp1254", "latin-1"):
        try:
            return ham.decode(kod)
        except UnicodeDecodeError:
            continue
    return ham.decode("latin-1", "replace")


def _ayirac_bul(metin):
    """İlk satırlara bakıp ayırıcıyı (sekme, noktalı virgül, virgül) seçer."""
    ilk = [l for l in metin.splitlines()[:20] if l.strip()]
    en, say = "\t", -1
    for a in ("\t", ";", ","):
        n = sum(l.count(a) for l in ilk)
        if n > say:
            en, say = a, n
    return en


def _csv_to_workbook(yol):
    """CSV/TXT listesini bellekte openpyxl çalışma kitabına çevirir (tam sayı görünümlü hücreler sayı olur)."""
    metin = _metin_oku(yol)
    wb = Workbook()
    ws = wb.active
    ws.title = (re.sub(r"[\[\]\*\?/\\:]", "_", os.path.splitext(os.path.basename(yol))[0])[:31]) or "Liste"
    for satir in csv.reader(io.StringIO(metin), delimiter=_ayirac_bul(metin)):
        yeni = []
        for h in satir:
            h = h.strip()
            if not h:
                yeni.append(None)
            elif re.fullmatch(r"[1-9]\d{0,14}|0", h):
                yeni.append(int(h))
            else:
                yeni.append(h)
        while yeni and yeni[-1] is None:                       # satır sonundaki fazladan ayırıcıları at
            yeni.pop()
        ws.append(yeni)
    return wb


def liste_kunyeleri_oku(yol, ilerleme=None):
    """Dış listedeki (Künye No sütunundaki) tüm künyeleri okur -> normalleşmiş künye kümesi.
    Künye sütunu boş/metin olan (sütunu kaymış) satırlarda sağdaki 6 hücre de kümeye eklenir."""
    def ilr(m):
        if ilerleme:
            ilerleme(m)
    uz = os.path.splitext(yol)[1].lower()
    if uz not in ESLESME_UZANTILAR:
        raise ValueError("Yalnızca .xlsx, .xlsm, .xls veya .csv dosyaları seçilebilir.")
    ilr("Liste okunuyor… (büyük listelerde 1 dakikayı bulabilir)")
    kapat = None
    if uz == ".xls":
        wb = _xls_to_workbook(yol)
    elif uz in (".csv", ".txt"):
        wb = _csv_to_workbook(yol)
    else:
        wb = load_workbook(yol, read_only=True, data_only=True)
        kapat = wb.close
    kume, bulundu = set(), False
    try:
        for ws in wb.worksheets:
            ilr("Taranıyor: %s" % ws.title)
            it = iter(ws.iter_rows(values_only=True))
            ilk = []
            for r in it:
                ilk.append(r)
                if len(ilk) >= 20:
                    break
            b = _baslik_bul(ilk)
            if not b:
                continue
            bulundu = True
            hr, hc = b

            def isle(satir):
                v = satir[hc - 1] if len(satir) >= hc else None
                n = kunye_norm(v)
                if n:
                    kume.add(n)
                if not n.isdigit():
                    for h in satir[hc:hc + 6]:
                        m = kunye_norm(h)
                        if m:
                            kume.add(m)
            for r in ilk[hr:]:
                isle(r)
            for r in it:
                isle(r)
    finally:
        if kapat:
            kapat()
    if not bulundu:
        raise ValueError("Excel'de 'Künye No' başlıklı bir sütun bulunamadı (ilk 20 satıra bakıldı).")
    return kume


def liste_on_kontrol(yol):
    """Seçilen listenin uygun olup olmadığını hızlıca denetler (tüm dosyayı yüklemeden)."""
    uz = os.path.splitext(yol)[1].lower()
    if uz not in ESLESME_UZANTILAR:
        raise ValueError("Yalnızca .xlsx, .xlsm, .xls veya .csv dosyaları seçilebilir.")
    if uz == ".xls":
        try:
            import xlrd  # noqa
        except ImportError:
            raise XlrdYok()
        return True
    if uz in (".csv", ".txt"):
        satirlar = list(csv.reader(io.StringIO("\n".join(_metin_oku(yol).splitlines()[:20])),
                                   delimiter=_ayirac_bul(_metin_oku(yol))))
        if _baslik_bul(satirlar):
            return True
        raise ValueError("Dosyada 'Künye No' başlıklı bir sütun bulunamadı (ilk 20 satıra bakıldı).")
    wb = load_workbook(yol, read_only=True)
    try:
        for ws in wb.worksheets:
            if _baslik_bul(ws.iter_rows(min_row=1, max_row=20, values_only=True)):
                return True
    finally:
        wb.close()
    raise ValueError("Excel'de 'Künye No' başlıklı bir sütun bulunamadı (ilk 20 satıra bakıldı).")


def excel_kunye_isaretle(girdi, cikti, kayitlar, ilerleme=None):
    """`kayitlar` (sunucuda toplanan kayıtlar) içindeki künyeleri `girdi` Excel'indeki 'Künye No' sütununda arar,
    bulduklarının hücresini yeşile boyayıp `cikti` olarak kaydeder. Özgün dosyaya dokunulmaz.
    Döner: {"sayim_kunye", "eslesen", "bulunamayan": [kayit...], "isaretlenen", "sayfalar": [(ad, adet)]}"""
    def ilr(m):
        if ilerleme:
            ilerleme(m)

    girdi_k, cikti_k = os.path.abspath(girdi), os.path.abspath(cikti)
    if os.path.normcase(girdi_k) == os.path.normcase(cikti_k):
        raise ValueError("Çıktı dosyası, özgün Excel ile aynı olamaz.")
    uz = os.path.splitext(girdi)[1].lower()
    if uz not in ESLESME_UZANTILAR:
        raise ValueError("Yalnızca .xlsx, .xlsm, .xls veya .csv dosyaları seçilebilir.")

    sayim = {}                                   # normalleşmiş künye -> ilk kayıt
    for k in kayitlar:
        n = kunye_norm(k.get("kunye_no"))
        if n:
            sayim.setdefault(n, k)
    if not sayim:
        raise ValueError("Sunucuda künye numaralı kayıt yok; eşleştirilecek bir şey bulunamadı.")

    ilr("Excel okunuyor… (büyük listelerde 1-2 dakika sürebilir)")
    if uz == ".xls":
        wb = _xls_to_workbook(girdi)
        uz_cikti = ".xlsx"
    elif uz in (".csv", ".txt"):
        wb = _csv_to_workbook(girdi)
        uz_cikti = ".xlsx"
    else:
        wb = load_workbook(girdi, keep_vba=(uz == ".xlsm"))
        uz_cikti = uz
    if os.path.splitext(cikti)[1].lower() != uz_cikti:
        cikti = os.path.splitext(cikti)[0] + uz_cikti

    bulunan, isaretlenen, sayfalar, kaymis = set(), 0, [], 0
    for ws in wb.worksheets:
        ilr("Taranıyor: %s" % ws.title)
        satirlar = ws.iter_rows(min_row=1, max_row=20, values_only=True)
        b = _baslik_bul(satirlar)
        if not b:
            continue
        hr, hc = b
        adet = 0
        for satir in ws.iter_rows(min_row=hr + 1, min_col=hc, max_col=hc + 6):
            n = kunye_norm(satir[0].value)
            if n and n in sayim:
                satir[0].fill = ESLESME_YESIL
                bulunan.add(n)
                adet += 1
            elif not n.isdigit():
                # Künye sütunu boş/metin: alanında ';' gibi ayırıcı geçen satırlarda sütunlar kayabilir.
                # Sağdaki birkaç hücrede, sunucudaki bir künyeyle birebir aynı değer varsa onu işaretle.
                for h in satir[1:]:
                    m = kunye_norm(h.value)
                    if m and m in sayim:
                        h.fill = ESLESME_YESIL
                        bulunan.add(m)
                        adet += 1
                        kaymis += 1
                        break
        isaretlenen += adet
        sayfalar.append((ws.title, adet))
    if not sayfalar:
        raise ValueError("Excel'de 'Künye No' başlıklı bir sütun bulunamadı (ilk 20 satıra bakıldı).")

    yok = [k for n, k in sayim.items() if n not in bulunan]
    if yok:                                       # özgün sayfalara dokunmadan, bulunamayanları ayrı sayfada ver
        ad = "Listede Bulunamayan"
        ws = wb.create_sheet(ad)
        ws.append(["Künye No", "Cihaz Adı", "Marka", "Model", "Seri No", "Birim/Oda", "Sayımı Yapan"])
        for k in yok:
            ws.append([csv_guvenli(k.get(a)) if a == "kunye_no" else k.get(a) or "" for a in
                       ("kunye_no", "cihaz_adi", "marka", "model", "seri_no", "birim", "sayan")])
        for c in ws[1]:
            c.font = Font(bold=True)
        for i, g in enumerate((18, 34, 18, 18, 22, 22, 22), 1):
            ws.column_dimensions[get_column_letter(i)].width = g
    ilr("Kaydediliyor…")
    wb.save(cikti)
    return {"sayim_kunye": len(sayim), "eslesen": len(bulunan), "bulunamayan": yok,
            "isaretlenen": isaretlenen, "sayfalar": sayfalar, "cikti": cikti, "kaymis": kaymis}


class Depo:
    def __init__(self, klasor, ikinci_yedek=""):
        self.kilit = threading.RLock()
        self.excel_kilit = threading.RLock()
        self.foto_kilit = threading.Lock()
        self.klasor = klasor
        self.foto_klasoru = os.path.join(klasor, "Fotograflar")
        self.yedek_klasoru = os.path.join(klasor, "Yedek")
        self.json_yol = os.path.join(klasor, "kayitlar.jsonl")
        self.excel_yol = os.path.join(klasor, "Sayim.xlsx")
        os.makedirs(self.foto_klasoru, exist_ok=True)
        os.makedirs(self.yedek_klasoru, exist_ok=True)
        self.kayitlar = []
        self._uuidler = set()
        self._kunye_say = Counter()
        self._sonraki_id = 1
        self.versiyon = 0            # her değişiklikte artar; arayüz ve Excel buna bakar
        self.excel_yazilan = -1      # Excel'e en son yazılan versiyon (-1: henüz yazılmadı)
        self.excel_hata = ""
        self._excel_tekrar = 0       # Excel kilitliyse bu zamana kadar yeniden denenmez
        self._son_json_yedek = 0
        self._yedek_versiyon = 0
        self._son_excel_yedek = 0
        self.ikinci_yedek = str(ikinci_yedek or "").strip()   # isteğe bağlı: USB/ağ klasörüne ikinci kopya
        self.ikinci_yedek_hata = ""
        self._ikinci_kilit = threading.Lock()
        self._ikinci_versiyon = -1       # ikinci konuma en son kopyalanan versiyon
        self._ikinci_tekrar = 0          # hata sonrası bu zamana kadar yeniden denenmez
        self._dur = threading.Event()
        self.liste_dosya = os.path.join(klasor, "liste_kunyeleri.json")   # 'Liste Yükle' ile alınan dış listenin künyeleri
        self.liste_kunyeler, self.liste_adi, self.liste_yolu = set(), "", ""
        self._liste_yukle()
        self._yukle()
        self._thread = threading.Thread(target=self._senkron_dongusu, daemon=True)
        self._thread.start()

    # -- dış künye listesi (eşleştirme) ----------------------------------------
    def _liste_yukle(self):
        try:
            with open(self.liste_dosya, encoding="utf-8") as f:
                d = json.load(f)
            self.liste_kunyeler = {str(x) for x in d.get("kunyeler", [])}
            self.liste_adi, self.liste_yolu = str(d.get("ad", "")), str(d.get("yol", ""))
        except FileNotFoundError:
            pass
        except Exception:
            log.exception("liste_kunyeleri.json okunamadı (yok sayıldı)")

    def liste_ayarla(self, ad, yol, kunyeler):
        """Yüklenen dış listenin künyelerini saklar; Excel ve ekran bu listeye göre yeşil işaretler."""
        kume = {str(x) for x in kunyeler if x}
        tmp = self.liste_dosya + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump({"ad": ad, "yol": yol, "kunyeler": sorted(kume)}, f, ensure_ascii=False)
        os.replace(tmp, self.liste_dosya)
        with self.kilit:
            self.liste_kunyeler, self.liste_adi, self.liste_yolu = kume, str(ad), str(yol)
            self.versiyon += 1                   # Excel yeniden yazılsın, ekran yenilensin

    def liste_ozeti(self):
        """(liste yüklü mü, listede eşleşen kayıt sayısı, künyeli kayıt sayısı, liste adı, listedeki künye sayısı)"""
        with self.kilit:
            kume = self.liste_kunyeler
            kunyeli = [kunye_norm(r.get("kunye_no")) for r in self.kayitlar]
            kunyeli = [n for n in kunyeli if n]
            return (bool(kume), sum(1 for n in kunyeli if n in kume), len(kunyeli), self.liste_adi, len(kume))

    @property
    def excel_kirli(self):
        """Excel dosyası en güncel kayıtlardan geride mi? (Sürüm karşılaştırması: yazarken gelen kayıt kaybolmaz.)"""
        return self.excel_yazilan != self.versiyon

    # -- yükleme / kaydetme ---------------------------------------------------
    def _yukle(self):
        bozuk = 0
        if os.path.exists(self.json_yol):
            with open(self.json_yol, "r", encoding="utf-8") as f:
                for no, satir in enumerate(f, 1):
                    satir = satir.strip()
                    if not satir:
                        continue
                    try:
                        k = json.loads(satir)
                        if not isinstance(k, dict):
                            raise ValueError("kayıt nesne değil")
                        for a in ALAN_ADLARI + ("zaman", "foto", "uuid", "oturum"):
                            k.setdefault(a, "")
                        self.kayitlar.append(k)
                    except Exception:
                        bozuk += 1
                        log.error("kayitlar.jsonl %d. satır okunamadı, atlandı", no)
        if bozuk:   # bozuk satır varsa dosyanın ilk halini kaybetmemek için kopyasını sakla
            try:
                shutil.copy2(self.json_yol, os.path.join(
                    self.yedek_klasoru, f"kayitlar_bozuk_{datetime.now():%Y%m%d_%H%M%S}.jsonl"))
            except Exception as e:
                log.warning("Bozuk dosya kopyalanamadı: %s", e)
        mx = max([k["id"] for k in self.kayitlar if isinstance(k.get("id"), int)] + [0])
        for k in self.kayitlar:
            if not isinstance(k.get("id"), int):
                mx += 1
                k["id"] = mx
        self._indeksle()
        self._json_onar(bozuk)

    def _json_onar(self, bozuk):
        """Elektrik kesilmesi gibi nedenlerle son satır yarım kaldıysa (ya da satır sonu eksikse) dosyayı temizler.
        Aksi halde sonraki kayıt yarım satırın sonuna yapışır ve ikisi birden okunamaz hale gelirdi (kayıt kaybı)."""
        try:
            if not os.path.exists(self.json_yol) or os.path.getsize(self.json_yol) == 0:
                return
            if bozuk:
                self._json_hepsini_yaz()          # bozuk satırlar yukarıda yedeklendi; aktif dosya temiz yazılır
                log.warning("kayitlar.jsonl %d bozuk satır nedeniyle yeniden yazıldı", bozuk)
                return
            with open(self.json_yol, "rb") as f:
                f.seek(-1, os.SEEK_END)
                son = f.read(1)
            if son != b"\n":
                with open(self.json_yol, "ab") as f:
                    f.write(b"\n")
                log.warning("kayitlar.jsonl sonuna eksik satır sonu eklendi")
        except OSError as e:
            log.error("kayitlar.jsonl onarılamadı: %s", e)

    def _indeksle(self):
        self._uuidler = {r.get("uuid") for r in self.kayitlar}
        # Künye no zorunlu değil: boş künyeli kayıtlar birbirinin "tekrarı" sayılmaz
        self._kunye_say = Counter(a for a in (kunye_anahtar(r.get("kunye_no")) for r in self.kayitlar) if a)
        # Numara geriye gitmesin: son kayıt silinse bile aynı No yeniden verilmez (silinenler.jsonl ile karışmaz)
        self._sonraki_id = max(self._sonraki_id, max([r.get("id", 0) for r in self.kayitlar] + [0]) + 1)

    def _json_ekle(self, kayit):
        satir = json.dumps(kayit, ensure_ascii=False) + "\n"
        onceki = os.path.getsize(self.json_yol) if os.path.exists(self.json_yol) else 0
        try:
            with open(self.json_yol, "a", encoding="utf-8") as f:
                f.write(satir)
                f.flush()
                os.fsync(f.fileno())
        except Exception:
            # Yazma yarıda kaldıysa (disk dolu vb.) yarım satır dosyada kalmasın; sonraki kayıt ona yapışıp kaybolmasın
            try:
                if os.path.exists(self.json_yol) and os.path.getsize(self.json_yol) > onceki:
                    with open(self.json_yol, "r+b") as f:
                        f.truncate(onceki)
            except OSError as e:
                log.error("Yarım satır geri alınamadı: %s", e)
            raise

    def _json_hepsini_yaz(self):
        tmp = self.json_yol + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            for k in self.kayitlar:
                f.write(json.dumps(k, ensure_ascii=False) + "\n")
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, self.json_yol)

    def kapat(self):
        """Kapanırken: durmamış değişiklikleri yedekle ve Excel'i son kez güncelle."""
        self._dur.set()
        try:
            if self.versiyon != self._yedek_versiyon and os.path.exists(self.json_yol):
                self._json_yedekle(zorla=True)
            self.excel_senkron()
            if self.ikinci_yedek and self._ikinci_versiyon != self.versiyon:
                self.ikinci_yedek_esitle()
        except Exception as e:
            log.warning("Kapanış işlemleri tamamlanamadı: %s", e)

    # -- fotoğraf -------------------------------------------------------------
    def _foto_kaydet(self, dosya, kunye, zaman):
        veri = dosya.read(MAX_FOTO + 1)
        if len(veri) > MAX_FOTO:
            raise ValueError("Fotoğraf 10 MB'tan büyük")
        im = Image.open(io.BytesIO(veri))
        resim_boyut_denetle(im)
        im.verify()
        im = Image.open(io.BytesIO(veri))
        if im.format not in ("JPEG", "PNG", "WEBP"):
            raise ValueError("Desteklenmeyen resim türü")
        im = ImageOps.exif_transpose(im).convert("RGB")
        im.thumbnail((1600, 1600))
        with self.foto_kilit:      # aynı saniyede gelen aynı künyeli iki fotoğraf birbirini ezmesin
            taban = f"{guvenli_ad(kunye)}_{zaman:%Y%m%d_%H%M%S}"
            ad = taban + ".jpg"
            n = 1
            while os.path.exists(os.path.join(self.foto_klasoru, ad)):
                ad = f"{taban}_{n}.jpg"
                n += 1
            im.save(os.path.join(self.foto_klasoru, ad), "JPEG", quality=85, optimize=True)
        return ad

    def _foto_sil(self, ad):
        if ad:
            try:
                os.remove(os.path.join(self.foto_klasoru, ad))
            except OSError:
                pass

    # -- kayıt işlemleri ------------------------------------------------------
    def _uuid_bul(self, u):
        if u not in self._uuidler:
            return None
        for r in self.kayitlar:
            if r.get("uuid") == u:
                return r
        return None

    def _adet(self, kunye):
        return self._kunye_say.get(kunye_anahtar(kunye), 0)

    def ekle(self, alan, foto_dosya, oturum):
        """Yeni kayıt ekler. Dönüş: (kayit, yeni_mi, tekrar_mi, foto_hata_mi)"""
        with self.kilit:
            r = self._uuid_bul(alan["uuid"])
            if r:   # aynı kayıt tekrar gönderilmiş (ör. yanıt telefona ulaşmadı): sessizce onayla
                return dict(r), False, self._adet(r["kunye_no"]) > 1, False
        zaman = datetime.now()
        foto_ad, foto_hata = "", False
        if foto_dosya is not None:      # yavaş iş (resim işleme) kilit dışında yapılır
            try:
                foto_ad = self._foto_kaydet(foto_dosya, alan["kunye_no"], zaman)
            except Exception as e:
                foto_hata = True
                log.warning("Fotoğraf kaydedilemedi (%s): %s", alan["kunye_no"], e)
        with self.kilit:
            r = self._uuid_bul(alan["uuid"])
            if r:   # aynı anda iki istek geldiyse ikincisinin fotoğrafını at
                self._foto_sil(foto_ad)
                return dict(r), False, self._adet(r["kunye_no"]) > 1, False
            kayit = {
                "id": self._sonraki_id, "uuid": alan["uuid"], "zaman": zaman.strftime("%Y-%m-%d %H:%M:%S"),
                "marka": alan["marka"], "model": alan["model"], "cihaz_adi": alan["cihaz_adi"],
                "kunye_no": alan["kunye_no"], "seri_no": alan.get("seri_no", ""),
                "birim": alan["birim"], "sayan": alan["sayan"],
                "foto": foto_ad, "oturum": oturum,
                "istemci_zaman": alan.get("istemci_zaman", ""),     # telefonda okutulduğu an (çevrimdışı kayıtlarda fark eder)
            }
            try:
                self._json_ekle(kayit)           # önce diske, sonra belleğe: yazılamazsa kayıt "var" sayılmaz
            except Exception:
                self._foto_sil(foto_ad)          # kaydı olmayan fotoğraf diskte öksüz kalmasın
                raise
            self._sonraki_id += 1
            self.kayitlar.append(kayit)
            self._uuidler.add(kayit["uuid"])
            if kunye_anahtar(kayit["kunye_no"]):
                self._kunye_say[kunye_anahtar(kayit["kunye_no"])] += 1
            tekrar = self._adet(kayit["kunye_no"]) > 1
            self.versiyon += 1                   # Excel arka planda (en geç ~3 sn içinde) güncellenir
        self._json_yedekle()
        return dict(kayit), True, tekrar, foto_hata

    def _silinen_yaz(self, kayit):
        """Silinen kaydı silinenler.jsonl'a ekler. Dönüş: eklemeden önceki dosya boyutu (geri alma için) ya da None."""
        yol = os.path.join(self.yedek_klasoru, "silinenler.jsonl")
        try:
            onceki = os.path.getsize(yol) if os.path.exists(yol) else 0
            k = dict(kayit)
            k["silinme_zamani"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            with open(yol, "a", encoding="utf-8") as f:
                f.write(json.dumps(k, ensure_ascii=False) + "\n")
            return onceki
        except Exception as e:
            log.warning("Silinen kayıt saklanamadı: %s", e)
            return None

    def _silinen_yaz_geri_al(self, onceki):
        """Silme diske yazılamadıysa az önce eklenen silinenler.jsonl girdisini kaldırır."""
        if onceki is None:
            return
        try:
            with open(os.path.join(self.yedek_klasoru, "silinenler.jsonl"), "r+b") as f:
                f.truncate(onceki)
        except OSError as e:
            log.warning("silinenler.jsonl girdisi geri alınamadı: %s", e)

    def _silinen_foto_tasi(self, kayit):
        """Silinen kaydın fotoğrafını (ana kayıt dosyası başarıyla yazıldıktan sonra) Yedek klasörüne taşır."""
        try:
            if kayit.get("foto"):
                hedef = os.path.join(self.yedek_klasoru, "silinen_fotograflar")
                os.makedirs(hedef, exist_ok=True)
                kaynak = os.path.join(self.foto_klasoru, kayit["foto"])
                if os.path.exists(kaynak):
                    shutil.move(kaynak, os.path.join(hedef, kayit["foto"]))
        except Exception as e:
            log.warning("Silinen fotoğraf taşınamadı: %s", e)

    def _silineni_sakla(self, kayit):
        """Silinen kaydı ve fotoğrafını geri getirilebilsin diye Yedek klasörüne alır (geriye dönük uyumluluk)."""
        self._silinen_yaz(kayit)
        self._silinen_foto_tasi(kayit)

    def sil(self, id_=None, uuid_=None, oturum=None):
        with self.kilit:
            hedef = None
            for r in self.kayitlar:
                if (id_ is not None and r.get("id") == id_) or (uuid_ is not None and r.get("uuid") == uuid_):
                    hedef = r
                    break
            if hedef is None:
                return False
            if oturum is not None and hedef.get("oturum") != oturum:
                return False
            sira = self.kayitlar.index(hedef)
            self.kayitlar.remove(hedef)
            silinen_onceki = self._silinen_yaz(hedef)   # önce silinenlere not düşülür (geri getirilebilsin)
            try:
                self._json_hepsini_yaz()
            except Exception:
                self.kayitlar.insert(sira, hedef)      # diske yazılamadı: bellekteki liste de eski haline dönsün
                self._silinen_yaz_geri_al(silinen_onceki)   # ... ve silinenler listesinde hayalet kayıt kalmasın
                raise
            self._silinen_foto_tasi(hedef)             # fotoğraf yalnızca silme kesinleştikten sonra taşınır
            self._indeksle()
            self.versiyon += 1
        self._json_yedekle()
        return True

    def guncelle(self, id_, **alanlar):
        with self.kilit:
            for r in self.kayitlar:
                if r.get("id") == id_:
                    eski = dict(r)
                    for k, v in alanlar.items():
                        if k in ALAN_ADLARI and k != "sayan":      # sayımı yapan kişi sonradan değiştirilemez
                            r[k] = temiz(v)
                    break
            else:
                return False
            try:
                self._json_hepsini_yaz()
            except Exception:
                r.clear()
                r.update(eski)                          # diske yazılamadı: bellekteki kayıt eski haline dönsün
                raise
            self._indeksle()
            self.versiyon += 1
        self._json_yedekle()
        return True

    # -- silinen kaydı geri getirme -----------------------------------------
    def _silinenler_oku(self):
        yol = os.path.join(self.yedek_klasoru, "silinenler.jsonl")
        sonuc = []
        try:
            with open(yol, "r", encoding="utf-8") as f:
                for satir in f:
                    satir = satir.strip()
                    if not satir:
                        continue
                    try:
                        k = json.loads(satir)
                        if isinstance(k, dict):
                            sonuc.append(k)
                    except Exception:
                        continue
        except FileNotFoundError:
            return []
        except OSError as e:
            log.warning("silinenler.jsonl okunamadı: %s", e)
            return []
        return sonuc

    def silinenler(self):
        """Silinen kayıtlar, en son silinen üstte."""
        with self.kilit:
            return list(reversed(self._silinenler_oku()))

    def geri_getir(self, silinme_zamani, id_, uuid_):
        """Silinen bir kaydı (fotoğrafıyla) yerine koyar. Dönüş: (kayit veya None, hata metni)."""
        with self.kilit:
            tum = self._silinenler_oku()
            sira = next((i for i, k in enumerate(tum) if k.get("silinme_zamani") == silinme_zamani
                         and k.get("id") == id_ and k.get("uuid", "") == (uuid_ or "")), None)
            if sira is None:
                return None, "Silinen kayıt bulunamadı (liste başka bir yerden değişmiş olabilir)."
            k = dict(tum[sira])
            k.pop("silinme_zamani", None)
            if k.get("uuid") and k["uuid"] in self._uuidler:
                return None, "Bu kayıt zaten listede var."
            for a in ALAN_ADLARI + ("zaman", "foto", "uuid", "oturum"):
                k.setdefault(a, "")
            if not isinstance(k.get("id"), int) or any(r.get("id") == k["id"] for r in self.kayitlar):
                k["id"] = self._sonraki_id              # eski numara başka kayda verilmişse yeni numara
            tasinan = None
            if k.get("foto"):
                kaynak = os.path.join(self.yedek_klasoru, "silinen_fotograflar", k["foto"])
                if os.path.exists(kaynak):
                    taban, uzanti = os.path.splitext(k["foto"])
                    ad, n = k["foto"], 1
                    while os.path.exists(os.path.join(self.foto_klasoru, ad)):
                        ad = f"{taban}_geri{n}{uzanti}"
                        n += 1
                    try:
                        shutil.move(kaynak, os.path.join(self.foto_klasoru, ad))
                        tasinan = (kaynak, os.path.join(self.foto_klasoru, ad))
                        k["foto"] = ad
                    except OSError as e:
                        log.warning("Fotoğraf geri taşınamadı: %s", e)
                        k["foto"] = ""
                elif not os.path.exists(os.path.join(self.foto_klasoru, k["foto"])):
                    k["foto"] = ""
            self.kayitlar.append(k)
            self.kayitlar.sort(key=lambda r: r.get("id", 0) if isinstance(r.get("id"), int) else 0)
            try:
                self._json_hepsini_yaz()
            except Exception as e:
                self.kayitlar.remove(k)
                if tasinan:
                    try:
                        shutil.move(tasinan[1], tasinan[0])
                    except OSError:
                        pass
                log.error("Geri getirme yazılamadı: %s", e)
                return None, f"Kayıt dosyasına yazılamadı: {e}"
            del tum[sira]
            try:
                yol = os.path.join(self.yedek_klasoru, "silinenler.jsonl")
                tmp = yol + ".tmp"
                with open(tmp, "w", encoding="utf-8") as f:
                    for x in tum:
                        f.write(json.dumps(x, ensure_ascii=False) + "\n")
                os.replace(tmp, yol)
            except OSError as e:
                log.warning("silinenler.jsonl güncellenemedi (kayıt geri getirildi): %s", e)
            self._indeksle()
            self.versiyon += 1
        self._json_yedekle()
        return dict(k), ""

    def al(self, id_):
        with self.kilit:
            for r in self.kayitlar:
                if r.get("id") == id_:
                    return dict(r)
        return None

    def liste(self):
        with self.kilit:
            return [dict(r) for r in self.kayitlar]

    def sayi(self):
        with self.kilit:
            return len(self.kayitlar)

    def tekrar_kumesi(self):
        with self.kilit:
            return {k for k, n in self._kunye_say.items() if n > 1}

    def kontrol(self, kunye):
        k = kunye_anahtar(kunye)
        if not k:
            return {"var": False, "adet": 0, "cihaz": ""}
        with self.kilit:
            eslesen = [r for r in self.kayitlar if kunye_anahtar(r.get("kunye_no")) == k] if self._kunye_say.get(k) else []
        if not eslesen:
            return {"var": False, "adet": 0, "cihaz": ""}
        return {"var": True, "adet": len(eslesen), "cihaz": eslesen[0].get("cihaz_adi", "")}

    def oneriler(self):
        with self.kilit:
            markalar = Counter(r.get("marka") for r in self.kayitlar if r.get("marka"))
            birimler = Counter(r.get("birim") for r in self.kayitlar if r.get("birim"))
            cihazlar = Counter(r.get("cihaz_adi") for r in self.kayitlar if r.get("cihaz_adi"))
        return {"markalar": [m for m, _ in markalar.most_common(100)],
                "birimler": [b for b, _ in birimler.most_common(100)],
                "cihazlar": [c for c, _ in cihazlar.most_common(100)]}

    def son_kayitlar(self, oturum, n=20):
        """Bu telefon oturumunun son kayıtları (yeniden eskiye) – telefondaki 'Son kayıtlarım' listesi için."""
        with self.kilit:
            sec = [r for r in self.kayitlar if r.get("oturum") == oturum][-n:]
            return [{"id": r["id"], "uuid": r.get("uuid", ""), "zaman": r.get("zaman", ""),
                     "cihaz_adi": r.get("cihaz_adi", ""), "kunye_no": r.get("kunye_no", ""),
                     "birim": r.get("birim", ""), "foto": bool(r.get("foto")),
                     "tekrar": self._adet(r.get("kunye_no")) > 1} for r in reversed(sec)]

    def tum_kayitlar(self, oturum):
        """Telefondaki 'Tüm Kayıtlar' ekranı için: tüm kayıtlar (yeniden eskiye), yalnızca gösterim alanları."""
        with self.kilit:
            bugun = datetime.now().strftime("%Y-%m-%d")
            return [{"id": r["id"], "zaman": r.get("zaman", ""), "cihaz_adi": r.get("cihaz_adi", ""),
                     "kunye_no": r.get("kunye_no", ""), "seri_no": r.get("seri_no", ""),
                     "marka": r.get("marka", ""), "model": r.get("model", ""), "birim": r.get("birim", ""),
                     "sayan": r.get("sayan", ""), "foto": bool(r.get("foto")),
                     "tekrar": self._adet(r.get("kunye_no")) > 1,
                     "benim": bool(oturum) and r.get("oturum") == oturum,
                     "uuid": r.get("uuid", "") if (oturum and r.get("oturum") == oturum) else "",
                     "bugun": str(r.get("zaman", "")).startswith(bugun)} for r in reversed(self.kayitlar)]

    def tum_sayfa(self, oturum, limit=60, offset=0, q="", filtre="hepsi"):
        """'Tüm Kayıtlar' ekranı için sunucu tarafı süzme + sayfalama (çok büyük listelerde telefona tüm liste inmesin).
        filtre: hepsi | benim | bugun | tekrar | fotosuz. Dönüş: liste (yeniden eskiye, yalnızca bu sayfa), toplam,
        filtreli (süzgece uyan toplam), sayac (tüm kayıtlar üzerinden: bugun, tekrar satır sayısı)."""
        qn = tum_arama_norm(q).strip()
        with self.kilit:
            bugun = datetime.now().strftime("%Y-%m-%d")
            sayac_bugun = sayac_tekrar = uyan = 0
            sayfa = []
            for r in reversed(self.kayitlar):
                bg = str(r.get("zaman", "")).startswith(bugun)
                tk = self._adet(r.get("kunye_no")) > 1
                bn = bool(oturum) and r.get("oturum") == oturum
                fo = bool(r.get("foto"))
                sayac_bugun += bg
                sayac_tekrar += tk
                if filtre == "benim" and not bn or filtre == "bugun" and not bg or filtre == "tekrar" and not tk \
                        or filtre == "fotosuz" and fo:
                    continue
                if qn and qn not in tum_arama_norm(" ".join(str(r.get(a, "")) for a in (
                        "cihaz_adi", "kunye_no", "seri_no", "marka", "model", "birim", "sayan", "id"))):
                    continue
                if offset <= uyan < offset + limit:
                    sayfa.append({"id": r["id"], "zaman": r.get("zaman", ""), "cihaz_adi": r.get("cihaz_adi", ""),
                                  "kunye_no": r.get("kunye_no", ""), "seri_no": r.get("seri_no", ""),
                                  "marka": r.get("marka", ""), "model": r.get("model", ""), "birim": r.get("birim", ""),
                                  "sayan": r.get("sayan", ""), "foto": fo, "tekrar": tk, "benim": bn,
                                  "uuid": r.get("uuid", "") if bn else "", "bugun": bg})
                uyan += 1
            return {"liste": sayfa, "toplam": len(self.kayitlar), "filtreli": uyan,
                    "sayac": {"bugun": int(sayac_bugun), "tekrar": int(sayac_tekrar)}}

    def ozet(self):
        with self.kilit:
            bugun = datetime.now().strftime("%Y-%m-%d")
            return {
                "toplam": len(self.kayitlar),
                "benzersiz": sum(1 for n in self._kunye_say.values() if n > 0),
                "tekrar": sum(1 for n in self._kunye_say.values() if n > 1),
                "fotolu": sum(1 for r in self.kayitlar if r.get("foto")),
                "bugun": sum(1 for r in self.kayitlar if str(r.get("zaman", "")).startswith(bugun)),
            }

    # -- yedek ----------------------------------------------------------------
    def _yedek_temizle(self, desen, tut):
        """Yedek klasöründe 'desen'e uyan en yeni 'tut' dosyayı bırakıp eskileri siler."""
        try:
            adlar = sorted(x for x in os.listdir(self.yedek_klasoru) if re.fullmatch(desen, x))
            for x in adlar[:-tut]:
                os.remove(os.path.join(self.yedek_klasoru, x))
        except Exception as e:
            log.warning("Eski yedekler temizlenemedi: %s", e)

    def _json_yedekle(self, zorla=False):
        """Zaman damgalı yedek (en çok 10 dakikada bir, son 40 yedek saklanır)."""
        if not zorla and time.time() - self._son_json_yedek < 600:
            return
        if not os.path.exists(self.json_yol):
            return
        try:
            with self.kilit:
                v = self.versiyon
                shutil.copy2(self.json_yol, os.path.join(
                    self.yedek_klasoru, f"kayitlar_{datetime.now():%Y%m%d_%H%M%S}.jsonl"))
            self._son_json_yedek = time.time()
            self._yedek_versiyon = v
            self._yedek_temizle(r"kayitlar_\d{8}_\d{6}\.jsonl", 40)
        except Exception as e:
            log.warning("JSON yedeği alınamadı: %s", e)

    def _excel_yedekle(self):
        if time.time() - self._son_excel_yedek < 1800 or not os.path.exists(self.excel_yol):
            return
        try:
            shutil.copy2(self.excel_yol, os.path.join(self.yedek_klasoru, f"Sayim_{datetime.now():%Y%m%d_%H%M%S}.xlsx"))
            self._son_excel_yedek = time.time()
            self._yedek_temizle(r"Sayim_\d{8}_\d{6}\.xlsx", 10)
        except Exception as e:
            log.warning("Excel yedeği alınamadı: %s", e)

    def yedek_al(self):
        """Elle yedek: kayıt dosyası + Excel kopyalanır ('_elle' ekli yedekler otomatik silinmez)."""
        if not os.path.exists(self.json_yol):
            raise FileNotFoundError("Henüz kayıt yok, yedeklenecek bir şey bulunamadı.")
        self.excel_senkron()
        damga = f"{datetime.now():%Y%m%d_%H%M%S}"
        with self.kilit:
            shutil.copy2(self.json_yol, os.path.join(self.yedek_klasoru, f"kayitlar_{damga}_elle.jsonl"))
        if os.path.exists(self.excel_yol):
            shutil.copy2(self.excel_yol, os.path.join(self.yedek_klasoru, f"Sayim_{damga}_elle.xlsx"))
        if self.ikinci_yedek:
            self.ikinci_yedek_esitle()
        return self.yedek_klasoru

    # -- ikinci yedek konumu (USB disk / ağ klasörü) ------------------------------
    def ikinci_yedek_ayarla(self, yol):
        """Ayarlar'dan ikinci yedek klasörü değiştirildiğinde çağrılır (boş = kapalı)."""
        with self._ikinci_kilit:
            self.ikinci_yedek = str(yol or "").strip()
            self.ikinci_yedek_hata = ""
            self._ikinci_versiyon = -1
            self._ikinci_tekrar = 0

    @staticmethod
    def _atomik_yaz(hedef, veri=None, kaynak=None):
        tmp = hedef + ".tmp"
        try:
            if kaynak is not None:
                shutil.copy2(kaynak, tmp)
            else:
                with open(tmp, "wb") as f:
                    f.write(veri)
            os.replace(tmp, hedef)
        except Exception:
            try:
                os.remove(tmp)
            except OSError:
                pass
            raise

    def ikinci_yedek_esitle(self):
        """Ana kaydı (günlük adlı kopya, son 14 gün), Excel'i ve henüz kopyalanmamış fotoğrafları ikinci konuma yazar.
        Ana kayıt asla bundan etkilenmez: hata olursa yalnızca ikinci_yedek_hata dolar ve arayüzde uyarı çıkar. Dönüş: başarılı mı."""
        hedef = self.ikinci_yedek
        if not hedef:
            return True
        with self._ikinci_kilit:
            try:
                with self.kilit:                       # kopya sırasında kayıt eklenmesin; kısa süre: yalnızca bellek okuması
                    v = self.versiyon
                    if os.path.exists(self.json_yol):
                        with open(self.json_yol, "rb") as f:
                            veri = f.read()
                    else:
                        veri = b""
                os.makedirs(hedef, exist_ok=True)
                self._atomik_yaz(os.path.join(hedef, f"kayitlar_{datetime.now():%Y%m%d}.jsonl"), veri=veri)
                if os.path.exists(self.excel_yol):
                    try:
                        self._atomik_yaz(os.path.join(hedef, "Sayim.xlsx"), kaynak=self.excel_yol)
                    except OSError as e:               # Excel hedefte açıksa kayıt/foto yedeği yine de sürsün
                        log.warning("İkinci yedeğe Excel kopyalanamadı: %s", e)
                fh = os.path.join(hedef, "Fotograflar")
                os.makedirs(fh, exist_ok=True)
                mevcut = set(os.listdir(fh))
                simdi = time.time()
                for ad in os.listdir(self.foto_klasoru):
                    k = os.path.join(self.foto_klasoru, ad)
                    if ad in mevcut or not os.path.isfile(k) or simdi - os.path.getmtime(k) < 10:
                        continue                       # yeni yazılmakta olan fotoğraf bir sonraki turda alınır
                    self._atomik_yaz(os.path.join(fh, ad), kaynak=k)
                adlar = sorted(x for x in os.listdir(hedef) if re.fullmatch(r"kayitlar_\d{8}\.jsonl", x))
                for x in adlar[:-14]:
                    os.remove(os.path.join(hedef, x))
                self._ikinci_versiyon = v
                self.ikinci_yedek_hata = ""
                return True
            except Exception as e:
                self.ikinci_yedek_hata = str(e)[:150] or e.__class__.__name__
                self._ikinci_tekrar = time.time() + 60
                log.warning("İkinci yedek yazılamadı (%s): %s", hedef, e)
                return False

    def csv_yaz(self, yol):
        with self.kilit:
            kayitlar = [dict(r) for r in self.kayitlar]
            tekrarlar = {k for k, n in self._kunye_say.items() if n > 1}
        with open(yol, "w", newline="", encoding="utf-8-sig") as f:   # utf-8-sig: Excel Türkçe karakterleri doğru açar
            w = csv.writer(f, delimiter=";")
            w.writerow(BASLIKLAR)
            for k in kayitlar:
                w.writerow([csv_guvenli(x) for x in (
                    k.get("id"), k.get("zaman"), k.get("marka"), k.get("model"), k.get("cihaz_adi"),
                    k.get("kunye_no"), k.get("seri_no"), k.get("birim"), k.get("sayan"), k.get("foto"),
                    "Evet" if kunye_anahtar(k.get("kunye_no")) in tekrarlar else "")])

    # -- Excel ----------------------------------------------------------------
    def _sayim_sayfasi(self, wb, kayitlar, tekrarlar, listede=frozenset()):
        """Ana sayfa. 'write_only' kipi + hazır stil şablonları: 10 bin kayıtta eski yönteme göre ~11 kat hızlı, düşük bellek."""
        ws = wb.create_sheet("Sayım")
        for i, g in enumerate(GENISLIKLER, 1):
            ws.column_dimensions[get_column_letter(i)].width = g
        ws.row_dimensions[1].height = 22
        ws.freeze_panes = "A2"
        ws.auto_filter.ref = f"A1:{get_column_letter(len(BASLIKLAR))}{max(len(kayitlar) + 1, 2)}"
        kenar = Border(left=INCE, right=INCE, top=INCE, bottom=INCE)
        orta, sol = Alignment(vertical="center", horizontal="center"), Alignment(vertical="center")
        link = Font(color="0563C1", underline="single")

        def sablon(font, dolgu, hiza):
            c = WriteOnlyCell(ws, value=0)
            c.border = kenar
            c.alignment = hiza
            if dolgu:
                c.fill = dolgu
            if font:
                c.font = font
            return c._style
        ST = {(o, t, l, g): sablon(link if l else None, ESLESME_YESIL if g else (SARI if t else None), orta if o else sol)
              for o in (0, 1) for t in (0, 1) for l in (0, 1) for g in (0, 1)}
        baslik = []
        for b in BASLIKLAR:
            c = WriteOnlyCell(ws, value=b)
            c.font = Font(bold=True, color="FFFFFF")
            c.fill = BASLIK_DOLGU
            c.alignment = Alignment(horizontal="center", vertical="center")
            baslik.append(c)
        ws.append(baslik)
        for k in kayitlar:
            t = 1 if kunye_anahtar(k.get("kunye_no")) in tekrarlar else 0
            degerler = [k.get("id"), k.get("zaman"), k.get("marka"), k.get("model"), k.get("cihaz_adi"),
                        k.get("kunye_no"), k.get("seri_no"), k.get("birim"), k.get("sayan"), "", "Evet" if t else ""]
            satir = []
            for i, v in enumerate(degerler, 1):
                c = WriteOnlyCell(ws, value=v)
                if isinstance(v, str):
                    c.data_type = "s"            # "=" ile başlayan metin formül sayılmasın
                g = 1 if (i == 6 and listede and kunye_norm(v) in listede) else 0     # künye dış listede bulundu -> yeşil
                c._style = copy.copy(ST[(1 if i in (1, 11) else 0, t, 0, g)])
                satir.append(c)
            if k.get("foto"):
                c = WriteOnlyCell(ws, value="Fotoğrafı aç")
                c.hyperlink = "Fotograflar/" + k["foto"]
                c._style = copy.copy(ST[(0, t, 1, 0)])
                satir[9] = c
            ws.append(satir)

    def _ozet_sayfasi(self, wb, kayitlar, tekrarlar):
        ws = wb.create_sheet("Özet")
        ws.column_dimensions["A"].width = 38
        ws.column_dimensions["B"].width = 16
        baslik_f, alt_f = Font(bold=True, color="FFFFFF"), Font(bold=True)

        def hucre(v, stil=None):
            c = WriteOnlyCell(ws, value=v)
            if isinstance(v, str):
                c.data_type = "s"
            if stil == "baslik":
                c.font, c.fill = baslik_f, BASLIK_DOLGU
            elif stil == "alt":
                c.font, c.fill = alt_f, ALT_BASLIK_DOLGU
            return c

        def yaz(a, b=None, stil=None):
            ws.append([hucre(a, stil)] + ([hucre(b, stil)] if b is not None else []))

        benzersiz = len({a for a in (kunye_anahtar(k.get("kunye_no")) for k in kayitlar) if a})
        yaz("Sayım Özeti", f"{datetime.now():%Y-%m-%d %H:%M}", "baslik")
        yaz("Toplam kayıt", len(kayitlar))
        yaz("Benzersiz künye sayısı", benzersiz)
        yaz("Birden fazla kaydı olan künye", len(tekrarlar))
        yaz("Fotoğraflı kayıt", sum(1 for k in kayitlar if k.get("foto")))
        ws.append([])
        for baslik, alan in (("Birim/Oda", "birim"), ("Cihaz Adı", "cihaz_adi"), ("Sayımı Yapan", "sayan")):
            yaz(baslik + " bazında", "Kayıt sayısı", "alt")
            for ad, n in say_birlestir(kayitlar, alan):
                yaz(ad, n)
            ws.append([])

    def _excel_olustur(self):
        """Tüm kayıtlardan Excel'i yeniden yazar; yazılan veri versiyonunu döndürür.
        (xlsx zip içinde XML olduğu ve 'Tekrar' boyaması eski satırları da değiştirebildiği için gerçek 'ekleme' yapılamaz;
        bunun yerine yazım write_only kipiyle çok hızlandırıldı ve büyük listelerde yazım aralığı otomatik açılır.)"""
        with self.kilit:
            kayitlar = [dict(r) for r in self.kayitlar]
            tekrarlar = {k for k, n in self._kunye_say.items() if n > 1}
            listede = set(self.liste_kunyeler)
            v = self.versiyon
        wb = Workbook(write_only=True)
        self._sayim_sayfasi(wb, kayitlar, tekrarlar, listede)
        self._ozet_sayfasi(wb, kayitlar, tekrarlar)
        self._excel_kaydet(wb)
        return v

    def _excel_kaydet(self, wb):
        tmp = self.excel_yol + ".tmp"
        try:
            wb.save(tmp)
            os.replace(tmp, self.excel_yol)   # Excel dosyası açıksa burada PermissionError alınır
        except Exception:
            try:
                if os.path.exists(tmp):
                    os.remove(tmp)
            except OSError:
                pass
            raise

    def excel_senkron(self):
        """Excel'i ana kayıttan yeniden yazar. Dosya açıksa kirli kalır, arka plan döngüsü sonra yeniden dener."""
        with self.excel_kilit:
            if not self.excel_kirli:
                return True
            try:
                bas = time.time()
                self.excel_yazilan = self._excel_olustur()
                self.excel_hata = ""
                sure = time.time() - bas
                if sure > 1:                       # büyük liste: sürekli yeniden yazıp işlemciyi yormasın (süre x2 bekle, en çok 60 sn)
                    self._excel_tekrar = time.time() + min(60, sure * 2)
                self._excel_yedekle()
                return True
            except PermissionError:
                self.excel_hata = "Excel dosyası açık; kapatınca otomatik yazılacak"
                self._excel_tekrar = time.time() + 10
            except Exception as e:
                self.excel_hata = f"Excel yazılamadı: {e}"
                self._excel_tekrar = time.time() + 10
                log.error("Excel yazılamadı: %s", e)
            return False

    def _senkron_dongusu(self):
        while not self._dur.wait(3):
            try:
                if self.excel_kirli and time.time() >= self._excel_tekrar:
                    self.excel_senkron()
                if self.versiyon != self._yedek_versiyon and time.time() - self._son_json_yedek >= 600:
                    self._json_yedekle()
                if (self.ikinci_yedek and (self._ikinci_versiyon != self.versiyon or self.ikinci_yedek_hata)
                        and time.time() >= self._ikinci_tekrar):
                    self.ikinci_yedek_esitle()
                    if not self.ikinci_yedek_hata:
                        self._ikinci_tekrar = time.time() + 300      # başarılıysa en çok 5 dakikada bir
            except Exception as e:
                log.error("Senkron döngüsü hatası: %s", e)


# ----------------------------------------------------------------------------
# HIZ SINIRLAYICI (yanlış PIN denemeleri)
# ----------------------------------------------------------------------------
# ----------------------------------------------------------------------------
# QR İÇERİĞİ ÇÖZÜMLEME  (telefon QR'ı okur -> bu bölüm alanları ayıklar)
# ----------------------------------------------------------------------------
_TR_HARF = str.maketrans("İıŞşĞğÜüÖöÇç", "IISSGGUUOOCC")

# Etiket (normalize edilmiş) -> form alanı. "malzeme/tur/yer" yedek değerlerdir (aşağıda birleştirilir).
ETIKET_ALAN = {
    "KUNYE NO": "kunye_no", "KUNYE": "kunye_no", "KNO": "kunye_no", "KUNYE NUMARASI": "kunye_no", "KUNYENO": "kunye_no",
    "S/N": "seri_no", "SN": "seri_no", "SERI NO": "seri_no", "SERI": "seri_no", "SERI NUMARASI": "seri_no",
    "SERIAL NO": "seri_no", "SERIAL NUMBER": "seri_no", "SERINO": "seri_no",
    "MARKA": "marka", "MODEL": "model",
    "TANIM": "cihaz_adi", "CIHAZ ADI": "cihaz_adi", "MALZEME TANIMI": "malzeme", "TUR": "tur",
}
EK_ETIKET = {"SICIL NO": "Sicil No", "DEMIRBAS NO": "Demirbaş No", "ZIMMET TARIHI": "Zimmet Tarihi",
             "LOT": "Lot", "URETIM TARIHI": "Üretim Tarihi", "KURUM ADI": "Kurum"}


def etiket_norm(s, camel=False):
    s = str(s or "")
    if camel:
        s = re.sub(r"(?<=[a-z])(?=[A-Z])", " ", s)
    s = s.translate(_TR_HARF).upper()
    s = "".join(c for c in unicodedata.normalize("NFKD", s) if not unicodedata.combining(c))
    s = re.sub(r"[^A-Z0-9/ ]+", " ", s)
    return re.sub(r"\s+", " ", s).strip()


def ad_norm(s):
    """Kişi adı karşılaştırması için: büyük/küçük harf ve Türkçe harf farkını (İ/ı/I/i, Ş, Ğ...) yok sayar.
    (Python'da 'İsmail'.lower() == 'ismail' DEĞİLDİR; Türkçe klavyenin otomatik büyük harfi 'İ' üretir.)"""
    s = unicodedata.normalize("NFC", str(s or "")).translate(_TR_HARF).upper()
    return re.sub(r"\s+", " ", s).strip()


class _TabloAyikla(HTMLParser):
    """HTML'deki tablo satırlarını [hücre, hücre, ...] listesi olarak toplar (iç içe tabloları da kaldırır)."""

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.satirlar, self._sat, self._huc, self._atla = [], [], [], 0

    def handle_starttag(self, tag, attrs):
        if tag in ("script", "style"):
            self._atla += 1
        elif tag == "tr":
            self._sat.append([])
        elif tag in ("td", "th"):
            self._huc.append([])
        elif tag == "br" and self._huc:
            self._huc[-1].append(" ")

    def handle_endtag(self, tag):
        if tag in ("script", "style"):
            self._atla = max(0, self._atla - 1)
        elif tag in ("td", "th") and self._huc:
            metin = re.sub(r"\s+", " ", "".join(self._huc.pop())).strip()
            if self._sat:
                self._sat[-1].append(metin)
        elif tag == "tr" and self._sat:
            satir = self._sat.pop()
            if satir:
                self.satirlar.append(satir)

    def handle_data(self, d):
        if self._huc and not self._atla:
            self._huc[-1].append(d)


def html_ciftleri(html):
    p = _TabloAyikla()
    try:
        p.feed(html)
        p.close()
    except Exception as e:
        log.warning("HTML ayıklanamadı: %s", e)
    ciftler = []
    for satir in p.satirlar:
        if len(satir) == 2:
            ciftler.append((satir[0], satir[1]))
        elif len(satir) > 2 and len(satir) % 2 == 0:
            ciftler += [(satir[i], satir[i + 1]) for i in range(0, len(satir), 2)]
    return ciftler


def metin_ciftleri(metin):
    ciftler = []
    for satir in re.split(r"[\r\n;|]+", metin):
        m = re.match(r"^\s*([^:=\t]{1,40}?)\s*[:=\t]\s*(.+?)\s*$", satir)
        if m:
            ciftler.append((m.group(1), m.group(2)))
    return ciftler


def json_ciftleri(metin):
    try:
        d = json.loads(metin)
    except Exception:
        return []
    if not isinstance(d, dict):
        return []
    return [(etiket_norm(k, camel=True), str(v)) for k, v in d.items() if isinstance(v, (str, int, float))]


def alanlari_esle(ciftler):
    """[(etiket, değer)] -> ({form_alani: değer}, [(ek etiket, değer)])"""
    ham, ek = {}, []
    for et, deger in ciftler:
        deger = temiz(deger, 200)
        if deger in ("", "-", "--", "—"):
            continue
        e = etiket_norm(et)
        alan = ETIKET_ALAN.get(e)
        if alan:
            ham.setdefault(alan, deger)
        elif e in EK_ETIKET and not any(x[0] == EK_ETIKET[e] for x in ek):
            ek.append((EK_ETIKET[e], deger))
    out = {a: ham[a] for a in ("kunye_no", "seri_no", "marka", "model") if a in ham}
    cihaz = ham.get("cihaz_adi") or ham.get("malzeme") or ham.get("tur")
    if cihaz:
        out["cihaz_adi"] = cihaz      # birim/bölüm bilgisi QR'dan bilerek aktarılmaz (elle girilir)
    return out, ek


def _ip_genel_mi(ip):
    """Yalnızca internetten erişilen (genel) adresler: yerel, özel ağ (10.x, 192.168.x, 172.16-31.x), link-local,
    paylaşımlı (100.64/10), ayrılmış ve çoklu yayın adresleri genel sayılmaz."""
    eslenik = getattr(ip, "ipv4_mapped", None)
    if eslenik is not None:
        ip = eslenik
    return ip.is_global and not ip.is_multicast


def alan_adi_listesi(metin):
    """'https://Alan.gov.tr/yol, *.baska.gov.tr:8080' gibi girişleri ['alan.gov.tr', 'baska.gov.tr'] haline getirir.
    (Şema/yol/port yazılırsa eskiden hiçbir adres eşleşmez ve QR okuma sessizce çalışmazdı.)"""
    sonuc = []
    for x in re.split(r"[,\n;]", str(metin or "")):
        x = x.strip().lower()
        if "://" in x:
            x = x.split("://", 1)[1]
        x = re.split(r"[/?#]", x, maxsplit=1)[0].rsplit("@", 1)[-1]
        x = re.sub(r":\d+$", "", x).lstrip("*.").strip(".")
        if x and x not in sonuc:
            sonuc.append(x)
    return sonuc


def url_izinli(url, izinli, guvenilir=()):
    """izinli doluysa yalnızca o alan adları. Boşsa herhangi bir adres, ama hastane ağındaki cihazları taramak için
    kötüye kullanılmasın diye yerel/özel ağ adresleri engellenir. 'guvenilir': yönetici ayarındaki künye sayfası sunucusu."""
    try:
        u = urllib.parse.urlparse(url)
    except Exception:
        return False
    if u.scheme not in ("http", "https") or not u.hostname:
        return False
    host = u.hostname.lower()
    if host in guvenilir:       # yöneticinin Ayarlar'da yazdığı künye sayfası sunucusu: izin listesi dolu olsa da erişilir
        return True
    if izinli:
        return any(host == x or host.endswith("." + x) for x in izinli)
    try:
        for ai in socket.getaddrinfo(host, None):
            ip = ipaddress.ip_address(ai[4][0].split("%")[0])
            if not _ip_genel_mi(ip):
                return False
    except Exception:
        return False
    return True


def _guvenli_baglanti_olustur(izinli, guvenilir):
    """http.client'ın bağlantı adımı: adı BİR KEZ çözer, adreslerden biri genel değilse bağlanmaz ve doğrulanan adrese bağlanır.
    (url_izinli ile gerçek bağlantı arasında DNS yanıtı değiştirilerek iç ağa gidilmesi - DNS rebinding - engellenir.)"""
    def baglan(adres, zaman_asimi=socket._GLOBAL_DEFAULT_TIMEOUT, kaynak=None, *a, **k):
        host, port = adres[0], adres[1]
        if izinli or str(host).lower() in guvenilir:       # yönetici bu siteleri kendisi izinli kılmış
            return socket.create_connection(adres, zaman_asimi, kaynak)
        adaylar = []
        for ai in socket.getaddrinfo(host, port, 0, socket.SOCK_STREAM):
            ip = ipaddress.ip_address(ai[4][0].split("%")[0])
            if not _ip_genel_mi(ip):
                raise OSError("Bu adrese bağlanılamaz (yerel/özel ağ adresi)")
            adaylar.append(ai[4][0])
        son_hata = None
        for ip in adaylar:
            try:
                return socket.create_connection((ip, port), zaman_asimi, kaynak)
            except OSError as e:
                son_hata = e
        raise son_hata or OSError("Adres çözülemedi")
    return baglan


def _vekil_kullaniliyor(req):
    """İstek bir HTTP vekil sunucusu (proxy) üzerinden mi gidiyor? Öyleyse adı vekil çözer; bağlantı denetimi atlanır."""
    try:
        return (urllib.parse.urlparse("//" + req.host).hostname or "") != (urllib.parse.urlparse(req.full_url).hostname or "")
    except Exception:
        return True


class _GuvenliHTTP(urllib.request.HTTPHandler):
    izinli = ()
    guvenilir = ()
    _vekil = False

    def _baglanti(self, *a, **k):
        c = http.client.HTTPConnection(*a, **k)
        if not self._vekil:
            c._create_connection = _guvenli_baglanti_olustur(self.izinli, self.guvenilir)
        return c

    def http_open(self, req):
        self._vekil = _vekil_kullaniliyor(req)
        return self.do_open(self._baglanti, req)


class _GuvenliHTTPS(urllib.request.HTTPSHandler):
    izinli = ()
    guvenilir = ()
    _vekil = False

    def _baglanti(self, *a, **k):
        c = http.client.HTTPSConnection(*a, **k)
        if not self._vekil:
            c._create_connection = _guvenli_baglanti_olustur(self.izinli, self.guvenilir)
        return c

    def https_open(self, req):
        self._vekil = _vekil_kullaniliyor(req)
        kw = {}
        if getattr(self, "_context", None) is not None:
            kw["context"] = self._context
        if getattr(self, "_check_hostname", None) is not None:      # Python 3.11 ve öncesi
            kw["check_hostname"] = self._check_hostname
        return self.do_open(self._baglanti, req, **kw)


class _GuvenliYonlendir(urllib.request.HTTPRedirectHandler):
    izinli = ()
    guvenilir = ()

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        if not url_izinli(newurl, self.izinli, self.guvenilir):
            raise urllib.error.URLError("yönlendirme reddedildi")
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def sayfa_cek(url, izinli, guvenilir=()):
    if not url_izinli(url, izinli, guvenilir):
        raise ValueError("Bu adrese bağlanılamaz (izin listesinde değil veya yerel/özel ağ adresi)")
    yon = _GuvenliYonlendir()
    yon.izinli = izinli
    yon.guvenilir = guvenilir
    h1, h2 = _GuvenliHTTP(), _GuvenliHTTPS()
    for h in (h1, h2):
        h.izinli = izinli
        h.guvenilir = guvenilir
    acici = urllib.request.build_opener(yon, h1, h2)
    istek = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0", "Accept-Language": "tr-TR,tr;q=0.9"})
    with acici.open(istek, timeout=8) as r:
        veri = r.read(2_000_001)
        cs = r.headers.get_content_charset()
    if len(veri) > 2_000_000:
        raise ValueError("Sayfa çok büyük")
    for kod in (cs, "utf-8", "cp1254"):
        if not kod:
            continue
        try:
            return veri.decode(kod)
        except Exception:
            continue
    return veri.decode("utf-8", "replace")


def qr_coz(ham, izinli=(), sablon=""):
    """QR/barkod içeriğinden cihaz alanlarını çıkarır.
    Desteklenen biçimler: (1) sayfası tablo olarak okunabilen web adresi (künye sayfası), (2) adresin ?kunye=... parametresi,
    (3) 'ETİKET: değer' satırları, (4) JSON, (5) yalnızca künye numarası."""
    ham = str(ham or "").strip()
    sonuc = {"alanlar": {}, "ek": [], "kaynak": "", "uyari": "", "ham": ham[:300]}
    if not ham:
        return sonuc
    alanlar, ek = {}, []
    guvenilir = set()       # yöneticinin ayarladığı künye sayfası sunucusu (özel ağda olsa bile) güvenilir sayılır
    try:
        h = urllib.parse.urlparse(str(sablon or "").replace("{kunye}", "0")).hostname
        if h:
            guvenilir.add(h.lower())
    except Exception:
        pass
    if re.match(r"^https?://", ham, re.I):
        u = urllib.parse.urlparse(ham)
        param = [(etiket_norm(k, camel=True), v) for k, v in urllib.parse.parse_qsl(u.query)]
        alanlar, ek = alanlari_esle(param)
        sonuc["kaynak"] = "adres"
        try:
            icerik = sayfa_cek(ham, izinli, guvenilir)
            ciftler = json_ciftleri(icerik.strip()) if icerik.lstrip().startswith("{") else html_ciftleri(icerik)
            a2, e2 = alanlari_esle(ciftler)
            if a2:
                alanlar.update(a2)
                ek = e2 or ek
                sonuc["kaynak"] = "sayfa"
            else:
                sonuc["uyari"] = "Adresteki sayfada künye tablosu bulunamadı."
        except Exception as e:
            log.warning("QR adresi okunamadı (%s): %s", ham[:120], e)
            sonuc["uyari"] = "QR adresi bu bilgisayardan açılamadı (%s)." % temiz(e, 80)
        if "kunye_no" not in alanlar:
            m = re.search(r"(?<!\d)\d{8,12}(?!\d)", u.path + "?" + u.query)
            if m:
                alanlar["kunye_no"] = m.group(0)
                sonuc["uyari"] = (sonuc["uyari"] + " " if sonuc["uyari"] else "") + "Künye no adresten tahmin edildi, kontrol edin."
    else:
        ciftler = json_ciftleri(ham) if ham.startswith("{") else metin_ciftleri(ham)
        alanlar, ek = alanlari_esle(ciftler)
        if alanlar:
            sonuc["kaynak"] = "metin"
        elif len(ham) <= 100:
            alanlar = {"kunye_no": temiz(ham, 100)}   # düz barkod: içerik doğrudan künye no kabul edilir
            sonuc["kaynak"] = "ham"
    k = alanlar.get("kunye_no", "")
    if (sablon and sonuc["kaynak"] in ("ham", "metin") and re.fullmatch(r"\d{8,12}", k)
            and not ("cihaz_adi" in alanlar and "seri_no" in alanlar)):
        # yalnızca künye no biliniyor: künye sayfasından geri kalan bilgileri tamamla
        try:
            icerik = sayfa_cek(sablon.replace("{kunye}", k), izinli, guvenilir)
            a2, e2 = alanlari_esle(html_ciftleri(icerik))
            if a2:
                for a, v in a2.items():
                    alanlar.setdefault(a, v)
                ek = e2 or ek
                sonuc["kaynak"] = "sayfa"
            else:
                sonuc["uyari"] = "Künye sayfasında tablo bulunamadı."
        except Exception as e:
            log.warning("Künye sayfası okunamadı (%s): %s", k, e)
            sonuc["uyari"] = "Künye sayfası bu bilgisayardan açılamadı (%s)." % temiz(e, 80)
    sonuc["alanlar"], sonuc["ek"] = alanlar, ek
    return sonuc


# ----------------------------------------------------------------------------
# FOTOĞRAFTAN OKUMA: önce QR (OpenCV), olmazsa etiket yazısından künye no (Tesseract)
# ----------------------------------------------------------------------------
_FOTO_SEM = threading.BoundedSemaphore(2)


def foto_qr_oku(im):
    """Fotoğrafta QR arar. Küçük QR'lar için önce tüm resim, sonra kayan pencere + 3x büyütme denenir."""
    if cv2 is None:
        return ""
    img = cv2.cvtColor(np.array(im), cv2.COLOR_RGB2BGR)
    h, w = img.shape[:2]
    det = cv2.QRCodeDetector()

    def oku(x):
        try:
            return det.detectAndDecode(x)[0] or ""
        except Exception:
            return ""
    v = oku(img)
    if v:
        return v
    bitis = time.time() + 15
    for pencere in (400, 520, 300):
        pw, ph = min(pencere, w), min(pencere, h)
        adim_x, adim_y = max(1, pw // 2), max(1, ph // 2)
        for y in list(range(0, max(1, h - ph + 1), adim_y)) + ([h - ph] if h > ph else []):
            for x in list(range(0, max(1, w - pw + 1), adim_x)) + ([w - pw] if w > pw else []):
                if time.time() > bitis:
                    return ""
                parca = cv2.resize(img[y:y + ph, x:x + pw], None, fx=3, fy=3, interpolation=cv2.INTER_CUBIC)
                v = oku(parca)
                if v:
                    return v
    return ""


def tesseract_hazir():
    if pytesseract is None:
        return False
    yol = shutil.which("tesseract")
    if not yol:
        for y in (r"C:\Program Files\Tesseract-OCR\tesseract.exe", r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe"):
            if os.path.exists(y):
                yol = y
                break
    if not yol:
        return False
    pytesseract.pytesseract.tesseract_cmd = yol
    return True


def ocr_kunye_ayikla(metin):
    m = re.search(r"K[UÜ]NYE\s*(?:NO)?\s*[:.]?\s*(\d{8,12})", metin, re.I)
    if m:
        return m.group(1)
    aday = re.findall(r"(?<![\d-])(\d{10})(?![\d-])", metin)   # tireli sicil numarasının parçalarını almaz
    return Counter(aday).most_common(1)[0][0] if aday else ""


def foto_ocr_kunye(im):
    """Dönüş: (künye_no veya '', okuma_yapıldı_mı)"""
    if not tesseract_hazir():
        return "", False
    try:
        try:
            dil = "tur+eng" if "tur" in pytesseract.get_languages() else "eng"
        except Exception:
            dil = "eng"
        return ocr_kunye_ayikla(pytesseract.image_to_string(im, lang=dil, config="--psm 11")), True
    except Exception as e:
        log.warning("OCR hatası: %s", e)
        return "", False


def foto_oku(veri, izinli=(), sablon=""):
    sonuc = {"alanlar": {}, "ek": [], "kaynak": "", "uyari": "", "ham": "", "yontem": ""}
    try:
        with Image.open(io.BytesIO(veri)) as im0:
            resim_boyut_denetle(im0)
            im = ImageOps.exif_transpose(im0).convert("RGB")
    except ValueError:
        sonuc["uyari"] = "Fotoğrafın çözünürlüğü çok yüksek."
        return sonuc
    except Exception:
        sonuc["uyari"] = "Fotoğraf açılamadı."
        return sonuc
    im.thumbnail((1920, 1920))
    with _FOTO_SEM:
        ham = foto_qr_oku(im)
        kunye, ocr_var = ("", tesseract_hazir()) if ham else foto_ocr_kunye(im)
    if ham:
        s2 = qr_coz(ham, izinli, sablon)
        s2["yontem"] = "qr"
        return s2
    if kunye:
        s2 = qr_coz(kunye, izinli, sablon)
        s2["yontem"] = "yazi"
        s2["uyari"] = ("Künye fotoğraftaki yazıdan okundu, kontrol edin. " + s2["uyari"]).strip()
        return s2
    eksik = []
    if cv2 is None:
        eksik.append("QR okuma için opencv-python-headless")
    if not ocr_var:
        eksik.append("yazı okuma için Tesseract")
    sonuc["uyari"] = "Fotoğrafta QR veya künye okunamadı." + (" (Kurulu değil: %s)" % ", ".join(eksik) if eksik else "")
    return sonuc



class HizSiniri:
    """Hatalı deneme sınırlayıcı: son 'pencere' saniye içindeki hatalar sayılır (eskiler düşer); 'deneme' hataya
    ulaşınca 'bekleme' saniye kilitlenir. (Eskiden hatalar hiç silinmiyordu: günlere yayılan 40 yanlış PIN herkesi kilitliyordu.)"""

    def __init__(self, deneme=5, bekleme=300, pencere=900):
        self.k = threading.Lock()
        self.d = {}              # anahtar -> (hata zamanları, kilit bitiş zamanı)
        self.deneme = deneme
        self.bekleme = bekleme
        self.pencere = pencere

    def kalan(self, ip):
        with self.k:
            e = self.d.get(ip)
            if e and e[1] > time.time():
                return int(e[1] - time.time()) + 1
        return 0

    def hata(self, ip):
        with self.k:
            simdi = time.time()
            zamanlar, kilit = self.d.get(ip, ([], 0))
            zamanlar = [z for z in zamanlar if simdi - z < self.pencere] + [simdi]
            if len(zamanlar) >= self.deneme:
                self.d[ip] = ([], simdi + self.bekleme)
            else:
                self.d[ip] = (zamanlar, kilit)
            if len(self.d) > 1000:      # bellek şişmesin: süresi dolmuş kayıtları at
                for a in [a for a, (z, kl) in self.d.items() if kl < simdi and not [x for x in z if simdi - x < self.pencere]]:
                    del self.d[a]

    def temizle(self, ip):
        with self.k:
            self.d.pop(ip, None)


# ----------------------------------------------------------------------------
# TELEFON FORMU (HTML + JS gömülü)
# ----------------------------------------------------------------------------
HTML = r'''<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="theme-color" content="#0b5ed7">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="Sayım">
<meta name="format-detection" content="telephone=no">
<meta name="color-scheme" content="light dark">
<link rel="manifest" href="/manifest.json">
<link rel="icon" href="/icon-192.png">
<link rel="apple-touch-icon" href="/icon-192.png">
<title>Hastane Sayım</title>
<style>
:root{--bg:#eef2f8;--kart:#fff;--yazi:#17202c;--soluk:#5d6a7d;--cizgi:#cfd8e6;--mavi:#0b5ed7;--mavi2:#084298;--baslik:#0b5ed7;
--yesil:#0f5132;--yesilbg:#d1e7dd;--yesilkenar:#198754;--kirmizi:#b02a37;--kirmizibg:#f8d7da;--sari:#664d03;--saribg:#fff3cd;--gri:#e3e9f3;
--kaydet:#198754;--tumbtn:#6f42c1;--odak:rgba(11,94,215,.25);--golge:0 1px 2px rgba(16,32,60,.08),0 4px 14px rgba(16,32,60,.06)}
@media (prefers-color-scheme:dark){:root{--bg:#0e131a;--kart:#18202b;--yazi:#e8edf4;--soluk:#9aa7b8;--cizgi:#35435a;--mavi:#3d8bfd;--mavi2:#8bb9fe;--baslik:#17315c;
--yesil:#a3d9bb;--yesilbg:#0f2e20;--yesilkenar:#2fb36a;--kirmizi:#ea868f;--kirmizibg:#3a1217;--sari:#ffda6a;--saribg:#33290a;--gri:#2a3546;--kaydet:#1e8f57;--tumbtn:#7e57c2;--odak:rgba(61,139,253,.35);--golge:none}}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
html{color-scheme:light dark;-webkit-text-size-adjust:100%;text-size-adjust:100%}
body{margin:0;font-family:system-ui,-apple-system,"Segoe UI",Roboto,Arial,sans-serif;font-size:16px;line-height:1.35;background:var(--bg);color:var(--yazi);padding-bottom:calc(112px + env(safe-area-inset-bottom));overscroll-behavior-y:none}
body.tarama{overflow:hidden}
button,input,summary{touch-action:manipulation}
header{background:var(--baslik);color:#fff;padding:10px 16px;padding-top:calc(10px + env(safe-area-inset-top));padding-left:max(16px,env(safe-area-inset-left));padding-right:max(16px,env(safe-area-inset-right));display:flex;gap:10px;align-items:center;position:sticky;top:0;z-index:5}
header h1{font-size:18px;margin:0;flex:1;font-weight:700}
.chip{font-size:13px;border-radius:12px;padding:4px 10px;background:rgba(255,255,255,.18);white-space:nowrap}
.chip.on{background:#198754}.chip.off{background:#dc3545}
.rozet{background:#ffc107;color:#222;border-radius:14px;padding:4px 10px;font-size:13px;font-weight:700;white-space:nowrap}
.rozet.kirmizi{background:#dc3545;color:#fff}
main{max-width:600px;margin:0 auto;padding:12px;padding-left:max(12px,env(safe-area-inset-left));padding-right:max(12px,env(safe-area-inset-right))}
.kart{background:var(--kart);border-radius:18px;padding:16px;box-shadow:var(--golge);margin-bottom:12px}
h2{margin:0 0 4px;font-size:18px}
.adim{display:flex;align-items:center;gap:10px;margin:0 0 14px;font-size:17px}
.adim b{display:inline-grid;place-items:center;width:26px;height:26px;border-radius:50%;background:var(--mavi);color:#fff;font-size:14px;flex:none}
label{display:block;font-weight:600;font-size:14px;color:var(--soluk);margin:16px 0 6px}
.adim + label{margin-top:0}
label.z::after{content:" *";color:var(--kirmizi)}
input:not([type=checkbox]):not([type=file]){-webkit-appearance:none;appearance:none;width:100%;min-height:52px;font-size:17px;padding:12px 14px;border:1.5px solid var(--cizgi);border-radius:14px;background:var(--bg);color:var(--yazi);font-family:inherit}
input:focus{outline:none;border-color:var(--mavi);box-shadow:0 0 0 3px var(--odak);background:var(--kart)}
input.hatali:not([type=checkbox]){border-color:var(--kirmizi)}
input:not([type=checkbox]):not([type=file]).oto{border-color:var(--yesilkenar);background-image:linear-gradient(var(--yesilkenar),var(--yesilkenar));background-size:5px 100%;background-repeat:no-repeat;background-position:left center}
.satir{display:flex;gap:8px}
.satir input{flex:1;min-width:0}
.iki{display:grid;grid-template-columns:1fr 1fr;gap:10px}
.iki label{margin-top:16px}
button{font-family:inherit;font-size:17px;border:0;border-radius:14px;padding:12px 16px;min-height:48px;background:var(--mavi);color:#fff;font-weight:600;cursor:pointer}
button.ikincil{background:var(--gri);color:var(--yazi)}
button.kare{min-width:52px;min-height:52px;padding:0 12px;flex:none}
button:disabled{opacity:.55}
button:active{opacity:.8}
button.tam{width:100%}
#tumBtn{background:var(--tumbtn)}
#altbar #kaydetBtn{background:var(--kaydet);box-shadow:0 2px 8px rgba(25,135,84,.4)}
.gizli{display:none!important}
.okut-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px}
.okut{min-height:88px;font-size:17px;line-height:1.25;border-radius:16px;padding:8px 6px}
.okut.ikinci{background:var(--kart);color:var(--mavi2);border:2px solid var(--mavi)}
.ipucu{font-size:13px;color:var(--soluk);margin:12px 0 0}
#qrDurum:empty,#kunyeDurum:empty{display:none}
#qrDurum{margin-top:12px;padding:10px 12px;border-radius:12px;font-size:14px;font-weight:600;word-break:break-word;background:var(--gri);color:var(--yazi)}
#qrDurum.ok{background:var(--yesilbg);color:var(--yesil)}
#qrDurum.uyar{background:var(--saribg);color:var(--sari)}
#kunyeDurum{margin-top:8px;padding:8px 12px;border-radius:10px;font-size:14px;font-weight:600}
#kunyeDurum.ok{background:var(--yesilbg);color:var(--yesil)}
#kunyeDurum.uyar{background:var(--saribg);color:var(--sari)}
#onizlemeKap{display:flex;align-items:center;gap:12px;margin-top:12px;padding:8px;border:1.5px solid var(--cizgi);border-radius:14px}
#onizleme{width:64px;height:64px;object-fit:cover;border-radius:10px;background:var(--bg);flex:none}
.foto-yazi{flex:1;font-weight:600}
.anahtar{display:flex;align-items:flex-start;gap:12px;margin:20px 0 0;font-weight:500;color:var(--yazi);font-size:15px;cursor:pointer}
.anahtar input{position:absolute;opacity:0;width:1px;height:1px}
.ayirac{flex:none;width:50px;height:30px;border-radius:15px;background:var(--cizgi);position:relative;transition:background .2s;margin-top:1px}
.ayirac::after{content:"";position:absolute;top:3px;left:3px;width:24px;height:24px;border-radius:50%;background:#fff;box-shadow:0 1px 3px rgba(0,0,0,.3);transition:transform .2s}
.anahtar input:checked + .ayirac{background:var(--yesilkenar)}
.anahtar input:checked + .ayirac::after{transform:translateX(20px)}
.anahtar input:focus-visible + .ayirac{outline:3px solid var(--odak)}
.anahtar small{display:block;color:var(--soluk);font-weight:400;margin-top:2px}
.kurulum{display:flex;align-items:center;gap:10px;background:var(--saribg);color:var(--sari);border-radius:16px;padding:10px 12px;margin-bottom:12px}
.kurulum-metin{flex:1;font-size:14px}.kurulum-metin b{display:block}
.kurulum button{min-height:40px;min-width:40px;padding:6px 14px;font-size:15px}
#altbar{position:fixed;left:0;right:0;bottom:0;z-index:6;background:var(--kart);border-top:1px solid var(--cizgi);padding:10px 12px calc(10px + env(safe-area-inset-bottom))}
#altbar button{display:block;width:100%;max-width:576px;margin:0 auto;min-height:58px;font-size:20px;letter-spacing:.5px;border-radius:16px;box-shadow:0 2px 8px rgba(11,94,215,.35)}
body.yaziyor #altbar{display:none}
#mesaj{position:fixed;left:12px;right:12px;bottom:calc(88px + env(safe-area-inset-bottom));max-width:576px;margin:0 auto;padding:12px 14px;border-radius:14px;font-size:16px;z-index:8;box-shadow:0 4px 16px rgba(0,0,0,.3);display:none}
#mesaj.tamam{background:var(--yesilbg);color:var(--yesil)}
#mesaj.hata{background:var(--kirmizibg);color:var(--kirmizi)}
#mesaj.uyari{background:var(--saribg);color:var(--sari)}
.not{font-size:13px;color:var(--soluk);margin-top:12px}
a{color:var(--mavi2)}
details summary{cursor:pointer;font-weight:600;font-size:16px;min-height:44px;display:flex;align-items:center}
.oge{display:flex;gap:10px;align-items:center;padding:10px 0;border-top:1px solid var(--cizgi)}
.oge .bilgi{flex:1;min-width:0}
.oge b{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.oge small{color:var(--soluk);font-size:13px}
.oge .etiket{display:inline-block;font-size:11px;font-weight:700;border-radius:8px;padding:1px 7px;margin-left:5px;vertical-align:1px}
.etiket.bekle{background:var(--saribg);color:var(--sari)}.etiket.red{background:var(--kirmizibg);color:var(--kirmizi)}.etiket.tek{background:var(--saribg);color:var(--sari)}
.oge button{padding:8px 11px;font-size:16px;background:var(--gri);color:var(--yazi);min-width:44px}
#toplam{text-align:center;color:var(--soluk);font-size:14px;margin:6px 0}
.giris{margin-top:18px;padding:24px 20px}
.giris .logo{font-size:44px;text-align:center;line-height:1.1}
.giris h2{text-align:center;font-size:22px;margin:6px 0 4px}
.giris .alt-yazi{text-align:center;color:var(--soluk);font-size:14px;margin:0 0 18px}
#tarayici{position:fixed;inset:0;background:#000;z-index:20;display:flex;flex-direction:column}
#tarayici video{position:absolute;inset:0;width:100%;height:100%;object-fit:cover}
.tara-ust{position:relative;z-index:2;display:flex;align-items:center;gap:10px;padding:12px 14px;padding-top:calc(12px + env(safe-area-inset-top));background:linear-gradient(rgba(0,0,0,.65),transparent);color:#fff}
.tara-ust span{flex:1;text-align:center;font-weight:600}
.yuvarlak{width:48px;height:48px;min-height:48px;padding:0;border-radius:50%;background:rgba(255,255,255,.22);color:#fff;font-size:20px}
.yuvarlak.acik{background:#ffc107;color:#222}
.tara-cerceve{position:relative;z-index:1;flex:1;display:grid;place-items:center;pointer-events:none}
.tara-cerceve i{display:block;width:min(70vw,300px);aspect-ratio:1;border-radius:22px;border:3px solid rgba(255,255,255,.9);box-shadow:0 0 0 100vmax rgba(0,0,0,.45);position:relative;overflow:hidden}
.tara-cerceve i::after{content:"";position:absolute;left:0;right:0;height:3px;background:#3ddc84;box-shadow:0 0 12px #3ddc84;animation:tara 1.8s ease-in-out infinite alternate}
@keyframes tara{from{top:6%}to{top:94%}}
.tara-alt{position:relative;z-index:2;padding:14px;padding-bottom:calc(14px + env(safe-area-inset-bottom));text-align:center;color:#fff;background:linear-gradient(transparent,rgba(0,0,0,.7))}
.tara-alt p{margin:0 0 10px;font-size:14px;opacity:.9}
@media (prefers-reduced-motion:reduce){.tara-cerceve i::after{animation:none;top:50%}.ayirac,.ayirac::after{transition:none}}

#tum{position:fixed;inset:0;z-index:15;background:var(--bg);display:flex;flex-direction:column}
body.tum-acik{overflow:hidden}
.tum-ust{background:var(--baslik);color:#fff;display:flex;align-items:center;gap:10px;padding:10px 12px;padding-top:calc(10px + env(safe-area-inset-top));padding-left:max(12px,env(safe-area-inset-left));padding-right:max(12px,env(safe-area-inset-right))}
.tum-ust h2{flex:1;margin:0;font-size:18px;color:#fff}
.tum-ust button{min-height:44px;min-width:44px;padding:6px 14px;font-size:16px;background:rgba(255,255,255,.2);color:#fff}
.tum-govde{flex:1;overflow-y:auto;-webkit-overflow-scrolling:touch;overscroll-behavior:contain;padding:12px;padding-left:max(12px,env(safe-area-inset-left));padding-right:max(12px,env(safe-area-inset-right));padding-bottom:calc(24px + env(safe-area-inset-bottom))}
.tum-ic{max-width:600px;margin:0 auto}
.istat{display:grid;grid-template-columns:repeat(4,1fr);gap:6px;margin-bottom:10px}
.istat div{background:var(--kart);border-radius:14px;padding:10px 6px;text-align:center;box-shadow:var(--golge)}
.istat b{display:block;font-size:22px;line-height:1.1}
.istat span{font-size:11px;color:var(--soluk);font-weight:700;letter-spacing:.3px}
#tumAra{margin-bottom:8px}
.cipler{display:flex;gap:6px;overflow-x:auto;padding:2px 0 10px;scrollbar-width:none}
.cipler::-webkit-scrollbar{display:none}
.cipler button{flex:none;min-height:38px;padding:6px 14px;font-size:14px;border-radius:19px;background:var(--gri);color:var(--yazi)}
.cipler button.secili{background:var(--mavi);color:#fff}
#tumSayac{font-size:13px;color:var(--soluk);margin:0 0 8px}
.tkayit{background:var(--kart);border-radius:14px;padding:10px 12px;margin-bottom:8px;box-shadow:var(--golge);cursor:pointer;border-left:5px solid var(--cizgi)}
.tkayit.tek{border-left-color:#ffc107}.tkayit.benim{border-left-color:var(--mavi)}
.tkayit .ust{display:flex;gap:8px;align-items:flex-start}
.tkayit .ad{flex:1;font-weight:700;min-width:0;word-break:break-word}
.tkayit .no{font-size:12px;color:var(--soluk);flex:none}
.tkayit .kun{font-size:15px;color:var(--mavi2);font-weight:700;margin-top:2px;word-break:break-all}
.tkayit .alt{font-size:13px;color:var(--soluk);margin-top:2px}
.tkayit .rozetler{margin-top:6px;display:flex;gap:5px;flex-wrap:wrap}
.tkayit .rz{font-size:11px;font-weight:700;border-radius:8px;padding:2px 8px;background:var(--gri);color:var(--yazi)}
.tkayit .rz.tek{background:var(--saribg);color:var(--sari)}.tkayit .rz.foto{background:var(--yesilbg);color:var(--yesil)}.tkayit .rz.benim{background:var(--mavi);color:#fff}
.tkayit .detay{display:none;margin-top:8px;padding-top:8px;border-top:1px solid var(--cizgi);font-size:14px}
.tkayit.ac .detay{display:block}
.tkayit .detay div{margin:3px 0}.tkayit .detay span{color:var(--soluk)}
.tkayit .detay img{display:block;width:100%;max-height:320px;object-fit:contain;border-radius:10px;margin-top:8px;background:var(--bg)}
#tumDaha{width:100%;margin:6px 0 4px}
.bos{text-align:center;color:var(--soluk);padding:28px 8px}

.esit{border-radius:16px;padding:10px 12px;margin-bottom:12px;background:var(--yesilbg);color:var(--yesil);border:1.5px solid var(--yesilkenar)}
.esit.cevrimdisi{background:var(--saribg);color:var(--sari);border-color:#ffc107}
.esit.sorun{background:var(--kirmizibg);color:var(--kirmizi);border-color:var(--kirmizi)}
.esit.gonderiyor{background:var(--gri);color:var(--yazi);border-color:var(--mavi)}
.esit-ic{display:flex;align-items:center;gap:10px}
.esit-ikon{font-size:24px;flex:none;line-height:1}
.esit.gonderiyor .esit-ikon{animation:don 1s linear infinite}
@keyframes don{to{transform:rotate(360deg)}}
.esit-metin{flex:1;min-width:0}
.esit-metin b{display:block;font-size:15px}
.esit-metin span{display:block;font-size:12px;opacity:.92;margin-top:1px}
.esit button{min-height:46px;padding:8px 12px;font-size:15px;flex:none}
#tumNot{background:var(--saribg);color:var(--sari);border-radius:12px;padding:8px 12px;font-size:13px;font-weight:600;margin:0 0 8px}
.tkayit.yerel{border-left-color:#ffc107}
.tkayit .rz.bekle{background:var(--saribg);color:var(--sari)}.tkayit .rz.red{background:var(--kirmizibg);color:var(--kirmizi)}
@media (prefers-reduced-motion:reduce){.esit.gonderiyor .esit-ikon{animation:none}}
</style>
</head>
<body>
<header>
  <h1>🏥 Hastane Sayım</h1>
  <span id="baglanti" class="chip on">● Bağlı</span>
  <span id="rozet" class="rozet gizli"></span>
</header>
<main>

<section id="giris" class="kart giris gizli">
  <div class="logo">🏥</div>
  <h2>Sayım Girişi</h2>
  <p class="alt-yazi">Adınızı yazın ve bilgisayarda görünen PIN'i girin.</p>
  <label for="g_ad">Adınız Soyadınız</label>
  <input id="g_ad" autocomplete="name" autocapitalize="words" enterkeyhint="next">
  <label for="g_pin">Sayım PIN'i</label>
  <div class="satir">
    <input id="g_pin" type="password" inputmode="numeric" autocomplete="off" enterkeyhint="go">
    <button id="pinGoster" type="button" class="ikincil kare" aria-label="PIN'i göster">👁</button>
  </div>
  <button id="g_btn" class="tam" style="margin-top:20px;min-height:56px">Giriş Yap</button>
  <div id="g_mesaj" class="not" role="status" aria-live="polite"></div>
  <p class="not">Bu forma hasta veya personel görüntüsü içeren fotoğraf yüklemeyin; yalnızca cihazı çekin.</p>
</section>

<div id="form" class="gizli">
  <section id="kurulum" class="kurulum gizli">
    <div class="kurulum-metin"><b>Ana ekrana ekleyin</b><span id="kurulumMetin"></span></div>
    <button id="kurulumBtn" type="button" class="gizli">Yükle</button>
    <button id="kurulumKapat" type="button" class="ikincil" aria-label="Kapat">✕</button>
  </section>

  <section id="esit" class="esit" aria-live="polite">
    <div class="esit-ic">
      <div class="esit-ikon" id="esitIkon">✔</div>
      <div class="esit-metin"><b id="esitBaslik">Bağlı</b><span id="esitAlt"></span></div>
      <button id="esitBtn" type="button">🔄 Güncelle</button>
    </div>
  </section>

  <section class="kart">
    <h3 class="adim"><b>1</b>Cihazı okutun</h3>
    <div class="okut-grid">
      <button id="barkodBtn" type="button" class="okut">📷 QR Okut</button>
      <button id="fotoBtn" type="button" class="okut ikinci">📸 Fotoğraf Çek</button>
    </div>
    <input id="fotoGiris" type="file" accept="image/*" capture="environment" class="gizli">
    <div id="qrDurum" role="status" aria-live="polite"></div>
    <div id="onizlemeKap" class="gizli">
      <img id="onizleme" alt="Çekilen fotoğraf">
      <span class="foto-yazi">Fotoğraf eklendi ✓</span>
      <button id="fotoSil" type="button" class="ikincil kare" aria-label="Fotoğrafı kaldır">✕</button>
    </div>
    <p class="ipucu">Etiketteki QR okutulunca künye, seri no, marka, model ve cihaz adı kendiliğinden dolar.</p>
  </section>

  <section class="kart">
    <h3 class="adim"><b>2</b>Cihaz bilgileri</h3>
    <label for="kunye_no">Künye No <span style="font-weight:400;color:var(--soluk)">(isteğe bağlı)</span></label>
    <input id="kunye_no" autocomplete="off" autocapitalize="characters" autocorrect="off" spellcheck="false" enterkeyhint="next">
    <div id="kunyeDurum" role="status" aria-live="polite"></div>

    <label for="seri_no">Seri No (S/N)</label>
    <input id="seri_no" autocomplete="off" autocapitalize="characters" autocorrect="off" spellcheck="false" enterkeyhint="next">

    <label for="cihaz_adi" class="z">Cihaz Adı</label>
    <input id="cihaz_adi" list="cihazlar" autocomplete="off" enterkeyhint="next">
    <datalist id="cihazlar"></datalist>

    <div class="iki">
      <div>
        <label for="marka">Marka</label>
        <input id="marka" list="markalar" autocomplete="off" autocorrect="off" enterkeyhint="next">
        <datalist id="markalar"></datalist>
      </div>
      <div>
        <label for="model">Model</label>
        <input id="model" autocomplete="off" autocorrect="off" spellcheck="false" enterkeyhint="next">
      </div>
    </div>
  </section>

  <section class="kart">
    <h3 class="adim"><b>3</b>Konum</h3>
    <label for="birim">Birim / Oda</label>
    <input id="birim" list="birimler" autocomplete="off" enterkeyhint="next">
    <datalist id="birimler"></datalist>

    <label for="sayan">Sayımı yapan (giriş yapan kişi)</label>
    <input id="sayan" readonly tabindex="-1" style="opacity:.75" title="Giriş yapan kişi otomatik yazılır; değiştirilemez">

    <label class="anahtar"><input type="checkbox" id="koru"><span class="ayirac"></span>
      <span><b>Aynı tür cihazları art arda sayıyorum</b><small>Cihaz adı, marka ve model korunur; yalnızca künye ve seri no temizlenir.</small></span></label>
  </section>

  <button id="tumBtn" type="button" class="tam" style="margin-bottom:12px;min-height:56px">📋 Tüm Kayıtları Göster (<span id="tumSayi">0</span>)</button>

  <details id="listeKutu" class="kart">
    <summary>Son kayıtlarım (<span id="listeSayi">0</span>)</summary>
    <div id="liste"></div>
    <p class="not" id="listeNot" style="margin:8px 0 0">Yanlış kaydı 🗑 ile silebilirsiniz.</p>
  </details>

  <div id="toplam"></div>
  <p class="not" style="text-align:center"><a href="#" id="cikis">Çıkış yap</a> · v9</p>

  <div id="altbar"><button id="kaydetBtn">KAYDET</button></div>
</div>

</main>

<div id="mesaj" role="status"></div>

<div id="tum" class="gizli" role="dialog" aria-label="Tüm kayıtlar">
  <div class="tum-ust">
    <button id="tumKapat" type="button" aria-label="Kapat">←</button>
    <h2>Tüm Kayıtlar</h2>
    <button id="tumYenile" type="button" aria-label="Yenile">↻</button>
  </div>
  <div class="tum-govde"><div class="tum-ic">
    <div class="istat">
      <div><b id="iToplam">0</b><span>TOPLAM</span></div>
      <div><b id="iBugun">0</b><span>BUGÜN</span></div>
      <div><b id="iTekrar">0</b><span>TEKRARLI</span></div>
      <div><b id="iBekleyen">0</b><span>BEKLEYEN</span></div>
    </div>
    <input id="tumAra" type="search" placeholder="Ara: cihaz, künye, seri no, birim, kişi…" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" enterkeyhint="search">
    <div class="cipler" id="tumCipler">
      <button type="button" data-f="hepsi" class="secili">Tümü</button>
      <button type="button" data-f="benim">Benim</button>
      <button type="button" data-f="bugun">Bugün</button>
      <button type="button" data-f="bekleyen">Bekleyen</button>
      <button type="button" data-f="tekrar">Tekrarlar</button>
      <button type="button" data-f="fotosuz">Fotoğrafsız</button>
    </div>
    <p id="tumNot" class="gizli"></p>
    <p id="tumSayac"></p>
    <div id="tumListe"></div>
    <button id="tumDaha" type="button" class="ikincil gizli">Daha fazla göster</button>
  </div></div>
</div>

<div id="tarayici" class="gizli" role="dialog" aria-label="QR tarayıcı">
  <video id="video" playsinline muted autoplay></video>
  <div class="tara-ust">
    <button id="tarayiciIptal" type="button" class="yuvarlak" aria-label="Kapat">✕</button>
    <span>QR kodu çerçeveye alın</span>
    <button id="fenerBtn" type="button" class="yuvarlak gizli" aria-label="Fener">🔦</button>
  </div>
  <div class="tara-cerceve"><i></i></div>
  <div class="tara-alt">
    <p>Okunmuyorsa yaklaşın, ışığı artırın veya fotoğrafla okutun.</p>
    <button id="tarayiciFoto" type="button" class="ikincil">📸 Fotoğrafla oku</button>
  </div>
</div>

<script>
const $ = s => document.querySelector(s);
const ALANLAR = ['marka', 'model', 'cihaz_adi', 'kunye_no', 'seri_no', 'birim', 'sayan'];
const DOKUNMATIK = window.matchMedia('(pointer: coarse)').matches;
const IOS = /iP(hone|ad|od)/.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
const UYGULAMA_MODU = window.matchMedia('(display-mode: standalone)').matches || navigator.standalone === true;
let tamFoto = null;
let gonderiyor = false;
let tekrarIste = false;
let kaydediyor = false;
let fotoModu = localStorage.getItem('fotoModu') || 'sor';
let sonListe = [];
let mesajZamani = null;
let kunyeIstek = 0;
let kunyeZamanlayici = null;
let cevrimici = navigator.onLine !== false;
let kuyrukDurum = {bekleyen: 0, red: 0};

function uuidUret() {
  if (window.crypto && crypto.randomUUID) return crypto.randomUUID();
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
    const r = Math.random() * 16 | 0;
    return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16);
  });
}

/* Bu telefona özgü kalıcı kimlik: yeniden girişte "Son kayıtlarım / BENİM" kayıtları kaybolmasın */
function cihazId() {
  let id = '';
  try { id = localStorage.getItem('cihazId') || ''; } catch (e) {}
  if (!/^[0-9A-Za-z-]{16,64}$/.test(id)) {
    id = uuidUret();
    try { localStorage.setItem('cihazId', id); } catch (e) {}
  }
  return id;
}

function mesaj(metin, tur, sure) {
  const m = $('#mesaj');
  m.className = tur || 'tamam';
  m.textContent = metin;
  m.style.display = 'block';
  clearTimeout(mesajZamani);
  mesajZamani = setTimeout(() => { m.style.display = 'none'; }, sure || 6000);
}
$('#mesaj').addEventListener('click', () => { $('#mesaj').style.display = 'none'; });

function baglanti(durum) {
  const onceki = cevrimici;
  cevrimici = !!durum;
  const c = $('#baglanti');
  c.textContent = durum ? '● Bağlı' : '● Bağlantı yok';
  c.className = 'chip ' + (durum ? 'on' : 'off');
  esitUygula();
  if (cevrimici && !onceki) setTimeout(gonder, 300);     // bağlantı geri geldi: bekleyenleri otomatik gönder
}
function saatMetni(ms) {
  if (!ms) return '';
  const d = new Date(Number(ms));
  return String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0');
}
function zamanMetni(ms) {
  const d = new Date(Number(ms));
  const p = n => String(n).padStart(2, '0');
  return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate()) + ' ' + p(d.getHours()) + ':' + p(d.getMinutes()) + ':' + p(d.getSeconds());
}

/* ---------- Eşitleme kartı (çevrimdışı çalışma + elle güncelle) ---------- */
function esitUygula() {
  const kart = $('#esit');
  if (!kart) return;
  const {bekleyen, red} = kuyrukDurum;
  let sinif = 'ok', ikon = '✔', baslik = '', alt = '';
  const son = saatMetni(localStorage.getItem('sonEsit'));
  if (gonderiyor) {
    sinif = 'gonderiyor'; ikon = '⟳'; baslik = 'Gönderiliyor…';
    alt = bekleyen + ' kayıt sunucuya aktarılıyor';
  } else if (red > 0) {
    sinif = 'sorun'; ikon = '⚠'; baslik = red + ' kayıt sorunlu';
    alt = '“Son kayıtlarım” listesinde ↻ ile yeniden deneyin veya 🗑 ile silin.' + (bekleyen ? ' Ayrıca ' + bekleyen + ' kayıt bekliyor.' : '');
  } else if (!cevrimici) {
    sinif = 'cevrimdisi'; ikon = '📴';
    baslik = bekleyen ? 'Çevrimdışı — ' + bekleyen + ' kayıt telefonda saklanıyor' : 'Çevrimdışı — kayıt yapabilirsiniz';
    alt = bekleyen ? 'Bağlantı gelince otomatik gönderilir. Program/tünel yeniden başlatıldıysa adres değişir; eski adreste bekleyen kayıtlar yeni adrese geçmez.'
                   : 'Kayıtlar telefonda saklanır, bağlantı gelince otomatik gönderilir.';
  } else if (bekleyen > 0) {
    sinif = 'cevrimdisi'; ikon = '⏳'; baslik = bekleyen + ' kayıt gönderilmeyi bekliyor';
    alt = 'Bağlısınız; “Güncelle” ile hemen gönderebilirsiniz.';
  } else {
    baslik = 'Bağlı — hepsi güncel';
    alt = son ? 'Son eşitleme: ' + son : 'Tüm kayıtlar sunucuda.';
  }
  kart.className = 'esit ' + (sinif === 'ok' ? '' : sinif);
  $('#esitIkon').textContent = ikon;
  $('#esitBaslik').textContent = baslik;
  $('#esitAlt').textContent = alt;
}
async function baglantiDene(oturumDenetle) {
  const ac = new AbortController();
  const zt = setTimeout(() => ac.abort(), 6000);
  try {
    const r = await fetch('/api/durum', {credentials: 'same-origin', cache: 'no-store', signal: ac.signal});
    const d = await r.json();
    baglanti(true);
    if (!d.giris && oturumDenetle && localStorage.getItem('girisYapildi')) girisGoster();
    return true;
  } catch (e) {
    baglanti(false);
    return false;
  } finally {
    clearTimeout(zt);
  }
}
async function esitle() {
  const b = $('#esitBtn');
  if (b.disabled) return;
  b.disabled = true;
  b.textContent = '⏳ Deneniyor…';
  try {
    const once = (await kuyrukHepsi()).filter(x => x.durum !== 'reddedildi').length;
    const ok = await baglantiDene(true);
    if (!ok) {
      mesaj('Bağlantı yok. Kayıtlar telefonda güvende; bağlantı gelince otomatik gönderilecek.', 'uyari', 5000);
      return;
    }
    await gonder();
    oneriYukle();
    if ($('#listeKutu').open) listeYenile();
    if (tumAcikMi()) tumYukle();
    const sonra = (await kuyrukHepsi()).filter(x => x.durum !== 'reddedildi').length;
    if (sonra) mesaj(sonra + ' kayıt hâlâ gönderilemedi, tekrar denenecek.', 'uyari', 5000);
    else {
      localStorage.setItem('sonEsit', String(Date.now()));
      mesaj(once ? once + ' kayıt gönderildi, her şey güncel ✓' : 'Her şey güncel ✓', 'tamam', 3500);
    }
  } finally {
    b.disabled = false;
    b.textContent = '🔄 Güncelle';
    bekleyenGuncelle();
  }
}

function toplamYaz(n) { $('#toplam').textContent = 'Sunucudaki toplam kayıt: ' + n; const t = $('#tumSayi'); if (t) t.textContent = n; }

/* ---------- IndexedDB kuyruğu (internet yokken kayıtlar burada bekler) ---------- */
function dbAc() {
  return new Promise((res, rej) => {
    const r = indexedDB.open('sayim', 1);
    r.onupgradeneeded = () => r.result.createObjectStore('kuyruk', {keyPath: 'uuid'});
    r.onsuccess = () => res(r.result);
    r.onerror = () => rej(r.error);
  });
}
async function kuyrukEkle(k) {
  const db = await dbAc();
  return new Promise((res, rej) => {
    const t = db.transaction('kuyruk', 'readwrite');
    t.objectStore('kuyruk').put(k);
    t.oncomplete = () => res();
    t.onerror = () => rej(t.error);
  });
}
async function kuyrukSil(uuid) {
  const db = await dbAc();
  return new Promise((res, rej) => {
    const t = db.transaction('kuyruk', 'readwrite');
    t.objectStore('kuyruk').delete(uuid);
    t.oncomplete = () => res();
    t.onerror = () => rej(t.error);
  });
}
async function kuyrukHepsi() {
  const db = await dbAc();
  return new Promise((res, rej) => {
    const t = db.transaction('kuyruk', 'readonly');
    const q = t.objectStore('kuyruk').getAll();
    q.onsuccess = () => res(q.result || []);
    q.onerror = () => rej(q.error);
  });
}
async function bekleyenGuncelle() {
  try {
    const l = await kuyrukHepsi();
    const red = l.filter(x => x.durum === 'reddedildi').length;
    const bekleyen = l.length - red;
    kuyrukDurum = {bekleyen: bekleyen, red: red};
    esitUygula();
    const r = $('#rozet');
    r.textContent = (red ? 'Sorunlu: ' + red + ' · ' : '') + 'Bekleyen: ' + bekleyen;
    r.classList.toggle('gizli', l.length === 0);
    r.classList.toggle('kirmizi', red > 0);
  } catch (e) {}
}

/* ---------- Giriş ---------- */
function girisGoster() {
  $('#form').classList.add('gizli');
  $('#giris').classList.remove('gizli');
  $('#g_ad').value = localStorage.getItem('sayan') || '';
}
function formGoster(ad) {
  $('#giris').classList.add('gizli');
  $('#form').classList.remove('gizli');
  $('#sayan').value = ad || localStorage.getItem('sayan') || '';        // giriş yapan kişi; elle değiştirilemez
  if (!$('#birim').value) $('#birim').value = localStorage.getItem('birim') || '';
  $('#koru').checked = localStorage.getItem('koru') === '1';
}
function fotoModuAl(d) {
  if (d && d.foto_modu) { fotoModu = d.foto_modu; localStorage.setItem('fotoModu', fotoModu); }
}
async function girisYap() {
  const ad = $('#g_ad').value.trim();
  const pin = $('#g_pin').value.trim();
  if (!ad || !pin) { $('#g_mesaj').textContent = 'Ad ve PIN gerekli'; return; }
  $('#g_btn').disabled = true;
  try {
    const r = await fetch('/api/giris', {
      method: 'POST', credentials: 'same-origin',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({ad: ad, pin: pin, cihaz: cihazId()})
    });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) { $('#g_mesaj').textContent = d.hata || 'Giriş başarısız'; return; }
    fotoModuAl(d);
    localStorage.setItem('girisYapildi', '1');
    localStorage.setItem('sayan', ad);
    $('#g_pin').value = '';
    $('#g_mesaj').textContent = '';
    baglanti(true);
    formGoster(ad);
    oneriYukle();
    gonder();
  } catch (e) {
    $('#g_mesaj').textContent = 'Bağlantı kurulamadı, internetinizi kontrol edin';
  } finally {
    $('#g_btn').disabled = false;
  }
}
async function durumKontrol() {
  try {
    const r = await fetch('/api/durum', {credentials: 'same-origin'});
    const d = await r.json();
    baglanti(true);
    fotoModuAl(d);
    if (d.giris) { formGoster(d.ad); oneriYukle(); gonder(); } else { girisGoster(); }
  } catch (e) {
    // internet yoksa: daha önce giriş yapıldıysa formu aç, kayıtlar kuyrukta bekler
    baglanti(false);
    if (localStorage.getItem('girisYapildi')) formGoster(); else girisGoster();
  }
}

/* ---------- Öneri listeleri ---------- */
function listeDoldur(id, dizi) {
  const kap = $('#' + id);
  kap.textContent = '';
  (dizi || []).forEach(x => { const o = document.createElement('option'); o.value = x; kap.appendChild(o); });
}
function oneriDoldur(d) {
  listeDoldur('markalar', d.markalar);
  listeDoldur('birimler', d.birimler);
  listeDoldur('cihazlar', d.cihazlar);
  if (d.toplam !== undefined) toplamYaz(d.toplam);
}
async function oneriYukle() {
  try {
    const r = await fetch('/api/oneriler', {credentials: 'same-origin'});
    if (r.status === 401) { girisGoster(); return; }
    if (!r.ok) return;
    const d = await r.json();
    localStorage.setItem('oneri', JSON.stringify(d));
    oneriDoldur(d);
  } catch (e) {
    try { oneriDoldur(JSON.parse(localStorage.getItem('oneri') || '{}')); } catch (x) {}
  }
}

/* ---------- Fotoğraf ---------- */
async function kucult(dosya, maks, kalite) {
  let bmp;
  try {
    bmp = await createImageBitmap(dosya, {imageOrientation: 'from-image'});
  } catch (e) {
    bmp = await new Promise((res, rej) => {
      const i = new Image();
      i.onload = () => res(i);
      i.onerror = rej;
      i.src = URL.createObjectURL(dosya);
    });
  }
  const w = bmp.width || bmp.naturalWidth;
  const h = bmp.height || bmp.naturalHeight;
  const o = Math.min(1, maks / Math.max(w, h));
  const c = document.createElement('canvas');
  c.width = Math.round(w * o);
  c.height = Math.round(h * o);
  c.getContext('2d').drawImage(bmp, 0, 0, c.width, c.height);
  return new Promise((res, rej) => c.toBlob(b => b ? res(b) : rej(new Error('blob')), 'image/jpeg', kalite || 0.8));
}
function fotoTemizle() {
  tamFoto = null;
  $('#fotoGiris').value = '';
  $('#onizlemeKap').classList.add('gizli');
  $('#fotoBtn').textContent = '📸 Fotoğraf Çek';
}

/* ---------- Künye: canlı tekrar kontrolü ---------- */
async function kunyeKontrol(v) {
  if (!v) return {var: false, adet: 0, cihaz: ''};      // künye isteğe bağlı: boş künye "tekrar" sayılmaz
  let yerel = 0;
  try {
    yerel = (await kuyrukHepsi()).filter(x => (x.kunye_no || '').toUpperCase() === v.toUpperCase()).length;
  } catch (e) {}
  const ac = new AbortController();
  const zt = setTimeout(() => ac.abort(), 4000);
  try {
    const r = await fetch('/api/kontrol?kunye=' + encodeURIComponent(v), {credentials: 'same-origin', signal: ac.signal});
    if (r.status === 401) { girisGoster(); return null; }
    if (r.ok) {
      const s = await r.json();
      baglanti(true);
      return {var: s.var || yerel > 0, adet: (s.adet || 0) + yerel, cihaz: s.cihaz || ''};
    }
  } catch (e) {
    baglanti(false);   // internet yok: yalnızca telefondaki bekleyen kayıtlara bakılır
  } finally {
    clearTimeout(zt);
  }
  return {var: yerel > 0, adet: yerel, cihaz: ''};
}
function kunyeCanli() {
  clearTimeout(kunyeZamanlayici);
  const no = ++kunyeIstek;
  const v = $('#kunye_no').value.trim();
  const d = $('#kunyeDurum');
  d.textContent = '';
  d.className = '';
  if (!v) return;
  kunyeZamanlayici = setTimeout(async () => {
    const s = await kunyeKontrol(v);
    if (!s || no !== kunyeIstek) return;
    if (s.var) {
      d.className = 'uyar';
      d.textContent = '⚠ Bu künye daha önce ' + s.adet + ' kez kaydedilmiş' + (s.cihaz ? ' (' + s.cihaz + ')' : '') + '.';
    } else {
      d.className = 'ok';
      d.textContent = '✓ Yeni künye';
    }
  }, 350);
}

/* ---------- Barkod / karekod ---------- */
let akim = null;
let taraZamani = null;
let fener = false;
let sesBaglam = null;
function sesHazirla() {   // iOS ses için kullanıcı dokunuşunda açılmalı
  try {
    sesBaglam = sesBaglam || new (window.AudioContext || window.webkitAudioContext)();
    if (sesBaglam.state === 'suspended') sesBaglam.resume();
  } catch (e) {}
}
function bip() {
  try {
    if (!sesBaglam) return;
    const o = sesBaglam.createOscillator(), g = sesBaglam.createGain();
    o.frequency.value = 880;
    g.gain.value = 0.08;
    o.connect(g);
    g.connect(sesBaglam.destination);
    o.start();
    o.stop(sesBaglam.currentTime + 0.12);
  } catch (e) {}
}
async function barkodAc() {
  sesHazirla();
  if (!('BarcodeDetector' in window)) {
    // iOS Safari ve bazı tarayıcılarda canlı QR tarama yoktur: etiketin fotoğrafı çekilir, bilgisayar okur
    mesaj('Bu tarayıcıda canlı tarama yok. QR etiketinin fotoğrafını çekin; bilgiler otomatik okunur.', 'uyari', 5000);
    $('#fotoGiris').click();
    return;
  }
  try {
    akim = await navigator.mediaDevices.getUserMedia({
      video: {facingMode: {ideal: 'environment'}, width: {ideal: 1920}, height: {ideal: 1080}}, audio: false});
  } catch (e) {
    mesaj('Kamera izni verilmedi. "Fotoğraf Çek" düğmesiyle QR etiketini fotoğraflayabilirsiniz.', 'uyari', 6000);
    return;
  }
  const v = $('#video');
  v.srcObject = akim;
  try { await v.play(); } catch (e) {}
  $('#tarayici').classList.remove('gizli');
  document.body.classList.add('tarama');
  fener = false;
  $('#fenerBtn').classList.add('gizli');
  $('#fenerBtn').classList.remove('acik');
  try {
    const iz = akim.getVideoTracks()[0];
    const yet = iz.getCapabilities ? iz.getCapabilities() : {};
    if (yet.torch) $('#fenerBtn').classList.remove('gizli');
    if (yet.focusMode && yet.focusMode.indexOf('continuous') >= 0) iz.applyConstraints({advanced: [{focusMode: 'continuous'}]}).catch(() => {});
  } catch (e) {}
  let det;
  try {
    const f = await BarcodeDetector.getSupportedFormats();
    det = new BarcodeDetector({formats: f});
  } catch (e) {
    det = new BarcodeDetector();
  }
  taraZamani = setInterval(async () => {
    try {
      if (!akim) return;
      const b = await det.detect(v);
      if (!akim) return;                 // aynı okuma iki kez işlenmesin
      if (b.length) {
        const ham = b[0].rawValue;
        bip();
        if (navigator.vibrate) navigator.vibrate(80);
        barkodKapat();
        qrIsle(ham);
      }
    } catch (e) {}
  }, 300);
}

/* Çözülen alanları forma yazar. guvenilir=false (yazıdan okuma) ise formdaki farklı künyenin üzerine yazmaz. */
function qrUygula(s, guvenilir, odak, etiket) {
  const d = $('#qrDurum');
  const a = s.alanlar || {};
  const eskiK = $('#kunye_no').value.trim().toUpperCase();
  const ayni = !!eskiK && !!a.kunye_no && eskiK === String(a.kunye_no).toUpperCase();
  if (!guvenilir && eskiK && a.kunye_no && !ayni) {
    d.className = 'uyar';
    d.textContent = 'Fotoğraftan okunan künye (' + a.kunye_no + ') formdakinden farklı; form değiştirilmedi.';
    return;
  }
  const ADLAR = {cihaz_adi: 'Cihaz', marka: 'Marka', model: 'Model', kunye_no: 'Künye', seri_no: 'Seri No'};
  const dolan = [];
  ALANLAR.forEach(f => {
    const el = $('#' + f);
    if (!a[f] || !el) return;
    if (ayni && el.value.trim()) return;          // aynı cihaz: elle girilenin üzerine yazma
    el.value = a[f];
    el.classList.remove('hatali');
    el.classList.add('oto');
    if (ADLAR[f]) dolan.push(ADLAR[f]);
  });
  kunyeCanli();
  if (!dolan.length && !ayni) {
    d.className = 'uyar';
    d.textContent = s.ham ? 'QR tanınamadı. İçerik: ' + String(s.ham).slice(0, 120) : (s.uyari || 'Bilgi okunamadı.');
    return;
  }
  let t = '✓ ' + (etiket || 'QR okundu') + (dolan.length ? ': ' + dolan.join(', ') : '');
  if (s.ek && s.ek.length) t += ' · ' + s.ek.slice(0, 3).map(x => x[0] + ' ' + x[1]).join(' · ');
  if (!$('#birim').value.trim()) t += ' · Birim/Oda’yı girin';
  if (s.uyari) t += ' — ' + s.uyari;
  d.className = s.uyari ? 'uyar' : 'ok';
  d.textContent = t;
  if (odak && !DOKUNMATIK && !$('#seri_no').value) $('#seri_no').focus();
}

/* QR içeriğini sunucuya çözdürür, dönen alanları forma doldurur */
async function qrIsle(ham, odak, etiket) {
  ham = String(ham || '').trim();
  const d = $('#qrDurum');
  d.className = '';
  d.textContent = 'QR okunuyor…';
  let s = null;
  try {
    const r = await fetch('/api/qr_coz', {method: 'POST', headers: {'Content-Type': 'application/json'},
                                          credentials: 'same-origin', body: JSON.stringify({ham: ham})});
    if (r.status === 401) { girisGoster(); return; }
    if (r.ok) { s = await r.json(); baglanti(true); }
  } catch (e) { baglanti(false); }
  if (!s) {   // internet yok: yalnızca düz künye veya adresteki künye parametresi kullanılabilir
    let k = ham;
    try {
      const u = new URL(ham);
      k = '';
      u.searchParams.forEach((v, a) => { if (/kunye|kno/i.test(a)) k = v; });
    } catch (e) {}
    s = {alanlar: k ? {kunye_no: k} : {}, ek: [], ham: ham,
         uyari: 'Bağlantı yok: yalnızca künye no alındı, diğer alanlar elle yazılmalı.'};
  }
  qrUygula(s, true, odak !== false, etiket);
}

/* Fotoğraftan okuma: önce telefonda QR aranır; bulunamazsa sunucu (OpenCV/Tesseract) denenir */
let fotoOkuNo = 0;
async function fotoOku(dosya) {
  const no = ++fotoOkuNo;
  const d = $('#qrDurum');
  d.className = '';
  d.textContent = 'Fotoğraf okunuyor…';
  if ('BarcodeDetector' in window) {
    try {
      const bmp = await createImageBitmap(dosya, {imageOrientation: 'from-image'});
      const b = await new BarcodeDetector({formats: ['qr_code']}).detect(bmp);
      if (bmp.close) bmp.close();
      if (b.length) {
        if (no === fotoOkuNo) await qrIsle(b[0].rawValue, false, 'Fotoğraftaki QR okundu');
        return;
      }
    } catch (e) {}
  }
  let s = null;
  try {
    // küçük QR'lar için sıkıştırılmamış orijinal en iyisidir; çok büyükse yüksek kaliteyle küçült
    const kb = dosya.size <= 5000000 ? dosya : await kucult(dosya, 2600, 0.92);
    const fd = new FormData();
    fd.append('foto', kb, 'oku.jpg');
    const r = await fetch('/api/foto_oku', {method: 'POST', body: fd, credentials: 'same-origin'});
    if (r.status === 401) { girisGoster(); return; }
    if (r.ok) { s = await r.json(); baglanti(true); }
  } catch (e) { baglanti(false); }
  if (no !== fotoOkuNo) return;                  // arada yeni fotoğraf çekildi
  if (!s) {
    d.className = 'uyar';
    d.textContent = 'Fotoğraf okunamadı (bağlantı yok); bilgileri elle girin.';
    return;
  }
  qrUygula(s, s.yontem === 'qr', false, s.yontem === 'qr' ? 'Fotoğraftaki QR okundu' : 'Fotoğraftan okundu');
}

function barkodKapat() {
  clearInterval(taraZamani);
  if (akim) akim.getTracks().forEach(t => t.stop());
  akim = null;
  fener = false;
  $('#tarayici').classList.add('gizli');
  document.body.classList.remove('tarama');
}

/* ---------- Kaydet / gönder ---------- */
function formuTemizle(koru) {
  (koru ? ['kunye_no', 'seri_no'] : ['marka', 'model', 'cihaz_adi', 'kunye_no', 'seri_no']).forEach(a => $('#' + a).value = '');
  $('#qrDurum').textContent = '';
  $('#qrDurum').className = '';
  ALANLAR.forEach(a => $('#' + a).classList.remove('oto'));
  fotoTemizle();
  kunyeCanli();
  if (DOKUNMATIK) window.scrollTo({top: 0, behavior: 'smooth'});     // telefonda klavye açılmasın; sıradaki okutma için başa dön
  else $(koru ? '#kunye_no' : '#cihaz_adi').focus();
}

async function kaydet() {
  if (kaydediyor) return;
  const k = {uuid: uuidUret(), zaman: Date.now()};
  ALANLAR.forEach(a => k[a] = $('#' + a).value.trim());
  $('#cihaz_adi').classList.toggle('hatali', !k.cihaz_adi);
  if (!k.cihaz_adi) {
    mesaj('Cihaz adı zorunludur.', 'hata');
    $('#cihaz_adi').focus();
    return;
  }
  kaydediyor = true;
  $('#kaydetBtn').disabled = true;
  try {
    if (!tamFoto) {
      if (fotoModu === 'zorunlu') { mesaj('Fotoğraf çekmeden kayıt yapılamaz.', 'hata'); return; }
      if (fotoModu === 'sor' && !confirm('Fotoğraf yok. Fotoğrafsız kaydedilsin mi?')) return;
    }
    const s = await kunyeKontrol(k.kunye_no);
    if (s === null) return;
    if (s.var && !confirm('Bu künye daha önce ' + s.adet + ' kez kaydedilmiş' + (s.cihaz ? ' (' + s.cihaz + ')' : '') + '. Yine de eklensin mi?')) return;
    k.foto = tamFoto;
    try {
      await kuyrukEkle(k);
    } catch (e) {
      mesaj('Kayıt telefonda saklanamadı: ' + e, 'hata');
      return;
    }
    localStorage.setItem('sayan', k.sayan);
    localStorage.setItem('birim', k.birim);
    formuTemizle($('#koru').checked);
    if (cevrimici) mesaj('Kaydedildi ✓ (gönderiliyor...)', 'tamam', 3000);
    else mesaj('Kaydedildi ✓ Telefonda saklandı; bağlantı gelince otomatik gönderilecek.', 'uyari', 4500);
    if (navigator.vibrate) navigator.vibrate(40);
    bekleyenGuncelle();
    gonder();
  } finally {
    kaydediyor = false;
    $('#kaydetBtn').disabled = false;
  }
}

async function tekGonder(k) {
  const fd = new FormData();
  fd.append('uuid', k.uuid);
  if (k.zaman) fd.append('istemci_zaman', zamanMetni(k.zaman));
  ALANLAR.forEach(a => fd.append(a, k[a] || ''));
  if (k.foto) fd.append('foto', k.foto, 'foto.jpg');
  let r;
  try {
    r = await fetch('/api/kayit', {method: 'POST', body: fd, credentials: 'same-origin'});
  } catch (e) {
    baglanti(false);
    const n = (await kuyrukHepsi()).filter(x => x.durum !== 'reddedildi').length;
    mesaj('Bağlantı yok; ' + n + ' kayıt bekliyor, bağlantı gelince otomatik gönderilecek.', 'uyari');
    return false;
  }
  baglanti(true);
  if (r.status === 401) { girisGoster(); return false; }
  const d = await r.json().catch(() => ({}));
  if (r.status === 400 || r.status === 413) {
    // Kayıt silinmez: telefonda "sorunlu" olarak kalır, kullanıcı listeden görüp yeniden deneyebilir veya silebilir
    k.durum = 'reddedildi';
    k.hata = d.hata || 'geçersiz kayıt';
    await kuyrukEkle(k);
    mesaj('Kayıt reddedildi (' + (k.kunye_no || k.cihaz_adi || '?') + '): ' + k.hata + '. "Son kayıtlarım" listesinden bakabilirsiniz.', 'hata', 9000);
    return true;
  }
  if (!r.ok) { mesaj('Sunucu hatası, daha sonra tekrar denenecek.', 'uyari'); return false; }
  await kuyrukSil(k.uuid);
  if (d.toplam !== undefined) toplamYaz(d.toplam);
  if (d.tekrar) mesaj('Gönderildi ✓ — DİKKAT: bu künye daha önce de kaydedilmiş (tekrar olarak işaretlendi).', 'uyari');
  else if (d.foto_hata) mesaj('Gönderildi ✓ — ancak fotoğraf işlenemedi, tekrar çekmeniz önerilir.', 'uyari');
  else mesaj('Gönderildi ✓ (' + (k.kunye_no || k.cihaz_adi || '') + ')', 'tamam', 3500);
  return true;
}

async function gonder() {
  if (gonderiyor) { tekrarIste = true; return; }   // gönderim sürerken eklenen kayıt kaçmasın
  gonderiyor = true;
  esitUygula();
  let gonderildi = false;
  try {
    do {
      tekrarIste = false;
      const liste = (await kuyrukHepsi()).filter(x => x.durum !== 'reddedildi').sort((a, b) => a.zaman - b.zaman);
      for (const k of liste) {
        if (!(await tekGonder(k))) { tekrarIste = false; break; }
        gonderildi = true;
      }
    } while (tekrarIste);
  } catch (e) {
    console.error(e);
  } finally {
    gonderiyor = false;
    bekleyenGuncelle();
    if (gonderildi) {
      try { if (!(await kuyrukHepsi()).some(x => x.durum !== 'reddedildi')) localStorage.setItem('sonEsit', String(Date.now())); } catch (e) {}
      esitUygula();
      if (tumAcikMi()) tumYukle();
    }
    if (gonderildi && $('#listeKutu').open) listeYenile();
  }
}

/* ---------- Son kayıtlarım ---------- */
function saatYaz(z) {
  if (typeof z === 'string') return z.slice(11, 16);
  try { return new Date(z).toTimeString().slice(0, 5); } catch (e) { return ''; }
}
function etiketEkle(kap, metin, sinif) {
  const s = document.createElement('span');
  s.className = 'etiket ' + sinif;
  s.textContent = metin;
  kap.appendChild(s);
}
async function listeYenile() {
  try {
    const r = await fetch('/api/son', {credentials: 'same-origin'});
    if (r.status === 401) { girisGoster(); return; }
    if (r.ok) {
      const d = await r.json();
      sonListe = d.liste || [];
      baglanti(true);
      if (d.toplam !== undefined) toplamYaz(d.toplam);
    }
  } catch (e) { baglanti(false); }
  let yerel = [];
  try { yerel = (await kuyrukHepsi()).sort((a, b) => b.zaman - a.zaman); } catch (e) {}
  const oge = yerel.map(k => ({tur: 'yerel', uuid: k.uuid, cihaz_adi: k.cihaz_adi, kunye_no: k.kunye_no, birim: k.birim,
                               zaman: k.zaman, durum: k.durum, hata: k.hata}))
    .concat(sonListe.map(s => ({tur: 'sunucu', uuid: s.uuid, cihaz_adi: s.cihaz_adi, kunye_no: s.kunye_no, birim: s.birim,
                                zaman: s.zaman, tekrar: s.tekrar})));
  $('#listeSayi').textContent = oge.length;
  const kap = $('#liste');
  kap.textContent = '';
  oge.forEach(o => {
    const div = document.createElement('div');
    div.className = 'oge';
    const bilgi = document.createElement('div');
    bilgi.className = 'bilgi';
    const b = document.createElement('b');
    b.textContent = o.cihaz_adi || '(adsız)';
    if (o.tur === 'yerel') etiketEkle(b, o.durum === 'reddedildi' ? 'REDDEDİLDİ' : 'BEKLİYOR', o.durum === 'reddedildi' ? 'red' : 'bekle');
    if (o.tekrar) etiketEkle(b, 'TEKRAR', 'tek');
    const kucuk = document.createElement('small');
    kucuk.textContent = [o.kunye_no, o.birim, saatYaz(o.zaman)].filter(Boolean).join(' · ') + (o.hata ? ' — ' + o.hata : '');
    bilgi.appendChild(b);
    bilgi.appendChild(kucuk);
    div.appendChild(bilgi);
    if (o.durum === 'reddedildi') {
      const t = document.createElement('button');
      t.textContent = '↻';
      t.setAttribute('aria-label', 'Yeniden dene');
      t.addEventListener('click', () => ogeTekrar(o));
      div.appendChild(t);
    }
    const sil = document.createElement('button');
    sil.textContent = '🗑';
    sil.setAttribute('aria-label', 'Sil');
    sil.addEventListener('click', () => ogeSil(o));
    div.appendChild(sil);
    kap.appendChild(div);
  });
  $('#listeNot').textContent = oge.length ? 'Yanlış kaydı 🗑 ile silebilirsiniz.' : 'Bu oturumda henüz kayıt yok.';
}
async function ogeSil(o) {
  if (!confirm((o.cihaz_adi || 'Kayıt') + ' (' + (o.kunye_no || '?') + ') silinsin mi?')) return;
  if (o.tur === 'yerel') {
    await kuyrukSil(o.uuid);
  } else {
    try {
      const r = await fetch('/api/geri_al', {
        method: 'POST', credentials: 'same-origin',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({uuid: o.uuid})
      });
      if (r.status === 401) { girisGoster(); return; }
      if (!r.ok) { mesaj('Silinemedi.', 'hata'); return; }
    } catch (e) {
      mesaj('Bağlantı yok, şimdi silinemez.', 'hata');
      return;
    }
    sonListe = sonListe.filter(x => x.uuid !== o.uuid);
  }
  mesaj('Kayıt silindi.', 'tamam', 3000);
  bekleyenGuncelle();
  listeYenile();
}
async function ogeTekrar(o) {
  const k = (await kuyrukHepsi()).find(x => x.uuid === o.uuid);
  if (!k) return;
  k.durum = 'bekliyor';
  delete k.hata;
  await kuyrukEkle(k);
  bekleyenGuncelle();
  listeYenile();
  gonder();
}

/* ---------- Olaylar ---------- */
$('#g_btn').addEventListener('click', girisYap);
$('#g_pin').addEventListener('keydown', e => { if (e.key === 'Enter') girisYap(); });
$('#kaydetBtn').addEventListener('click', kaydet);
$('#barkodBtn').addEventListener('click', barkodAc);
$('#tarayiciIptal').addEventListener('click', barkodKapat);
$('#tarayiciFoto').addEventListener('click', () => { barkodKapat(); $('#fotoGiris').click(); });
$('#fenerBtn').addEventListener('click', async () => {
  try {
    const iz = akim.getVideoTracks()[0];
    fener = !fener;
    await iz.applyConstraints({advanced: [{torch: fener}]});
    $('#fenerBtn').classList.toggle('acik', fener);
  } catch (e) {}
});
document.addEventListener('keydown', e => { if (e.key === 'Escape' && akim) barkodKapat(); });
document.addEventListener('visibilitychange', () => { if (document.hidden && akim) barkodKapat(); });
$('#pinGoster').addEventListener('click', () => {
  const g = $('#g_pin');
  const goster = g.type === 'password';
  g.type = goster ? 'text' : 'password';
  $('#pinGoster').setAttribute('aria-label', goster ? "PIN'i gizle" : "PIN'i göster");
});
$('#g_ad').addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); $('#g_pin').focus(); } });
ALANLAR.forEach(a => $('#' + a).addEventListener('input', () => $('#' + a).classList.remove('oto')));
/* Enter tuşu bir sonraki alana geçsin; son alanda klavye kapansın */
const SIRA = ['kunye_no', 'seri_no', 'cihaz_adi', 'marka', 'model', 'birim', 'sayan'];
SIRA.forEach((a, i) => {
  if (a === 'kunye_no') return;           // künye: el tipi barkod okuyucu için ayrı işlenir
  $('#' + a).addEventListener('keydown', e => {
    if (e.key !== 'Enter') return;
    e.preventDefault();
    if (i + 1 < SIRA.length) $('#' + SIRA[i + 1]).focus(); else e.target.blur();
  });
});
/* Telefonda klavye gerçekten açıkken (görünür alan küçülünce) alt çubuk alanları kapatmasın */
let tabanYuk = 0;
function klavyeKontrol() {
  const vv = window.visualViewport;
  const yuk = vv ? vv.height : window.innerHeight;
  if (!tabanYuk || yuk > tabanYuk) tabanYuk = yuk;
  document.body.classList.toggle('yaziyor', DOKUNMATIK && (tabanYuk - yuk) > 150);
}
if (window.visualViewport) window.visualViewport.addEventListener('resize', klavyeKontrol);
window.addEventListener('resize', klavyeKontrol);
window.addEventListener('orientationchange', () => { tabanYuk = 0; setTimeout(klavyeKontrol, 400); });
klavyeKontrol();
/* Ana ekrana ekleme ipucu: Android (yükleme penceresi) ve iOS (Paylaş menüsü) */
let kurulumIstegi = null;
function kurulumAc(metin, yukleDugmesi) {
  if (localStorage.getItem('kurulumKapat') || UYGULAMA_MODU) return;
  $('#kurulumMetin').textContent = metin;
  $('#kurulumBtn').classList.toggle('gizli', !yukleDugmesi);
  $('#kurulum').classList.remove('gizli');
}
window.addEventListener('beforeinstallprompt', e => {
  e.preventDefault();
  kurulumIstegi = e;
  kurulumAc('Uygulama gibi tek dokunuşla açılır.', true);
});
if (IOS && !UYGULAMA_MODU) kurulumAc('Tarayıcının Paylaş menüsünden “Ana Ekrana Ekle”yi seçin.', false);
$('#kurulumBtn').addEventListener('click', async () => {
  if (!kurulumIstegi) return;
  kurulumIstegi.prompt();
  try { await kurulumIstegi.userChoice; } catch (e) {}
  kurulumIstegi = null;
  $('#kurulum').classList.add('gizli');
});
$('#kurulumKapat').addEventListener('click', () => { localStorage.setItem('kurulumKapat', '1'); $('#kurulum').classList.add('gizli'); });
$('#fotoBtn').addEventListener('click', () => $('#fotoGiris').click());
$('#fotoSil').addEventListener('click', fotoTemizle);
$('#koru').addEventListener('change', e => localStorage.setItem('koru', e.target.checked ? '1' : '0'));
$('#kunye_no').addEventListener('input', () => { $('#kunye_no').classList.remove('hatali'); kunyeCanli(); });
$('#cihaz_adi').addEventListener('input', () => $('#cihaz_adi').classList.remove('hatali'));
$('#kunye_no').addEventListener('keydown', e => {
  // el tipi barkod okuyucular okuma sonunda Enter gönderir: cihaz adı doluysa doğrudan kaydet
  if (e.key !== 'Enter') return;
  e.preventDefault();
  if ($('#cihaz_adi').value.trim() && $('#kunye_no').value.trim()) kaydet(); else $('#cihaz_adi').focus();
});
$('#listeKutu').addEventListener('toggle', e => { if (e.target.open) listeYenile(); });
$('#fotoGiris').addEventListener('change', async e => {
  const f = e.target.files[0];
  if (!f) return;
  try {
    tamFoto = await kucult(f, 1280);
    $('#onizleme').src = URL.createObjectURL(tamFoto);
    $('#onizlemeKap').classList.remove('gizli');
    $('#fotoBtn').textContent = '📸 Fotoğrafı Yeniden Çek';
    fotoOku(f).catch(() => {});                  // etiketteki QR / künye fotoğraftan okunur
  } catch (err) {
    tamFoto = null;
    mesaj('Fotoğraf işlenemedi, tekrar deneyin.', 'hata');
  }
});
$('#cikis').addEventListener('click', async e => {
  e.preventDefault();
  try { await fetch('/api/cikis', {method: 'POST', credentials: 'same-origin'}); } catch (x) {}
  localStorage.removeItem('girisYapildi');
  tumListe = [];
  girisGoster();
});

/* ---------- Tüm kayıtlar ekranı (Android + iOS; yalnızca görüntüleme) ---------- */
let tumListe = [];        // çevrimiçi: sunucunun süzüp sayfaladığı kayıtlar; çevrimdışı: önbellekteki son liste
let tumYerel = [];        // telefonda bekleyen kayıtlar
let tumFiltre = 'hepsi';
let tumAdet = 60;         // yalnızca çevrimdışı kipte: ekranda gösterilen sayı
let tumToplam = 0;        // sunucudaki tüm kayıt
let tumFiltreli = 0;      // süzgece uyan kayıt (sunucuda sayılır)
let tumSayac = {};
let tumCevrimdisi = false;
let tumIstekNo = 0;       // eski (geç dönen) yanıtlar yenisini ezmesin
const TUM_ADIM = 60;
function tumNorm(s) {
  return String(s == null ? '' : s).toLocaleLowerCase('tr').replace(/\u0131/g, 'i').normalize('NFD').replace(/[\u0300-\u036f]/g, '');
}
function tumAcikMi() { return !$('#tum').classList.contains('gizli'); }
function tumAc() {
  $('#tum').classList.remove('gizli');
  document.body.classList.add('tum-acik');
  try { history.pushState({tum: 1}, ''); } catch (e) {}
  tumYukle();
}
function tumGizle() {
  $('#tum').classList.add('gizli');
  document.body.classList.remove('tum-acik');
}
function tumKapat() {
  if (history.state && history.state.tum) { history.back(); return; }
  tumGizle();
}
async function yerelYukle() {
  try {
    const l = (await kuyrukHepsi()).sort((a, b) => b.zaman - a.zaman);
    tumYerel = l.map(k => ({id: null, yerel: true, durum: k.durum || 'bekliyor', hata: k.hata || '', uuid: k.uuid,
      zaman: zamanMetni(k.zaman), cihaz_adi: k.cihaz_adi, kunye_no: k.kunye_no, seri_no: k.seri_no, marka: k.marka,
      model: k.model, birim: k.birim, sayan: k.sayan, foto: !!k.foto, _foto: k.foto, tekrar: false, benim: true, bugun: true}));
  } catch (e) { tumYerel = []; }
}
async function tumYukle(devam) {
  devam = devam === true;                       // true: aynı süzgeçle bir sonraki sayfayı ekle
  const no = ++tumIstekNo;
  if (!devam) $('#tumSayac').textContent = 'Yükleniyor…';
  await yerelYukle();
  if (no !== tumIstekNo) return;
  let not = '';
  const q = $('#tumAra').value.trim();
  try {
    const ps = new URLSearchParams({limit: tumFiltre === 'bekleyen' ? 0 : TUM_ADIM, offset: devam ? tumListe.length : 0,
      q: q, f: tumFiltre === 'bekleyen' ? 'hepsi' : tumFiltre});
    const r = await fetch('/api/tum?' + ps.toString(), {credentials: 'same-origin'});
    if (no !== tumIstekNo) return;
    if (r.status === 401) { tumGizle(); girisGoster(); return; }
    if (!r.ok) throw new Error('http');
    const d = await r.json();
    if (no !== tumIstekNo) return;
    const gelen = d.liste || [];
    if (devam) {
      const var_ = new Set(tumListe.map(k => k.id));
      gelen.forEach(k => { if (!var_.has(k.id)) tumListe.push(k); });
    } else {
      tumListe = gelen;
    }
    tumCevrimdisi = false;
    tumToplam = d.toplam || 0;
    tumFiltreli = d.filtreli || 0;
    tumSayac = d.sayac || {};
    baglanti(true);
    toplamYaz(tumToplam);
    if (!q && tumFiltre === 'hepsi') {          // çevrimdışı kullanım için süzgeçsiz listeyi (en çok 500) sakla
      try { localStorage.setItem('tumOnbellek', JSON.stringify({z: Date.now(), liste: tumListe.slice(0, 500), toplam: tumToplam, sayac: tumSayac})); } catch (e) {}
    }
  } catch (e) {
    if (no !== tumIstekNo) return;
    baglanti(false);
    tumCevrimdisi = true;
    let z = 0;
    try {
      const c = JSON.parse(localStorage.getItem('tumOnbellek') || 'null');
      if (c && c.liste) { tumListe = c.liste; z = c.z; tumToplam = c.toplam || c.liste.length; tumSayac = c.sayac || {}; }
    } catch (x) {}
    not = '📴 Çevrimdışı — ' + (tumListe.length ? 'sunucu listesi ' + (z ? saatMetni(z) + ' itibarıyla (son yüklenen)' : 'son yüklenen') +
          '; telefondaki bekleyenler en üstte.' : 'sunucu listesi yüklenemedi, yalnızca telefondaki bekleyenler görünüyor.');
  }
  const tn = $('#tumNot');
  tn.textContent = not;
  tn.classList.toggle('gizli', !not);
  $('#iToplam').textContent = tumCevrimdisi ? (tumToplam || tumListe.length) : tumToplam;
  $('#iBugun').textContent = tumSayac.bugun !== undefined ? tumSayac.bugun : tumListe.filter(k => k.bugun).length;
  $('#iTekrar').textContent = tumSayac.tekrar !== undefined ? tumSayac.tekrar : tumListe.filter(k => k.tekrar).length;
  $('#iBekleyen').textContent = tumYerel.length;
  tumAdet = TUM_ADIM;
  tumCiz();
}
function tumSuz(liste) {
  const q = tumNorm($('#tumAra').value).trim();
  return liste.filter(k => {
    if (tumFiltre === 'bekleyen' && !k.yerel) return false;
    if (tumFiltre === 'benim' && !k.benim) return false;
    if (tumFiltre === 'bugun' && !k.bugun) return false;
    if (tumFiltre === 'tekrar' && !k.tekrar) return false;
    if (tumFiltre === 'fotosuz' && k.foto) return false;
    if (!q) return true;
    return tumNorm([k.cihaz_adi, k.kunye_no, k.seri_no, k.marka, k.model, k.birim, k.sayan, k.id].join(' ')).indexOf(q) >= 0;
  });
}
function tumSatir(k) {
  const div = document.createElement('div');
  div.className = 'tkayit' + (k.tekrar ? ' tek' : '') + (k.benim ? ' benim' : '') + (k.yerel ? ' yerel' : '');
  const ust = document.createElement('div');
  ust.className = 'ust';
  const ad = document.createElement('div');
  ad.className = 'ad';
  ad.textContent = k.cihaz_adi || '(adsız)';
  const no = document.createElement('div');
  no.className = 'no';
  no.textContent = k.yerel ? '⏳' : '#' + k.id;
  ust.appendChild(ad);
  ust.appendChild(no);
  const kun = document.createElement('div');
  kun.className = 'kun';
  kun.textContent = k.kunye_no || '-';
  const alt = document.createElement('div');
  alt.className = 'alt';
  alt.textContent = [k.birim, k.sayan, k.zaman ? String(k.zaman).slice(0, 16) : ''].filter(Boolean).join(' · ');
  const rz = document.createElement('div');
  rz.className = 'rozetler';
  const rozet = (m, c) => { const s = document.createElement('span'); s.className = 'rz ' + c; s.textContent = m; rz.appendChild(s); };
  if (k.yerel) rozet(k.durum === 'reddedildi' ? '⚠ SORUNLU' : '⏳ TELEFONDA BEKLİYOR', k.durum === 'reddedildi' ? 'red' : 'bekle');
  else if (k.benim) rozet('BENİM', 'benim');
  if (k.tekrar) rozet('⚠ TEKRAR', 'tek');
  rozet(k.foto ? '📷 Fotoğraflı' : 'Fotoğrafsız', k.foto ? 'foto' : '');
  const det = document.createElement('div');
  det.className = 'detay';
  [['Seri no', k.seri_no], ['Marka / Model', [k.marka, k.model].filter(Boolean).join(' / ')],
   ['Birim/Oda', k.birim], ['Sayımı yapan', k.sayan], ['Zaman', k.zaman]].concat(k.hata ? [['Hata', k.hata]] : []).forEach(([e, v]) => {
    const r = document.createElement('div');
    const sp = document.createElement('span');
    sp.textContent = e + ': ';
    r.appendChild(sp);
    r.appendChild(document.createTextNode(v || '-'));
    det.appendChild(r);
  });
  if ((k.benim || k.yerel) && k.uuid) {
    const sb = document.createElement('button');
    sb.type = 'button';
    sb.className = 'ikincil';
    sb.textContent = '🗑 Sil';
    sb.style.marginTop = '10px';
    sb.addEventListener('click', ev => {
      ev.stopPropagation();
      ogeSil({tur: k.yerel ? 'yerel' : 'sunucu', uuid: k.uuid, cihaz_adi: k.cihaz_adi, kunye_no: k.kunye_no})
        .then(() => { if (tumAcikMi()) tumYukle(); });
    });
    det.appendChild(sb);
  }
  div.appendChild(ust);
  div.appendChild(kun);
  div.appendChild(alt);
  div.appendChild(rz);
  div.appendChild(det);
  div.addEventListener('click', () => {
    div.classList.toggle('ac');
    if (div.classList.contains('ac') && k.foto && !det.querySelector('img')) {
      const im = document.createElement('img');
      im.alt = 'Cihaz fotoğrafı';
      im.loading = 'lazy';
      im.addEventListener('error', () => im.remove());
      im.src = k.yerel ? URL.createObjectURL(k._foto) : '/foto/' + k.id;
      det.appendChild(im);
    }
  });
  return div;
}
function tumCiz() {
  const yerel = tumSuz(tumYerel);                         // telefondaki bekleyenler her zaman istemcide süzülür
  let sunucu, uyan;
  if (tumCevrimdisi) { sunucu = tumSuz(tumListe); uyan = sunucu.length; }
  else if (tumFiltre === 'bekleyen') { sunucu = []; uyan = 0; }
  else { sunucu = tumListe; uyan = tumFiltreli; }       // çevrimiçi: sunucu zaten süzdü ve sayfaladı
  const hepsi = yerel.concat(sunucu);
  const goster = tumCevrimdisi ? hepsi.slice(0, tumAdet) : hepsi;
  const kap = $('#tumListe');
  kap.textContent = '';
  goster.forEach(k => kap.appendChild(tumSatir(k)));
  if (!hepsi.length) {
    const b = document.createElement('div');
    b.className = 'bos';
    b.textContent = (tumToplam || tumListe.length || tumYerel.length) ? 'Bu süzgece uyan kayıt yok.' : 'Henüz kayıt yok.';
    kap.appendChild(b);
  }
  $('#tumSayac').textContent = goster.length + ' / ' + (yerel.length + uyan) + ' kayıt gösteriliyor (en yeni üstte)';
  const kalan = tumCevrimdisi ? hepsi.length - tumAdet : uyan - sunucu.length;
  const daha = $('#tumDaha');
  daha.classList.toggle('gizli', kalan <= 0);
  daha.textContent = 'Daha fazla göster (' + Math.max(kalan, 0) + ' kayıt daha)';
}
$('#tumBtn').addEventListener('click', tumAc);
$('#tumKapat').addEventListener('click', tumKapat);
$('#tumYenile').addEventListener('click', () => tumYukle());
$('#tumDaha').addEventListener('click', () => { if (tumCevrimdisi) { tumAdet += TUM_ADIM; tumCiz(); } else tumYukle(true); });
let tumAraZ = null;
$('#tumAra').addEventListener('input', () => { clearTimeout(tumAraZ); tumAraZ = setTimeout(() => { tumAdet = TUM_ADIM; tumYukle(); }, 300); });
$('#tumCipler').addEventListener('click', e => {
  const b = e.target.closest('button[data-f]');
  if (!b) return;
  tumFiltre = b.dataset.f;
  document.querySelectorAll('#tumCipler button').forEach(x => x.classList.toggle('secili', x === b));
  tumAdet = TUM_ADIM;
  tumYukle();
});
window.addEventListener('popstate', () => { if (tumAcikMi()) tumGizle(); });
document.addEventListener('keydown', e => { if (e.key === 'Escape' && tumAcikMi()) tumKapat(); });
$('#esitBtn').addEventListener('click', esitle);
window.addEventListener('online', () => { baglantiDene(false).then(ok => { if (ok) gonder(); }); });
window.addEventListener('offline', () => baglanti(false));
setInterval(gonder, 15000);
setInterval(() => { if (!document.hidden && !gonderiyor) baglantiDene(false); }, 20000);   // gerçek bağlantı durumu (tünel/sunucu dahil)
document.addEventListener('visibilitychange', () => { if (!document.hidden) baglantiDene(false).then(ok => { if (ok) gonder(); }); });
if (navigator.storage && navigator.storage.persist) navigator.storage.persist().catch(() => {});   // tarayıcı bekleyen kayıtları kendiliğinden silmesin

if ('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js').catch(() => {});
baglanti(navigator.onLine);
bekleyenGuncelle();
durumKontrol();
</script>
</body>
</html>
'''

SERVICE_WORKER = r'''const C = 'sayim-v9';
self.addEventListener('install', e => { e.waitUntil(caches.open(C).then(c => c.add('/')).catch(() => {})); self.skipWaiting(); });
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(k => Promise.all(k.filter(x => x !== C).map(x => caches.delete(x)))).then(() => clients.claim()));
});
self.addEventListener('fetch', e => {
  const u = new URL(e.request.url);
  if (e.request.mode === 'navigate' && u.pathname === '/') {
    e.respondWith(fetch(e.request).then(r => {
      const kopya = r.clone();
      caches.open(C).then(c => c.put('/', kopya));
      return r;
    }).catch(() => caches.match('/')));
  }
});
'''


# ----------------------------------------------------------------------------
# FLASK UYGULAMASI (internete açılan tek şey: form + kayıt uç noktaları)
# ----------------------------------------------------------------------------
def ikon_png(boyut):
    """Telefonda 'Ana ekrana ekle' için basit uygulama simgesi (dosya gerektirmez, çalışırken üretilir)."""
    s = 512
    im = Image.new("RGB", (s, s), "#0b5ed7")
    d = ImageDraw.Draw(im)
    d.rounded_rectangle((120, 80, 392, 432), 36, fill="white")
    d.rounded_rectangle((200, 56, 312, 120), 20, fill="#084298")
    for y in (170, 250, 330):
        d.rounded_rectangle((158, y, 202, y + 44), 10, fill="#0b5ed7")
        d.rounded_rectangle((226, y + 10, 356, y + 34), 12, fill="#b8c2d1")
    if boyut != s:
        im = im.resize((boyut, boyut), Image.LANCZOS)
    b = io.BytesIO()
    im.save(b, "PNG", optimize=True)
    return b.getvalue()


def uygulama_olustur(depo, ayar):
    app = Flask(__name__)
    app.secret_key = ayar["gizli_anahtar"]
    app.config.update(
        MAX_CONTENT_LENGTH=12 * 1024 * 1024,
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Lax",
        PERMANENT_SESSION_LIFETIME=12 * 3600,
    )
    siniri = HizSiniri()                              # IP başına: 5 hatalı denemede 5 dk bekletir
    genel_sinir = HizSiniri(deneme=40, bekleme=300)   # tüm dünya için: dağıtık PIN denemesini yavaşlatır
    uuid_re = re.compile(r"^[0-9A-Za-z-]{16,64}$")
    ikonlar = {}
    guven_ser = URLSafeTimedSerializer(ayar["gizli_anahtar"], salt="tanidik-cihaz")
    TANIDIK_SURE = 30 * 86400

    def tanidik_cihaz():
        """Bu telefon daha önce doğru PIN ile girmiş mi? (imzalı çerez; 'Tüm oturumları kapat' bunu da geçersiz kılar)"""
        t = request.cookies.get("tc")
        if not t:
            return False
        try:
            guven_ser.loads(t, max_age=TANIDIK_SURE)
            return True
        except Exception:
            return False

    @app.before_request
    def access_denetimi():
        """Cloudflare Access açıksa tünelden gelen her istekte Access başlığı bulunmalı (ek güvenlik; asıl denetim Cloudflare'dedir).
        Doğrudan bu bilgisayardan ya da yerel ağdan gelen istekler etkilenmez."""
        if not ayar.get("access_zorunlu"):
            return None
        if request.remote_addr in ("127.0.0.1", "::1") and request.headers.get("CF-Connecting-IP"):
            if not (request.headers.get("Cf-Access-Jwt-Assertion") or request.headers.get("Cf-Access-Authenticated-User-Email")):
                return Response("Bu adrese yalnızca Cloudflare Access girişiyle erişilebilir.", status=403,
                                mimetype="text/plain; charset=utf-8")
        return None

    def pin_parmak():
        return hashlib.sha256((str(ayar["pin"]) + ayar["gizli_anahtar"]).encode()).hexdigest()[:12]

    def istemci_ip():
        # CF-Connecting-IP başlığına yalnızca istek bu bilgisayardaki cloudflared'den geldiyse güvenilir;
        # yoksa yerel ağdaki biri başlığı taklit ederek deneme sınırını atlatabilirdi.
        if request.remote_addr in ("127.0.0.1", "::1"):
            return request.headers.get("CF-Connecting-IP") or request.remote_addr
        return request.remote_addr or "?"

    def giris_gerekli(f):
        from functools import wraps

        @wraps(f)
        def sar(*a, **kw):
            if not session.get("ok") or session.get("pv") != pin_parmak():
                return jsonify(hata="giris"), 401
            return f(*a, **kw)
        return sar

    def kullanici_listesi():
        return [ad_norm(x) for x in re.split(r"[,\n;]", ayar.get("kullanicilar", "") or "") if x.strip()]

    @app.after_request
    def basliklar(r):
        r.headers["X-Content-Type-Options"] = "nosniff"
        r.headers["X-Frame-Options"] = "DENY"
        r.headers["Referrer-Policy"] = "no-referrer"
        r.headers["Permissions-Policy"] = "camera=(self), microphone=()"
        r.headers["Content-Security-Policy"] = (
            "default-src 'self'; img-src 'self' data: blob:; style-src 'self' 'unsafe-inline'; "
            "script-src 'self' 'unsafe-inline'; media-src 'self' blob:; connect-src 'self'; worker-src 'self'")
        if request.path.startswith("/api/"):
            r.headers["Cache-Control"] = "no-store"
        return r

    @app.errorhandler(413)
    def cok_buyuk(e):
        return jsonify(hata="Dosya çok büyük"), 413

    @app.errorhandler(Exception)
    def genel_hata(e):
        from werkzeug.exceptions import HTTPException
        if isinstance(e, HTTPException):
            return jsonify(hata=e.description), e.code
        log.exception("İstek hatası: %s", e)
        return jsonify(hata="Sunucu hatası"), 500

    @app.get("/")
    def ana():
        html = HTML
        if not str(ayar.get("pin", "")).isdigit():     # harfli PIN: telefonda sayısal tuş takımı yerine normal klavye açılsın
            html = html.replace('id="g_pin" type="password" inputmode="numeric"', 'id="g_pin" type="password" inputmode="text"')
        return Response(html, mimetype="text/html")

    @app.get("/sw.js")
    def sw():
        r = Response(SERVICE_WORKER, mimetype="application/javascript")
        r.headers["Cache-Control"] = "no-cache"
        return r

    @app.get("/manifest.json")
    def manifest():
        m = {"name": "Hastane Sayım", "short_name": "Sayım", "start_url": "/", "scope": "/",
             "display": "standalone", "lang": "tr", "background_color": "#f1f4f9", "theme_color": "#0b5ed7",
             "icons": [{"src": "/icon-192.png", "sizes": "192x192", "type": "image/png"},
                       {"src": "/icon-512.png", "sizes": "512x512", "type": "image/png"}]}
        return Response(json.dumps(m), mimetype="application/manifest+json")

    @app.get("/icon-<int:boyut>.png")
    def ikon(boyut):
        if boyut not in (192, 512):
            return jsonify(hata="Bulunamadı"), 404
        if boyut not in ikonlar:
            ikonlar[boyut] = ikon_png(boyut)
        r = Response(ikonlar[boyut], mimetype="image/png")
        r.headers["Cache-Control"] = "public, max-age=86400"
        return r

    @app.get("/api/durum")
    def durum():
        ok = bool(session.get("ok")) and session.get("pv") == pin_parmak()
        return jsonify(giris=ok, ad=session.get("ad", "") if ok else "", foto_modu=ayar.get("foto_modu", "sor"))

    @app.post("/api/giris")
    def giris():
        ip = istemci_ip()
        # Genel kilit dağıtık PIN denemesini yavaşlatır; ama internetten biri 40 yanlış denemeyle herkesi dışarıda bırakmasın diye
        # daha önce doğru PIN'le girmiş (imzalı çerezli) telefonlar genel kilitten muaftır (IP başına sınır ve PIN yine geçerli).
        bekle = max(siniri.kalan(ip), 0 if tanidik_cihaz() else genel_sinir.kalan("*"))
        if bekle:
            return jsonify(hata=f"Çok fazla hatalı deneme. {bekle} sn sonra tekrar deneyin."), 429
        d = request.get_json(silent=True) or {}
        ad = temiz(d.get("ad"), 60)
        pin = str(d.get("pin", ""))
        liste = kullanici_listesi()
        pin_ok = hmac.compare_digest(pin.encode(), str(ayar["pin"]).encode())
        ad_ok = bool(ad) and (not liste or ad_norm(ad) in liste)     # İsmail = ismail = İSMAİL, IŞIK = ışık
        if not (pin_ok and ad_ok):
            siniri.hata(ip)
            genel_sinir.hata("*")
            log.warning("Hatalı giriş denemesi: ip=%s ad=%s", ip, ad)
            return jsonify(hata="Ad veya PIN hatalı"), 401
        siniri.temizle(ip)
        cihaz = temiz(d.get("cihaz"), 64)
        if uuid_re.match(cihaz):
            # aynı telefon + aynı ad yeniden girişte aynı kimliği alır: "Son kayıtlarım", "BENİM" ve geri alma sürer
            sid = "d" + hashlib.sha256((cihaz + "|" + ad.lower()).encode("utf-8")).hexdigest()[:31]
        else:
            sid = uuid.uuid4().hex      # eski/önbellekteki sayfa: önceki davranış
        session.clear()
        session.permanent = True
        session.update(ok=True, ad=ad, sid=sid, pv=pin_parmak())
        em = temiz(request.headers.get("Cf-Access-Authenticated-User-Email"), 120)
        log.info("Giriş: %s (%s)%s", ad, ip, f" access={em}" if em else "")
        yanit = jsonify(ok=True, ad=ad, foto_modu=ayar.get("foto_modu", "sor"))
        https = request.headers.get("X-Forwarded-Proto", "").lower() == "https" or request.is_secure
        yanit.set_cookie("tc", guven_ser.dumps(1), max_age=TANIDIK_SURE, httponly=True, samesite="Lax", secure=https)
        return yanit

    @app.post("/api/cikis")
    def cikis():
        session.clear()
        return jsonify(ok=True)

    @app.get("/api/oneriler")
    @giris_gerekli
    def oneriler():
        d = depo.oneriler()
        d["toplam"] = depo.sayi()
        return jsonify(d)

    @app.get("/api/son")
    @giris_gerekli
    def son():
        return jsonify(liste=depo.son_kayitlar(session.get("sid")), toplam=depo.sayi())

    @app.get("/api/tum")
    @giris_gerekli
    def tum():
        if "limit" not in request.args:                 # eski istemci: tüm liste (geriye dönük uyumluluk)
            liste = depo.tum_kayitlar(session.get("sid"))
            return jsonify(liste=liste, toplam=len(liste))
        try:
            limit = max(0, min(int(request.args.get("limit", 60)), 500))
            offset = max(0, int(request.args.get("offset", 0)))
        except ValueError:
            return jsonify(hata="Geçersiz sayfa bilgisi"), 400
        f = request.args.get("f", "hepsi")
        if f not in ("hepsi", "benim", "bugun", "tekrar", "fotosuz"):
            f = "hepsi"
        return jsonify(**depo.tum_sayfa(session.get("sid"), limit, offset, request.args.get("q", "")[:100], f))

    @app.get("/foto/<int:kid>")
    @giris_gerekli
    def foto_ver(kid):
        k = depo.al(kid)
        ad = os.path.basename(str(k.get("foto") or "")) if k else ""
        yol = os.path.join(depo.foto_klasoru, ad) if ad else ""
        if not ad or not os.path.isfile(yol):
            return jsonify(hata="Fotoğraf yok"), 404
        r = send_file(yol, mimetype="image/jpeg", max_age=3600)
        r.headers["Cache-Control"] = "private, max-age=3600"
        return r

    @app.get("/api/kontrol")
    @giris_gerekli
    def kontrol():
        return jsonify(depo.kontrol(temiz(request.args.get("kunye"), 100)))

    @app.post("/api/kayit")
    @giris_gerekli
    def kayit():
        f = request.form
        u = temiz(f.get("uuid"), 64)
        if not uuid_re.match(u):
            return jsonify(hata="Geçersiz kayıt kimliği"), 400
        alan = {
            "uuid": u,
            "marka": temiz(f.get("marka")), "model": temiz(f.get("model")),
            "cihaz_adi": temiz(f.get("cihaz_adi")), "kunye_no": temiz(f.get("kunye_no"), 100),
            "seri_no": temiz(f.get("seri_no"), 100),
            "birim": temiz(f.get("birim")), "sayan": session.get("ad", "") or temiz(f.get("sayan"), 60),   # sayımı yapan = giriş yapan kişi (istekle değiştirilemez)
        }
        iz = temiz(f.get("istemci_zaman"), 19)
        alan["istemci_zaman"] = iz if re.fullmatch(r"\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}", iz) else ""
        if not alan["cihaz_adi"]:
            return jsonify(hata="Cihaz adı zorunlu"), 400
        foto = request.files.get("foto")
        if foto is None and ayar.get("foto_modu") == "zorunlu":
            return jsonify(hata="Fotoğraf zorunlu"), 400
        k, yeni, tekrar, foto_hata = depo.ekle(alan, foto, session.get("sid"))
        return jsonify(ok=True, id=k["id"], yeni=yeni, tekrar=tekrar, foto_hata=foto_hata, toplam=depo.sayi())

    @app.post("/api/qr_coz")
    @giris_gerekli
    def qr_coz_api():
        d = request.get_json(silent=True) or {}
        ham = str(d.get("ham") or "")[:2000]
        if not ham.strip():
            return jsonify(hata="QR içeriği boş"), 400
        izinli = alan_adi_listesi(ayar.get("qr_izinli_siteler", ""))
        sonuc = qr_coz(ham, izinli, str(ayar.get("qr_sayfa_sablonu") or ""))
        log.info("QR çözüldü: kaynak=%s alanlar=%s ham=%s", sonuc["kaynak"] or "-", ",".join(sonuc["alanlar"]) or "-", ham[:150])
        return jsonify(sonuc)

    @app.post("/api/foto_oku")
    @giris_gerekli
    def foto_oku_api():
        f = request.files.get("foto")
        if f is None:
            return jsonify(hata="Fotoğraf yok"), 400
        veri = f.read(MAX_FOTO + 1)
        if len(veri) > MAX_FOTO:
            return jsonify(hata="Fotoğraf çok büyük"), 413
        izinli = alan_adi_listesi(ayar.get("qr_izinli_siteler", ""))
        sonuc = foto_oku(veri, izinli, str(ayar.get("qr_sayfa_sablonu") or ""))
        log.info("Fotoğraf okundu: yontem=%s alanlar=%s uyari=%s", sonuc["yontem"] or "-", ",".join(sonuc["alanlar"]) or "-", sonuc["uyari"][:80])
        return jsonify(sonuc)

    @app.post("/api/geri_al")
    @giris_gerekli
    def geri_al():
        d = request.get_json(silent=True) or {}
        u = temiz(d.get("uuid"), 64)
        if not uuid_re.match(u):
            return jsonify(hata="Geçersiz kimlik"), 400
        if not depo.sil(uuid_=u, oturum=session.get("sid")):
            return jsonify(hata="Kayıt bulunamadı veya size ait değil"), 404
        return jsonify(ok=True, toplam=depo.sayi())

    return app


# ----------------------------------------------------------------------------
# SUNUCU VE TÜNEL YÖNETİMİ
# ----------------------------------------------------------------------------
class Sunucu:
    def __init__(self):
        self.srv = None
        self.thread = None

    @property
    def calisiyor(self):
        return self.srv is not None

    def baslat(self, app, host, port):
        self.srv = make_server(host, port, app, threaded=True)   # port doluysa OSError fırlatır
        self.thread = threading.Thread(target=self.srv.serve_forever, daemon=True)
        self.thread.start()
        log.info("Sunucu başladı %s:%s", host, port)

    def durdur(self):
        if self.srv:
            try:
                self.srv.shutdown()
                self.srv.server_close()
            except Exception as e:
                log.error("Sunucu durdurulurken hata: %s", e)
            self.srv = None
            log.info("Sunucu durdu")


class Tunel:
    URL_RE = re.compile(r"https://[a-z0-9-]+\.trycloudflare\.com")

    def __init__(self):
        self.url = ""
        self.durum = "kapalı"
        self.hata = ""
        self.uyari = ""          # hata değil, bilgi: örn. tünel aracı çok eski
        self.istenen = False
        self.proc = None
        self.thread = None
        self.ayar = {}
        self._nesil = 0          # her başlat/durdur'da artar: eski iş parçacığı yeni çalışmanın durumunu bozamaz

    @staticmethod
    def exe_bul_ayrinti(ekstra, ayar=None):
        """Kullanılacak cloudflared'i bulur. Dönüş: (yol, kaynak). kaynak: ozel / gomulu / klasor / sistem / ''.
        Sıra: kullanıcının seçtiği dosya (seçildiyse) -> gömülü sürüm -> program klasöründeki cloudflared.exe -> PATH."""
        ayar = ayar or {}
        ozel = str(ayar.get("cloudflared_ozel") or "")
        if ayar.get("cloudflared_kaynak") == "ozel":
            if ozel and os.path.isfile(ozel):
                return ozel, "ozel"
            log.warning("Seçilen cloudflared dosyası bulunamadı (%s); gömülü sürüme dönülüyor", ozel)
        g = gomulu_cikar()
        if g:
            return g, "gomulu"
        adlar = ["cloudflared.exe", "cloudflared"]
        for klasor in ekstra:
            for ad in adlar:
                yol = os.path.join(klasor, ad)
                if os.path.isfile(yol):
                    return yol, "klasor"
        for ad in adlar:
            yol = shutil.which(ad)
            if yol:
                return yol, "sistem"
        return None, ""

    @staticmethod
    def exe_bul(ekstra, ayar=None):
        return Tunel.exe_bul_ayrinti(ekstra, ayar)[0]

    def baslat(self, port, protokol, ekstra_klasorler, ayar=None):
        self._nesil += 1
        nesil = self._nesil
        self.istenen = True
        self.hata = ""
        self.uyari = ""
        self.ayar = ayar if ayar is not None else {}
        self.thread = threading.Thread(target=self._calistir, args=(port, protokol, ekstra_klasorler, nesil), daemon=True)
        self.thread.start()

    def _gecerli(self, nesil):
        """Bu iş parçacığı hâlâ güncel çalışmaya mı ait? (Durdur -> hemen Başlat yapılınca eskisi sessizce çekilmeli.)"""
        return self.istenen and nesil == self._nesil

    _surum_onbellek = {}      # (exe yolu, kaynak) -> uyarı: --version her yeniden bağlanmada çalıştırılmasın

    @classmethod
    def surum_uyarisi(cls, exe, kaynak):
        anahtar = (exe, kaynak)
        if anahtar not in cls._surum_onbellek:
            try:
                surum = GOMULU_SURUM if kaynak == "gomulu" else cloudflared_surum(exe, 6)[0]
                cls._surum_onbellek[anahtar] = eski_surum_uyarisi(surum)
            except Exception:
                cls._surum_onbellek[anahtar] = ""
        return cls._surum_onbellek[anahtar]

    def _calistir(self, port, protokol, ekstra, nesil=None):
        if nesil is None:
            nesil = self._nesil
        ayar_ = getattr(self, "ayar", None) or {}
        sabit = ayar_.get("tunel_modu") == "sabit"
        ortam, sabit_url = None, ""
        if sabit:
            hata_ = sabit_tunel_hatasi(ayar_)
            if hata_:
                if self._gecerli(nesil):
                    self.durum = "sabit tünel ayarı eksik"
                    self.hata = hata_
                    self.istenen = False
                return
            ortam = dict(os.environ, TUNNEL_TOKEN=token_ayikla(ayar_.get("sabit_tunel_token")))   # anahtar komut satırında görünmesin
            sabit_url = sabit_adres_duzelt(ayar_.get("sabit_adres"))
        while self._gecerli(nesil):
            self.durum = "tünel aracı hazırlanıyor..."
            try:
                exe, kaynak = self.exe_bul_ayrinti(ekstra, getattr(self, "ayar", {}))
            except Exception as e:
                if self._gecerli(nesil):
                    self.durum = "cloudflared bulunamadı"
                    self.hata = str(e)
                    self.istenen = False
                return
            if not exe:
                if self._gecerli(nesil):
                    self.durum = "cloudflared bulunamadı"
                    self.hata = ("Tünel aracı (cloudflared) bulunamadı. Üstteki “☁ Tünel Aracı” düğmesine basıp "
                                 "bir cloudflared.exe seçin veya oradaki indirme düğmesini kullanın.")
                    self.istenen = False
                return
            if not self._gecerli(nesil):
                break
            self.uyari = self.surum_uyarisi(exe, kaynak)
            log.info("cloudflared kaynağı: %s (%s)", kaynak, exe)
            if sabit:
                komut = [exe, "tunnel", "--no-autoupdate"] + (["--protocol", protokol] if protokol and protokol != "auto" else []) + ["run"]
            else:
                komut = [exe, "tunnel", "--no-autoupdate", "--url", f"http://127.0.0.1:{port}"]
                if protokol and protokol != "auto":
                    komut += ["--protocol", protokol]
            self.url = ""
            self.durum = "bağlanıyor..."
            try:
                proc = subprocess.Popen(
                    komut, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, env=ortam,
                    encoding="utf-8", errors="replace", creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
                if not self._gecerli(nesil):      # başlarken durdurulduysa bu süreç artık istenmiyor: ortada bırakma
                    try:
                        proc.terminate()
                    except Exception:
                        pass
                    break
                self.proc = proc
                for satir in proc.stdout:
                    if sabit:                      # sabit tünelde adres bellidir; bağlantının kurulduğu günlükten anlaşılır
                        if self._gecerli(nesil):
                            if SABIT_BAGLI_RE.search(satir):
                                self.url = sabit_url
                                self.durum = "bağlı"
                                self.hata = ""
                                log.info("Sabit tünel bağlı: %s", sabit_url)
                            elif SABIT_TOKEN_HATA_RE.search(satir):
                                self.hata = ("Tünel anahtarı (token) geçersiz ya da tünel silinmiş. Cloudflare panelinden "
                                             "anahtarı yeniden kopyalayıp Ayarlar'a yapıştırın.")
                        continue
                    m = self.URL_RE.search(satir)
                    if m and m.group(0) != "https://api.trycloudflare.com" and self._gecerli(nesil):
                        self.url = m.group(0)
                        self.durum = "bağlı"
                        self.hata = ""
                        log.info("Tünel adresi: %s", self.url)
                proc.wait()
            except Exception as e:
                log.error("cloudflared çalıştırılamadı: %s", e)
                if self._gecerli(nesil):
                    self.hata = str(e)
            if not self._gecerli(nesil):
                break
            self.url = ""
            self.durum = "yeniden bağlanıyor..."
            for _ in range(5):
                if not self._gecerli(nesil):
                    break
                time.sleep(1)
        if nesil == self._nesil:
            self.durum = "kapalı"

    def durdur(self):
        self._nesil += 1          # çalışan iş parçacığı artık eski sayılır ve çekilir
        self.istenen = False
        self.uyari = ""
        if self.proc and self.proc.poll() is None:
            try:
                self.proc.terminate()
                self.proc.wait(timeout=5)
            except Exception:
                try:
                    self.proc.kill()
                except Exception:
                    pass
        self.proc = None
        self.url = ""
        self.durum = "kapalı"


# ----------------------------------------------------------------------------
# MASAÜSTÜ ARAYÜZÜ (tkinter)
# ----------------------------------------------------------------------------
RENK = {
    "bg": "#f1f4f9", "kart": "#ffffff", "yazi": "#1b2430", "soluk": "#5b6677", "cizgi": "#d5dbe6",
    "mavi": "#0b5ed7", "mavi_koyu": "#084298", "yesil": "#15803d", "kirmizi": "#b00020",
    "turuncu": "#b45309", "sari": "#fff3a3", "yesil_acik": "#c6efce", "zebra": "#f6f8fb", "gri": "#e3e9f3",
}
FOTO_MOD_ADLARI = {"sor": "Fotoğrafsız kayıtta sor", "serbest": "İsteğe bağlı (sorma)", "zorunlu": "Zorunlu"}
_TR_HARITA = str.maketrans("İIıŞşĞğÜüÖöÇç", "iiiSsGgUuOoCc")


def tum_arama_norm(s):
    """Telefon ekranındaki arama (tumNorm) ile aynı kural: büyük/küçük harf, Türkçe harf ve aksan farkı yok sayılır."""
    s = unicodedata.normalize("NFD", str(s if s is not None else "").translate(_TR_HARITA).lower())
    return "".join(c for c in s if not unicodedata.combining(c))


def arama_norm(s):
    """Arama için: büyük/küçük harf ve Türkçe karakter farkını yok sayar (sirket = ŞİRKET)."""
    return str(s if s is not None else "").translate(_TR_HARITA).lower()


def ortala(pen, ebeveyn):
    pen.update_idletasks()
    w, h = pen.winfo_reqwidth(), pen.winfo_reqheight()
    x = ebeveyn.winfo_rootx() + (ebeveyn.winfo_width() - w) // 2
    y = ebeveyn.winfo_rooty() + (ebeveyn.winfo_height() - h) // 3
    pen.geometry(f"+{max(x, 0)}+{max(y, 0)}")


def dpi_ayarla():
    """Windows'ta bulanık yazıyı önler (Tk penceresi oluşturulmadan önce çağrılmalı)."""
    if sys.platform != "win32":
        return
    try:
        import ctypes
        try:
            ctypes.windll.shcore.SetProcessDpiAwareness(1)
        except Exception:
            ctypes.windll.user32.SetProcessDPIAware()
    except Exception:
        pass


def pencereli_calistir(app, baslik, is_, bitince):
    """`is_(ilerleme)` işini arka planda çalıştırır; bu sırada kapatılamayan küçük bir ilerleme penceresi gösterir.
    Bitince `bitince(sonuc, hata)` çağrılır."""
    durum = {"mesaj": "Başlıyor…", "bitti": False, "sonuc": None, "hata": None}
    pen = tk.Toplevel(app)
    pen.title(baslik)
    pen.configure(bg=RENK["bg"])
    pen.transient(app)
    pen.protocol("WM_DELETE_WINDOW", lambda: None)          # işlem bitmeden kapatılmasın
    ic = ttk.Frame(pen, padding=18)
    ic.pack(fill="both", expand=True)
    lbl = ttk.Label(ic, text=durum["mesaj"], width=58)
    lbl.pack(anchor="w")
    bar = ttk.Progressbar(ic, mode="indeterminate", length=int(420 * app.olcek))
    bar.pack(fill="x", pady=(10, 0))
    bar.start(12)
    ortala(pen, app)
    pen.grab_set()

    def calis():
        try:
            durum["sonuc"] = is_(lambda m: durum.__setitem__("mesaj", m))
        except Exception as e:
            log.exception("%s hatası", baslik)
            durum["hata"] = str(e) or e.__class__.__name__
        durum["bitti"] = True

    def izle():
        if not durum["bitti"]:
            lbl.config(text=durum["mesaj"])
            app.after(200, izle)
            return
        bar.stop()
        pen.grab_release()
        pen.destroy()
        bitince(durum["sonuc"], durum["hata"])

    threading.Thread(target=calis, daemon=True).start()
    app.after(200, izle)


class Uygulama(tk.Tk):
    SUTUNLAR = [("id", "No", 55), ("zaman", "Tarih-Saat", 145), ("marka", "Marka", 105),
                ("model", "Model", 105), ("cihaz_adi", "Cihaz Adı", 190), ("kunye_no", "Künye No", 140),
                ("seri_no", "Seri No", 150), ("birim", "Birim/Oda", 125), ("sayan", "Sayımı Yapan", 125), ("foto", "Foto", 50),
                ("tekrar", "Tekrar", 60), ("liste", "Listede", 70)]
    FILTRELER = ["Tümü", "Sadece tekrarlar", "Fotoğrafsız", "Bugün", "Listede eşleşenler", "Listede bulunamayanlar"]
    TUM_BIRIMLER = "Tüm birimler"

    def __init__(self):
        super().__init__()
        self.title("Hastane Envanter Sayım Sistemi")
        try:
            self.olcek = max(1.0, float(self.winfo_fpixels("1i")) / 96.0)
        except Exception:
            self.olcek = 1.0
        gen = min(int(1280 * self.olcek), self.winfo_screenwidth() - 60)
        yuk = min(int(820 * self.olcek), self.winfo_screenheight() - 100)
        self.geometry(f"{gen}x{yuk}")
        self.minsize(min(int(1050 * self.olcek), gen), min(int(660 * self.olcek), yuk))
        self.font_ad = "Segoe UI" if sys.platform == "win32" else tkfont.nametofont("TkDefaultFont").actual("family")
        self.ayar = ayar_yukle()
        self.depo = None
        self.sunucu = Sunucu()
        self.tunel = Tunel()
        self.son_url = None
        self.son_versiyon = -1
        self._son_yenileme = 0.0
        self.qr_foto = None
        self._foto_img = None
        self._ara_job = None
        self._durum_job = None
        self.eslestirme_girdi = ""          # 'Liste Yükle' ile seçilen dış Excel listesi
        self.sira = ("id", True)             # (sütun, azalan?) – varsayılan: en yeni en üstte
        self.var_adres = tk.StringVar()
        self.var_ara = tk.StringVar()
        self.var_filtre = tk.StringVar(value=self.FILTRELER[0])
        self.var_birim = tk.StringVar(value=self.TUM_BIRIMLER)
        self._stil_kur()
        self._arayuz()
        self._depo_ac()
        self.protocol("WM_DELETE_WINDOW", self.kapat)
        self.bind("<Control-f>", lambda e: (self.ent_ara.focus_set(), self.ent_ara.select_range(0, "end")))
        self.bind("<F5>", lambda e: self.tabloyu_yenile())
        self.after(500, self._tik)
        if AYAR_NOTU:
            self.after(800, lambda: self.bildir(AYAR_NOTU, "turuncu", 15000))

    # -- görünüm --------------------------------------------------------------
    def _stil_kur(self):
        self.configure(bg=RENK["bg"])
        for ad in ("TkDefaultFont", "TkTextFont", "TkMenuFont", "TkHeadingFont"):
            try:
                tkfont.nametofont(ad).configure(family=self.font_ad, size=10)
            except tk.TclError:
                pass
        st = ttk.Style(self)
        try:
            st.theme_use("clam")
        except tk.TclError:
            pass
        ad = self.font_ad
        st.configure(".", background=RENK["bg"], foreground=RENK["yazi"], font=(ad, 10))
        st.configure("TFrame", background=RENK["bg"])
        st.configure("Kart.TFrame", background=RENK["kart"])
        st.configure("TLabel", background=RENK["bg"], foreground=RENK["yazi"])
        st.configure("Kart.TLabel", background=RENK["kart"])
        st.configure("Soluk.Kart.TLabel", background=RENK["kart"], foreground=RENK["soluk"])
        st.configure("KartBaslik.TLabel", background=RENK["kart"], foreground=RENK["soluk"], font=(ad, 8, "bold"))
        st.configure("Sayi.TLabel", background=RENK["kart"], foreground=RENK["yazi"], font=(ad, 22, "bold"))
        st.configure("Pin.TLabel", background=RENK["kart"], foreground=RENK["mavi"], font=(ad, 22, "bold"))
        st.configure("Chip.TLabel", background=RENK["bg"], font=(ad, 10, "bold"))
        st.configure("DetayAd.TLabel", background=RENK["kart"], foreground=RENK["yazi"], font=(ad, 12, "bold"))
        st.configure("Deger.TLabel", background=RENK["kart"], foreground=RENK["yazi"], font=(ad, 10))
        st.configure("TButton", padding=(12, 6), relief="flat", borderwidth=0,
                     background=RENK["gri"], foreground=RENK["yazi"], focuscolor=RENK["gri"])
        st.map("TButton", background=[("disabled", "#eceff5"), ("active", "#d3dbea")],
               foreground=[("disabled", "#9aa5b5")])
        st.configure("Accent.TButton", background=RENK["mavi"], foreground="white", focuscolor=RENK["mavi"])
        st.map("Accent.TButton", background=[("disabled", "#9db9e8"), ("active", RENK["mavi_koyu"])],
               foreground=[("disabled", "white")])
        st.configure("Danger.TButton", background=RENK["kirmizi"], foreground="white", focuscolor=RENK["kirmizi"])
        st.map("Danger.TButton", background=[("disabled", "#e5a5ad"), ("active", "#8f0019")],
               foreground=[("disabled", "white")])
        st.configure("TEntry", padding=6, fieldbackground="white")
        st.configure("TCombobox", padding=5, fieldbackground="white")
        st.configure("TLabelframe", background=RENK["bg"], bordercolor=RENK["cizgi"])
        st.configure("TLabelframe.Label", background=RENK["bg"], foreground=RENK["soluk"], font=(ad, 9, "bold"))
        st.configure("TCheckbutton", background=RENK["bg"])
        st.configure("Treeview", rowheight=int(28 * self.olcek), background="white", fieldbackground="white",
                     foreground=RENK["yazi"], borderwidth=0)
        st.configure("Treeview.Heading", background=RENK["gri"], foreground=RENK["yazi"], font=(ad, 10, "bold"),
                     relief="flat", padding=(6, 7))
        st.map("Treeview.Heading", background=[("active", "#d3dbea")])
        # Bazı Tk sürümlerinde etiket (tag) renkleri görünmez; bilinen çözüm: hatalı varsayılan eşlemeyi ayıkla.
        # (Seçili satır eşlemesi de aynı çağrıda verilmeli, yoksa birbirini ezer.)
        def _temiz_map(secenek):
            return [e for e in st.map("Treeview", query_opt=secenek) if e[:2] != ("!disabled", "!selected")]
        st.map("Treeview",
               background=[("selected", RENK["mavi"])] + _temiz_map("background"),
               foreground=[("selected", "white")] + _temiz_map("foreground"))

    def _kart(self, ebeveyn):
        """Beyaz, ince çerçeveli kart. Dönüş: (dış çerçeve, içerik çerçevesi)."""
        dis = tk.Frame(ebeveyn, bg=RENK["kart"], highlightbackground=RENK["cizgi"], highlightthickness=1)
        ic = ttk.Frame(dis, style="Kart.TFrame", padding=(14, 10))
        ic.pack(fill="both", expand=True)
        return dis, ic

    def _chip(self, etiket, metin, renk):
        etiket.config(text="● " + metin, foreground=RENK[renk])

    # -- arayüz ---------------------------------------------------------------
    def _arayuz(self):
        ad = self.font_ad
        o = self.olcek

        # Üst çubuk: komutlar + durum göstergeleri
        ust = ttk.Frame(self, padding=(12, 10))
        ust.pack(fill="x")
        self.btn_baslat = ttk.Button(ust, text="▶  Sistemi Başlat", style="Accent.TButton", command=self.baslat)
        self.btn_baslat.pack(side="left")
        self.btn_durdur = ttk.Button(ust, text="■  Durdur", command=self.durdur, state="disabled")
        self.btn_durdur.pack(side="left", padx=8)
        ttk.Button(ust, text="⚙  Ayarlar", command=self.ayarlar_penceresi).pack(side="left")
        ttk.Button(ust, text="☁  Tünel Aracı", command=self.tunel_araci_penceresi).pack(side="left", padx=(8, 0))
        sag = ttk.Frame(ust)
        sag.pack(side="right")
        self.lbl_sunucu = ttk.Label(sag, style="Chip.TLabel")
        self.lbl_sunucu.pack(side="left", padx=10)
        self.lbl_tunel = ttk.Label(sag, style="Chip.TLabel")
        self.lbl_tunel.pack(side="left", padx=10)
        self.lbl_excel = ttk.Label(sag, style="Chip.TLabel")
        self.lbl_excel.pack(side="left", padx=10)
        self._chip(self.lbl_sunucu, "Sunucu: kapalı", "soluk")
        self._chip(self.lbl_tunel, "Tünel: kapalı", "soluk")
        self._chip(self.lbl_excel, "Excel: -", "soluk")

        # Bağlantı kartı: adres, PIN, QR
        dis, ic = self._kart(self)
        dis.pack(fill="x", padx=12, pady=(0, 8))
        sol = ttk.Frame(ic, style="Kart.TFrame")
        sol.pack(side="left", fill="x", expand=True)
        ttk.Label(sol, text="TELEFONLARIN AÇACAĞI ADRES", style="KartBaslik.TLabel").pack(anchor="w")
        satir = ttk.Frame(sol, style="Kart.TFrame")
        satir.pack(fill="x", pady=(4, 0))
        ttk.Entry(satir, textvariable=self.var_adres, state="readonly", font=(ad, 12)).pack(side="left", fill="x", expand=True)
        ttk.Button(satir, text="Kopyala", command=self.kopyala).pack(side="left", padx=(6, 0))
        ttk.Button(satir, text="Tarayıcıda Aç", command=self.tarayicida_ac).pack(side="left", padx=(6, 0))
        self.lbl_ipucu = ttk.Label(sol, style="Soluk.Kart.TLabel", text="")
        self.lbl_ipucu.pack(anchor="w", pady=(4, 0))
        ttk.Label(sol, text="SAYIM PIN'İ", style="KartBaslik.TLabel").pack(anchor="w", pady=(8, 0))
        pin_s = ttk.Frame(sol, style="Kart.TFrame")
        pin_s.pack(anchor="w")
        self.lbl_pin = ttk.Label(pin_s, text="", style="Pin.TLabel")
        self.lbl_pin.pack(side="left")
        ttk.Button(pin_s, text="Kopyala", command=self.pin_kopyala).pack(side="left", padx=12)
        self.lbl_yerel = ttk.Label(sol, text="", style="Soluk.Kart.TLabel")
        self.lbl_yerel.pack(anchor="w", pady=(2, 0))
        self.lbl_tunel_hata = ttk.Label(sol, text="", style="Kart.TLabel", foreground=RENK["kirmizi"],
                                        wraplength=int(720 * o), justify="left")
        self.lbl_tunel_hata.pack(anchor="w")
        ttk.Label(sol, text="UYARI: Bu sistem hasta bilgisi içeren veri/fotoğraf toplamamalıdır; cihaz fotoğraflarında "
                            "hasta veya personel görüntüsü bulunmasın.", style="Kart.TLabel",
                  foreground=RENK["turuncu"], wraplength=int(720 * o), justify="left").pack(anchor="w", pady=(6, 0))
        self.lbl_qr = ttk.Label(ic, style="Kart.TLabel", anchor="center", justify="center", foreground=RENK["soluk"])
        self.lbl_qr.pack(side="right", padx=8)
        self.qr_boyut = int(190 * o)

        # İstatistik kartları
        sat = ttk.Frame(self)
        sat.pack(fill="x", padx=12, pady=(0, 8))
        self.stat = {}
        for i, (kod, bas) in enumerate((("toplam", "TOPLAM KAYIT"), ("bugun", "BUGÜN"),
                                        ("tekrar", "TEKRAR EDEN KÜNYE"), ("fotolu", "FOTOĞRAFLI KAYIT"),
                                        ("eslesen", "LİSTEDE EŞLEŞEN"))):
            d, k = self._kart(sat)
            d.pack(side="left", fill="x", expand=True, padx=(0, 8 if i < 4 else 0))
            ttk.Label(k, text=bas, style="KartBaslik.TLabel").pack(anchor="w")
            l = ttk.Label(k, text="0", style="Sayi.TLabel")
            l.pack(anchor="w")
            self.stat[kod] = l

        # Arama / süzgeç çubuğu
        fb = ttk.Frame(self)
        fb.pack(fill="x", padx=12, pady=(0, 6))
        ttk.Label(fb, text="Ara:").pack(side="left")
        self.ent_ara = ttk.Entry(fb, textvariable=self.var_ara, width=32)
        self.ent_ara.pack(side="left", padx=(6, 12))
        cmb = ttk.Combobox(fb, textvariable=self.var_filtre, values=self.FILTRELER, state="readonly", width=22)
        cmb.pack(side="left")
        cmb.bind("<<ComboboxSelected>>", lambda e: self.tabloyu_yenile())
        self.cmb_birim = ttk.Combobox(fb, textvariable=self.var_birim, values=[self.TUM_BIRIMLER], state="readonly", width=24)
        self.cmb_birim.pack(side="left", padx=8)
        self.cmb_birim.bind("<<ComboboxSelected>>", lambda e: self.tabloyu_yenile())
        ttk.Button(fb, text="Temizle", command=self.filtre_temizle).pack(side="left")
        self.lbl_gosterilen = ttk.Label(fb, text="", foreground=RENK["soluk"])
        self.lbl_gosterilen.pack(side="right")
        self.var_ara.trace_add("write", self._ara_degisti)

        # Tablo + ayrıntı paneli
        govde = ttk.Frame(self)
        govde.pack(fill="both", expand=True, padx=12, pady=(0, 6))
        dis, ic = self._kart(govde)          # ayrıntı paneli (sağ)
        dis.pack(side="right", fill="y", padx=(8, 0))
        dis.pack_propagate(False)
        dis.configure(width=int(360 * o))
        self._detay_paneli_kur(ic)

        tablo_cerceve = ttk.Frame(govde)
        tablo_cerceve.pack(side="left", fill="both", expand=True)
        self.tablo = ttk.Treeview(tablo_cerceve, columns=[c[0] for c in self.SUTUNLAR], show="headings", selectmode="browse")
        for kod, baslik, gen in self.SUTUNLAR:
            self.tablo.heading(kod, text=baslik, command=lambda c=kod: self._sirala(c))
            self.tablo.column(kod, width=int(gen * o), minwidth=int(40 * o), anchor="center" if kod in ("id", "foto", "tekrar", "liste") else "w")
        self._baslik_oku()
        self.tablo.tag_configure("tekrar", background=RENK["sari"])
        self.tablo.tag_configure("eslesen", background=RENK["yesil_acik"])
        self.tablo.tag_configure("zebra", background=RENK["zebra"])
        kay = ttk.Scrollbar(tablo_cerceve, orient="vertical", command=self.tablo.yview)
        kay_x = ttk.Scrollbar(tablo_cerceve, orient="horizontal", command=self.tablo.xview)
        self.tablo.configure(yscrollcommand=kay.set, xscrollcommand=kay_x.set)
        self.tablo.grid(row=0, column=0, sticky="nsew")
        kay.grid(row=0, column=1, sticky="ns")
        kay_x.grid(row=1, column=0, sticky="ew")
        tablo_cerceve.rowconfigure(0, weight=1)
        tablo_cerceve.columnconfigure(0, weight=1)
        self.tablo.bind("<Double-1>", lambda e: self.duzenle())
        self.tablo.bind("<Return>", lambda e: self.duzenle())
        self.tablo.bind("<Delete>", lambda e: self.sil())
        self.tablo.bind("<<TreeviewSelect>>", self._secim_degisti)
        self.menu = tk.Menu(self, tearoff=0)
        self.menu.add_command(label="Düzenle", command=self.duzenle)
        self.menu.add_command(label="Fotoğrafı göster", command=self.foto_goster)
        self.menu.add_command(label="Künye no'yu kopyala", command=self.kunye_kopyala)
        self.menu.add_separator()
        self.menu.add_command(label="Sil", command=self.sil)
        self.tablo.bind("<Button-3>", self._sag_tik)
        self.tablo.bind("<Button-2>", self._sag_tik)

        # Alt çubuk
        alt = ttk.Frame(self, padding=(12, 4, 12, 10))
        alt.pack(fill="x")
        ttk.Button(alt, text="✎  Düzenle", command=self.duzenle).pack(side="left")
        ttk.Button(alt, text="🗑  Sil", style="Danger.TButton", command=self.sil).pack(side="left", padx=6)
        ttk.Button(alt, text="↩  Silinenler", command=self.silinenler_penceresi).pack(side="left", padx=(0, 6))
        ttk.Button(alt, text="📊  Excel'i Aç", command=self.excel_ac).pack(side="left", padx=(14, 6))
        ttk.Button(alt, text="📥  Liste Yükle", command=self.eslestirme_listesi_yukle).pack(side="left", padx=6)
        ttk.Button(alt, text="📤  İşaretli Excel'i Ver", command=self.kunye_eslestir).pack(side="left", padx=6)
        ttk.Button(alt, text="⭳  CSV Aktar", command=self.csv_aktar).pack(side="left", padx=6)
        ttk.Button(alt, text="💾  Yedek Al", command=self.yedek_al).pack(side="left", padx=6)
        ttk.Button(alt, text="📁  Fotoğraflar", command=self.foto_klasoru_ac).pack(side="left", padx=(14, 6))
        ttk.Button(alt, text="📁  Veri Klasörü", command=self.veri_klasoru_ac).pack(side="left", padx=6)
        self.lbl_durum = ttk.Label(alt, text="")
        self.lbl_durum.pack(side="right")
        self._pin_goster()
        self._qr_guncelle("")

    def _pin_goster(self):
        self.lbl_pin.config(text=str(self.ayar["pin"]))

    def bildir(self, metin, renk="yesil", sure=7000):
        """Alt çubukta kısa bilgi mesajı gösterir."""
        if self._durum_job:
            self.after_cancel(self._durum_job)
        self.lbl_durum.config(text=metin, foreground=RENK.get(renk, RENK["yazi"]))
        self._durum_job = self.after(sure, lambda: self.lbl_durum.config(text=""))

    def _depo_ac(self):
        try:
            if self.depo:
                self.depo.kapat()
            self.depo = Depo(self.ayar["kayit_klasoru"], self.ayar.get("ikinci_yedek_klasoru", ""))
            self.son_versiyon = -1
            if self.depo.liste_yolu and os.path.exists(self.depo.liste_yolu):
                self.eslestirme_girdi = self.depo.liste_yolu
        except Exception as e:
            self.depo = None
            log.exception("Depo açılamadı")
            messagebox.showerror("Hata", f"Kayıt klasörü açılamadı:\n{self.ayar['kayit_klasoru']}\n\n{e}")

    # -- sistem kontrol -------------------------------------------------------
    def baslat(self):
        if not self.depo:
            self._depo_ac()
            if not self.depo:
                return
        try:
            port = int(self.ayar["port"])
            host = "0.0.0.0" if self.ayar.get("yerel_ag") else "127.0.0.1"
            app = uygulama_olustur(self.depo, self.ayar)
            self.sunucu.baslat(app, host, port)
        except OSError as e:
            messagebox.showerror("Port kullanımda", f"{self.ayar['port']} numaralı port açılamadı.\n"
                                                    f"Başka bir program kullanıyor olabilir; Ayarlar'dan portu değiştirin.\n\n{e}")
            return
        except Exception as e:
            log.exception("Sunucu başlatılamadı")
            messagebox.showerror("Hata", f"Sunucu başlatılamadı:\n{e}")
            return
        self.tunel.baslat(port, self.ayar.get("tunel_protokol", "auto"), [BASE_DIR, self.ayar["kayit_klasoru"]], self.ayar)
        self.btn_baslat.config(state="disabled")
        self.btn_durdur.config(state="normal")

    def durdur(self):
        self.tunel.durdur()
        self.sunucu.durdur()
        self.btn_baslat.config(state="normal")
        self.btn_durdur.config(state="disabled")

    # -- periyodik güncelleme -------------------------------------------------
    def _tik(self):
        try:
            cal = self.sunucu.calisiyor
            self._chip(self.lbl_sunucu, "Sunucu: çalışıyor" if cal else "Sunucu: kapalı", "yesil" if cal else "soluk")
            d = self.tunel.durum
            if d == "bağlı":
                renk = "yesil"
            elif "bulunamadı" in d:
                renk = "kirmizi"
            else:
                renk = "turuncu" if (cal and d != "kapalı") else "soluk"
            self._chip(self.lbl_tunel, f"Tünel: {d}", renk)
            yedek_hata = getattr(self.depo, "ikinci_yedek_hata", "") if self.depo else ""
            if self.tunel.hata:
                self.lbl_tunel_hata.config(text=self.tunel.hata, foreground=RENK["kirmizi"])
            elif yedek_hata:
                self.lbl_tunel_hata.config(text="İkinci yedek yazılamadı (USB/ağ klasörü takılı mı?): " + yedek_hata,
                                           foreground=RENK["turuncu"])
            else:
                self.lbl_tunel_hata.config(text=self.tunel.uyari, foreground=RENK["turuncu"])
            if self.depo:
                if self.depo.excel_kirli:
                    hata = self.depo.excel_hata
                    self._chip(self.lbl_excel, "Excel: " + (hata or "yazılıyor..."),
                               "kirmizi" if hata.startswith("Excel yazılamadı") else "turuncu")
                else:
                    self._chip(self.lbl_excel, "Excel: güncel", "yesil")
                if self.depo.versiyon != self.son_versiyon:
                    # binlerce satırda her kayıtta tabloyu baştan kurmak arayüzü yavaşlatır: büyük listede en çok 5 sn'de bir
                    bekle = 1.5 if self.depo.sayi() < 1500 else 5.0
                    if time.time() - self._son_yenileme >= bekle:
                        self.tabloyu_yenile()
            url = self.tunel.url
            yerel = ""
            if cal and self.ayar.get("yerel_ag"):
                yerel = f"http://{yerel_ip()}:{self.ayar['port']}"
            self.lbl_yerel.config(text=f"Yerel ağ adresi (aynı Wi-Fi): {yerel}" if yerel else "")
            gosterilecek = url or yerel
            if gosterilecek != self.son_url:
                self.son_url = gosterilecek
                self.var_adres.set(gosterilecek)
                self._qr_guncelle(gosterilecek)
            if gosterilecek:
                ipucu = "Telefonla QR kodu okutun veya adresi tarayıcıya yazın; ardından adınız ve PIN ile giriş yapın."
            elif cal:
                ipucu = "Tünel bağlanıyor, birkaç saniye bekleyin..."
            else:
                ipucu = "Adres ve QR kod, “Sistemi Başlat”a bastıktan sonra burada görünür."
            self.lbl_ipucu.config(text=ipucu)
        except Exception as e:
            log.error("Arayüz güncelleme hatası: %s", e)
        self.after(1500, self._tik)

    def _qr_guncelle(self, url):
        if not ImageTk:
            return
        if not url:
            self.lbl_qr.config(image="", text="QR kod, sistem\nbaşlayınca burada\ngörünür", width=22)
            self.qr_foto = None
            return
        qr = qrcode.QRCode(box_size=6, border=2)
        qr.add_data(url)
        qr.make(fit=True)
        img = qr.make_image(fill_color="black", back_color="white").get_image().convert("RGB").resize(
            (self.qr_boyut, self.qr_boyut), Image.NEAREST)
        self.qr_foto = ImageTk.PhotoImage(img)
        self.lbl_qr.config(image=self.qr_foto, text="", width=0)

    # -- tablo ----------------------------------------------------------------
    def _listede(self, k):
        """Kaydın künyesi yüklenen dış listede var mı?"""
        kume = self.depo.liste_kunyeler if self.depo else None
        return bool(kume) and kunye_norm(k.get("kunye_no")) in kume

    def _baslik_oku(self):
        kod_, azalan = self.sira
        for kod, baslik, _ in self.SUTUNLAR:
            ok = (" ▼" if azalan else " ▲") if kod == kod_ else ""
            self.tablo.heading(kod, text=baslik + ok)

    def _sirala(self, kod):
        self.sira = (kod, not self.sira[1]) if self.sira[0] == kod else (kod, kod == "id")
        self._baslik_oku()
        self.tabloyu_yenile()

    def _filtrele(self, liste, tekrar):
        q = arama_norm(self.var_ara.get().strip())
        f = self.var_filtre.get()
        b = self.var_birim.get()
        bugun = datetime.now().strftime("%Y-%m-%d")
        sonuc = []
        for k in liste:
            if f == "Sadece tekrarlar" and kunye_anahtar(k.get("kunye_no")) not in tekrar:
                continue
            if f == "Fotoğrafsız" and k.get("foto"):
                continue
            if f == "Listede eşleşenler" and not self._listede(k):
                continue
            if f == "Listede bulunamayanlar" and (self._listede(k) or not self.depo.liste_kunyeler):
                continue
            if f == "Bugün" and not str(k.get("zaman", "")).startswith(bugun):
                continue
            if b != self.TUM_BIRIMLER and k.get("birim", "") != b:
                continue
            if q and q not in arama_norm(" ".join(str(k.get(a, "")) for a in (
                    "id", "zaman", "marka", "model", "cihaz_adi", "kunye_no", "seri_no", "birim", "sayan"))):
                continue
            sonuc.append(k)
        return sonuc

    def _sirala_liste(self, liste, tekrar):
        kod, azalan = self.sira
        if kod == "id":
            anahtar = lambda k: k.get("id", 0)
        elif kod == "foto":
            anahtar = lambda k: bool(k.get("foto"))
        elif kod == "tekrar":
            anahtar = lambda k: kunye_anahtar(k.get("kunye_no")) in tekrar
        elif kod == "liste":
            anahtar = lambda k: self._listede(k)
        else:
            anahtar = lambda k: arama_norm(k.get(kod, ""))
        liste.sort(key=anahtar, reverse=azalan)

    def _ara_degisti(self, *_):
        if self._ara_job:
            self.after_cancel(self._ara_job)
        self._ara_job = self.after(200, self.tabloyu_yenile)

    def filtre_temizle(self):
        self.var_ara.set("")
        self.var_filtre.set(self.FILTRELER[0])
        self.var_birim.set(self.TUM_BIRIMLER)
        self.tabloyu_yenile()

    def tabloyu_yenile(self):
        if not self.depo:
            return
        self.son_versiyon = self.depo.versiyon
        self._son_yenileme = time.time()
        sec = self.tablo.selection()
        secili = sec[0] if sec else None
        y0 = self.tablo.yview()[0]
        liste = self.depo.liste()
        tekrar = self.depo.tekrar_kumesi()
        oz = self.depo.ozet()
        for kod in ("toplam", "bugun", "tekrar", "fotolu"):
            self.stat[kod].config(text=str(oz[kod]))
        yuklu, esl, kunyeli, _ad, _n = self.depo.liste_ozeti()
        self.stat["eslesen"].config(text=f"{esl} / {kunyeli}" if yuklu else "-")
        birimler = sorted({k.get("birim", "") for k in liste if k.get("birim")}, key=arama_norm)
        self.cmb_birim.config(values=[self.TUM_BIRIMLER] + birimler)
        if self.var_birim.get() != self.TUM_BIRIMLER and self.var_birim.get() not in birimler:
            self.var_birim.set(self.TUM_BIRIMLER)
        gorunen = self._filtrele(liste, tekrar)
        self._sirala_liste(gorunen, tekrar)
        self.tablo.delete(*self.tablo.get_children())
        for i, k in enumerate(gorunen):
            t = kunye_anahtar(k.get("kunye_no")) in tekrar
            e = self._listede(k)
            etiket = ("eslesen",) if e else (("tekrar",) if t else (("zebra",) if i % 2 else ()))
            self.tablo.insert("", "end", iid=str(k["id"]), tags=etiket, values=(
                k["id"], k.get("zaman", ""), k.get("marka", ""), k.get("model", ""), k.get("cihaz_adi", ""),
                k.get("kunye_no", ""), k.get("seri_no", ""), k.get("birim", ""), k.get("sayan", ""),
                "✓" if k.get("foto") else "-", "Evet" if t else "",
                ("✓" if e else "✗") if yuklu else ""))
        if secili is not None and self.tablo.exists(secili):
            self.tablo.selection_set(secili)
        self.tablo.yview_moveto(y0)
        self.lbl_gosterilen.config(text=f"{len(gorunen)} / {len(liste)} kayıt gösteriliyor")
        self._secim_degisti()

    def _secim_degisti(self, _=None):
        k = self._secili_kayit(sessiz=True)
        self._detay_goster(k)

    def _detay_paneli_kur(self, ic):
        """Sağdaki 'Kayıt Detayı' kartı: büyük fotoğraf, rozetler, vurgulu künye kutusu ve düzenli alan ızgarası."""
        ad, o = self.font_ad, self.olcek
        ust = ttk.Frame(ic, style="Kart.TFrame")
        ust.pack(fill="x")
        ttk.Label(ust, text="KAYIT DETAYI", style="KartBaslik.TLabel").pack(side="left")
        self.lbl_d_id = tk.Label(ust, text="", bg=RENK["gri"], fg=RENK["yazi"], font=(ad, 8, "bold"), padx=8, pady=1)
        self.lbl_d_id.pack(side="right")

        # Alt eylem düğmeleri (her zaman görünür)
        eyl = ttk.Frame(ic, style="Kart.TFrame")
        eyl.pack(side="bottom", fill="x", pady=(8, 0))
        for metin, komut in (("✎  Düzenle", self.duzenle), ("🖼  Fotoğraf", self.foto_goster),
                             ("⧉  Künye", self.kunye_kopyala)):
            ttk.Button(eyl, text=metin, command=komut).pack(side="left", expand=True, fill="x", padx=2)
        ttk.Button(eyl, text="🗑  Sil", style="Danger.TButton", command=self.sil).pack(side="left", expand=True, fill="x", padx=2)

        # Kaydırılabilir gövde (küçük ekranlarda panel taşmasın)
        kap = ttk.Frame(ic, style="Kart.TFrame")
        kap.pack(fill="both", expand=True, pady=(6, 0))
        self.d_canvas = tk.Canvas(kap, bg=RENK["kart"], highlightthickness=0, borderwidth=0)
        d_kay = ttk.Scrollbar(kap, orient="vertical", command=self.d_canvas.yview)
        self.d_canvas.configure(yscrollcommand=d_kay.set)
        d_kay.pack(side="right", fill="y")
        self.d_canvas.pack(side="left", fill="both", expand=True)
        govde = ttk.Frame(self.d_canvas, style="Kart.TFrame")
        pen_id = self.d_canvas.create_window((0, 0), window=govde, anchor="nw")
        govde.bind("<Configure>", lambda e: self.d_canvas.configure(scrollregion=self.d_canvas.bbox("all")))
        self.d_canvas.bind("<Configure>", lambda e: self.d_canvas.itemconfigure(pen_id, width=e.width))

        def teker(e):
            if govde.winfo_reqheight() > self.d_canvas.winfo_height():
                adim = -1 if (e.delta > 0 or getattr(e, "num", 0) == 4) else 1
                self.d_canvas.yview_scroll(adim, "units")
        self.d_canvas.bind("<Enter>", lambda e: (self.d_canvas.bind_all("<MouseWheel>", teker)))
        self.d_canvas.bind("<Leave>", lambda e: self.d_canvas.unbind_all("<MouseWheel>"))

        # Fotoğraf çerçevesi
        self.d_foto_cerceve = tk.Frame(govde, bg=RENK["zebra"], highlightbackground=RENK["cizgi"], highlightthickness=1)
        self.d_foto_cerceve.pack(fill="x", pady=(0, 2))
        self.lbl_foto = tk.Label(self.d_foto_cerceve, bg=RENK["zebra"], fg=RENK["soluk"], font=(ad, 10),
                                 text="Bir kayıt seçin", cursor="hand2", pady=int(36 * o))
        self.lbl_foto.pack(fill="x")
        self.lbl_foto.bind("<Double-1>", lambda e: self.foto_goster())
        self.lbl_foto_ipucu = ttk.Label(govde, text="Büyütmek için fotoğrafa çift tıklayın", style="Soluk.Kart.TLabel",
                                        font=(ad, 8), anchor="center")

        # İçerik (kayıt seçilince görünür)
        self.d_icerik = ttk.Frame(govde, style="Kart.TFrame")
        self.d_icerik.pack(fill="x")
        gen = int(300 * o)
        self.lbl_d_ad = ttk.Label(self.d_icerik, text="", style="DetayAd.TLabel", wraplength=gen, justify="left")
        self.lbl_d_ad.pack(anchor="w", pady=(8, 4))
        self.f_chip = ttk.Frame(self.d_icerik, style="Kart.TFrame")
        self.f_chip.pack(anchor="w", fill="x")

        # Vurgulu künye kutusu (tıklayınca kopyalar)
        self.d_kunye_kutu = tk.Frame(self.d_icerik, bg="#e8f0fe", highlightbackground="#c3d6f8",
                                     highlightthickness=1, cursor="hand2", padx=10, pady=6)
        self.d_kunye_kutu.pack(fill="x", pady=(8, 2))
        k1 = tk.Label(self.d_kunye_kutu, text="KÜNYE NO  ·  kopyalamak için tıklayın", bg="#e8f0fe",
                      fg=RENK["soluk"], font=(ad, 8, "bold"), anchor="w")
        k1.pack(fill="x")
        self.lbl_d_kunye = tk.Label(self.d_kunye_kutu, text="", bg="#e8f0fe", fg=RENK["mavi_koyu"],
                                    font=(ad, 15, "bold"), anchor="w")
        self.lbl_d_kunye.pack(fill="x")
        for w in (self.d_kunye_kutu, k1, self.lbl_d_kunye):
            w.bind("<Button-1>", lambda e: self.kunye_kopyala())

        # Tekrar uyarısı
        self.lbl_d_uyari = tk.Label(self.d_icerik, text="⚠  Bu künye birden fazla kez kayıtlı", bg="#fff3cd",
                                    fg=RENK["turuncu"], font=(ad, 9, "bold"), anchor="w", padx=10, pady=5)

        # Alan ızgarası
        izgara = self.d_izgara = ttk.Frame(self.d_icerik, style="Kart.TFrame")
        izgara.pack(fill="x", pady=(4, 0))
        izgara.columnconfigure(0, weight=1, uniform="d")
        izgara.columnconfigure(1, weight=1, uniform="d")
        self.d_alan = {}

        def alan(kod, baslik, satir, sutun, span=1):
            f = ttk.Frame(izgara, style="Kart.TFrame")
            f.grid(row=satir, column=sutun, columnspan=span, sticky="nw", pady=(8, 0), padx=(0, 6))
            ttk.Label(f, text=baslik, style="KartBaslik.TLabel").pack(anchor="w")
            v = ttk.Label(f, text="-", style="Deger.TLabel", justify="left",
                          wraplength=int((140 if span == 1 else 290) * o))
            v.pack(anchor="w")
            self.d_alan[kod] = v
        alan("seri_no", "SERİ NO", 0, 0)
        alan("zaman", "ZAMAN", 0, 1)
        alan("marka_model", "MARKA / MODEL", 1, 0, 2)
        alan("birim", "BİRİM / ODA", 2, 0, 2)
        alan("sayan", "SAYIMI YAPAN", 3, 0, 2)
        self.d_icerik.pack_forget()

    def _detay_rozet(self, metin, bg, fg):
        tk.Label(self.f_chip, text=metin, bg=bg, fg=fg, font=(self.font_ad, 8, "bold"),
                 padx=8, pady=2).pack(side="left", padx=(0, 5))

    def _detay_goster(self, k):
        self._foto_img = None
        for w in self.f_chip.winfo_children():
            w.destroy()
        if not k:
            self.lbl_foto.config(image="", text="Bir kayıt seçin", pady=int(36 * self.olcek))
            self.lbl_foto_ipucu.pack_forget()
            self.lbl_d_id.config(text="")
            self.d_icerik.pack_forget()
            return
        tekrar = kunye_anahtar(k.get("kunye_no")) in self.depo.tekrar_kumesi()
        self.lbl_d_id.config(text=f"#{k.get('id', '')}")
        self.lbl_d_ad.config(text=k.get("cihaz_adi", "") or "(adsız)")
        self.lbl_d_kunye.config(text=k.get("kunye_no", "") or "-")
        marka, model = k.get("marka", ""), k.get("model", "")
        self.d_alan["seri_no"].config(text=k.get("seri_no", "") or "-")
        zam = k.get("zaman", "") or "-"
        iz = k.get("istemci_zaman", "")
        if iz and zam != "-":
            try:    # çevrimdışı kayıtta telefonda okutulduğu an ile sunucuya ulaştığı an arasında fark varsa göster
                fark = abs((datetime.strptime(zam, "%Y-%m-%d %H:%M:%S") - datetime.strptime(iz, "%Y-%m-%d %H:%M:%S")).total_seconds())
                if fark > 120:
                    zam += f"\n(telefonda okutuldu: {iz})"
            except ValueError:
                pass
        self.d_alan["zaman"].config(text=zam)
        self.d_alan["marka_model"].config(text=" / ".join(x for x in (marka, model) if x) or "-")
        self.d_alan["birim"].config(text=k.get("birim", "") or "-")
        self.d_alan["sayan"].config(text=k.get("sayan", "") or "-")
        if tekrar:
            self._detay_rozet("⚠  TEKRAR", "#fff3cd", RENK["turuncu"])
            self.lbl_d_uyari.pack(fill="x", pady=(6, 0), before=self.d_izgara)
        else:
            self.lbl_d_uyari.pack_forget()
        foto_var = bool(k.get("foto"))
        if foto_var:
            self._detay_rozet("●  FOTOĞRAFLI", "#dcfce7", RENK["yesil"])
        else:
            self._detay_rozet("○  FOTOĞRAFSIZ", RENK["gri"], RENK["soluk"])
        if not self.d_icerik.winfo_manager():
            self.d_icerik.pack(fill="x")
        metin = "Fotoğraf yok"
        self.lbl_foto_ipucu.pack_forget()
        if foto_var and ImageTk:
            yol = os.path.join(self.depo.foto_klasoru, k["foto"])
            try:
                with Image.open(yol) as im:
                    im = im.convert("RGB")
                    im.thumbnail((int(318 * self.olcek), int(230 * self.olcek)))
                    self._foto_img = ImageTk.PhotoImage(im)
                self.lbl_foto.config(image=self._foto_img, text="", pady=int(4 * self.olcek))
                self.lbl_foto_ipucu.pack(fill="x", before=self.d_icerik)
                return
            except Exception:
                metin = "Fotoğraf okunamadı"
        self.lbl_foto.config(image="", text=metin, pady=int(36 * self.olcek))

    def _sag_tik(self, e):
        iid = self.tablo.identify_row(e.y)
        if not iid:
            return
        self.tablo.selection_set(iid)
        try:
            self.menu.tk_popup(e.x_root, e.y_root)
        finally:
            self.menu.grab_release()

    # -- tablo işlemleri ------------------------------------------------------
    def _secili_kayit(self, sessiz=False):
        sec = self.tablo.selection()
        if not sec or not self.depo:
            if not sessiz:
                messagebox.showinfo("Bilgi", "Önce tablodan bir kayıt seçin.")
            return None
        return self.depo.al(int(sec[0]))

    def sil(self):
        k = self._secili_kayit()
        if k and messagebox.askyesno(
                "Sil", f"{k['cihaz_adi']} ({k['kunye_no']}) kaydı silinsin mi?\n\n"
                       "Silinen kayıt ve fotoğrafı, gerekirse geri almanız için Yedek klasörüne taşınır."):
            try:
                self.depo.sil(id_=k["id"])
                self.bildir("Kayıt silindi (Yedek klasöründe saklandı)", "turuncu")
            except Exception as e:
                log.exception("Silme hatası")
                messagebox.showerror("Hata", str(e))

    def duzenle(self):
        k = self._secili_kayit()
        if not k:
            return
        pen = tk.Toplevel(self)
        pen.title(f"Kaydı düzenle – No {k['id']}")
        pen.configure(bg=RENK["bg"])
        pen.transient(self)
        pen.resizable(False, False)
        ic = ttk.Frame(pen, padding=18)
        ic.pack(fill="both", expand=True)
        alanlar = [("cihaz_adi", "Cihaz Adı *"), ("marka", "Marka"), ("model", "Model"),
                   ("kunye_no", "Künye No"), ("seri_no", "Seri No"), ("birim", "Birim/Oda"), ("sayan", "Sayımı Yapan (değiştirilemez)")]
        vars_ = {}
        ilk = None
        for i, (kod, ad) in enumerate(alanlar):
            ttk.Label(ic, text=ad).grid(row=i, column=0, sticky="w", padx=(0, 14), pady=5)
            v = tk.StringVar(value=k.get(kod, ""))
            e = ttk.Entry(ic, textvariable=v, width=42, state="readonly" if kod == "sayan" else "normal")
            e.grid(row=i, column=1, pady=5)
            vars_[kod] = v
            if kod != "sayan":
                ilk = ilk or e

        def kaydet(_=None):
            if not vars_["cihaz_adi"].get().strip():
                messagebox.showwarning("Eksik", "Cihaz adı boş olamaz.", parent=pen)
                return
            try:
                self.depo.guncelle(k["id"], **{c: v.get() for c, v in vars_.items()})
                pen.destroy()
                self.bildir("Kayıt güncellendi")
            except Exception as e:
                log.exception("Güncelleme hatası")
                messagebox.showerror("Hata", str(e), parent=pen)

        btn = ttk.Frame(ic)
        btn.grid(row=len(alanlar), column=0, columnspan=2, sticky="e", pady=(14, 0))
        ttk.Button(btn, text="İptal", command=pen.destroy).pack(side="right")
        ttk.Button(btn, text="Kaydet", style="Accent.TButton", command=kaydet).pack(side="right", padx=8)
        pen.bind("<Return>", kaydet)
        pen.bind("<Escape>", lambda e: pen.destroy())
        ortala(pen, self)
        try:
            pen.wait_visibility()
            pen.grab_set()
        except tk.TclError:
            pass
        ilk.focus_set()

    def silinenler_penceresi(self):
        """Silinen kayıtları listeler; seçileni fotoğrafıyla birlikte geri getirir."""
        if not self.depo:
            return
        if not self.depo.silinenler():
            messagebox.showinfo("Silinenler", "Silinmiş kayıt yok.")
            return
        pen = tk.Toplevel(self)
        pen.title("Silinen kayıtlar")
        pen.configure(bg=RENK["bg"])
        pen.transient(self)
        ic = ttk.Frame(pen, padding=14)
        ic.pack(fill="both", expand=True)
        ttk.Label(ic, text="Geri getirmek istediğiniz kaydı seçip “Geri Getir”e basın (fotoğrafıyla birlikte yerine konur)."
                  ).pack(anchor="w", pady=(0, 8))
        sut = (("silinme", "Silinme zamanı", 150), ("cihaz_adi", "Cihaz Adı", 210), ("kunye_no", "Künye No", 140),
               ("birim", "Birim/Oda", 130), ("sayan", "Sayımı Yapan", 130))
        cerceve = ttk.Frame(ic)
        cerceve.pack(fill="both", expand=True)
        tb = ttk.Treeview(cerceve, columns=[c[0] for c in sut], show="headings", selectmode="browse", height=12)
        for kod, baslik, gen in sut:
            tb.heading(kod, text=baslik)
            tb.column(kod, width=int(gen * self.olcek), anchor="w")
        kay = ttk.Scrollbar(cerceve, orient="vertical", command=tb.yview)
        tb.configure(yscrollcommand=kay.set)
        tb.pack(side="left", fill="both", expand=True)
        kay.pack(side="left", fill="y")
        harita = {}

        def doldur():
            harita.clear()
            tb.delete(*tb.get_children())
            for i, k in enumerate(self.depo.silinenler()):
                harita[str(i)] = k
                tb.insert("", "end", iid=str(i), values=(k.get("silinme_zamani", ""), k.get("cihaz_adi", ""),
                          k.get("kunye_no", ""), k.get("birim", ""), k.get("sayan", "")))

        def geri(_=None):
            sec = tb.selection()
            if not sec:
                messagebox.showinfo("Bilgi", "Önce listeden bir kayıt seçin.", parent=pen)
                return
            k = harita.get(sec[0], {})
            kayit, hata = self.depo.geri_getir(k.get("silinme_zamani", ""), k.get("id"), k.get("uuid", ""))
            if kayit is None:
                messagebox.showwarning("Geri getirilemedi", hata, parent=pen)
                doldur()
                return
            self.bildir(f"Kayıt geri getirildi (No {kayit['id']})")
            doldur()
            if not harita:
                pen.destroy()

        doldur()
        btn = ttk.Frame(ic)
        btn.pack(fill="x", pady=(10, 0))
        ttk.Button(btn, text="Kapat", command=pen.destroy).pack(side="right")
        ttk.Button(btn, text="↩  Geri Getir", style="Accent.TButton", command=geri).pack(side="right", padx=8)
        tb.bind("<Double-1>", geri)
        pen.bind("<Escape>", lambda e: pen.destroy())
        ortala(pen, self)

    def foto_goster(self):
        k = self._secili_kayit()
        if not k:
            return
        if not k.get("foto"):
            messagebox.showinfo("Bilgi", "Bu kayıtta fotoğraf yok.")
            return
        dosya_ac(os.path.join(self.depo.foto_klasoru, k["foto"]))

    def kunye_kopyala(self):
        k = self._secili_kayit(sessiz=True)
        if k:
            self.clipboard_clear()
            self.clipboard_append(k.get("kunye_no", ""))
            self.bildir("Künye no kopyalandı")

    def excel_ac(self):
        if not self.depo:
            return
        self.depo.excel_senkron()
        if os.path.exists(self.depo.excel_yol):
            dosya_ac(self.depo.excel_yol)
        else:
            messagebox.showinfo("Bilgi", "Excel dosyası henüz oluşturulamadı.\n" + (self.depo.excel_hata or ""))

    def eslestirme_listesi_yukle(self):
        """Künyelerin aranacağı dış Excel listesini seçer (işleme 'İşaretli Excel'i Ver' ile yapılır)."""
        yol = filedialog.askopenfilename(
            parent=self, title="Künyelerin aranacağı Excel listesini seçin",
            filetypes=[("Excel / CSV listesi", "*.xlsx *.xlsm *.xls *.csv *.txt"), ("Tüm dosyalar", "*.*")])
        if not yol:
            return
        try:
            try:
                liste_on_kontrol(yol)
            except XlrdYok as e:
                if not messagebox.askyesno("Liste Yükle", str(e) + "\n\nŞimdi otomatik kurulsun mu? (internet gerekir)", parent=self):
                    return
                self.bildir("xlrd kuruluyor… lütfen bekleyin", "turuncu", 60000)
                self.update_idletasks()
                ok, acik = xlrd_kur()
                if not ok:
                    messagebox.showerror("Liste Yükle", "Kurulamadı:\n" + acik, parent=self)
                    return
                liste_on_kontrol(yol)
        except Exception as e:
            messagebox.showerror("Liste Yükle", str(e), parent=self)
            return
        if not self.depo:
            return

        def is_(ilr):
            kume = liste_kunyeleri_oku(yol, ilr)
            ilr("Kaydediliyor…")
            self.depo.liste_ayarla(os.path.basename(yol), yol, kume)
            return len(kume)

        def bitince(n, hata):
            if hata:
                messagebox.showerror("Liste Yükle", hata, parent=self)
                return
            self.eslestirme_girdi = yol
            self.tabloyu_yenile()
            _y, esl, kunyeli, ad, _n = self.depo.liste_ozeti()
            self.bildir(f"Liste yüklendi: {esl} / {kunyeli} kayıt eşleşti")
            messagebox.showinfo(
                "Liste Yükle",
                f"Liste yüklendi: {ad}\nListedeki künye sayısı: {n}\n\n"
                f"Sunucudaki {kunyeli} künyeli kaydın {esl} tanesi listede bulundu.\n"
                "Tabloda yeşil satır olarak, programın kendi Excel'inde (Sayim.xlsx) yeşil künye hücresi olarak görünür; "
                "yeni gelen kayıtlar da otomatik denetlenir.\n\n"
                "Listenin kendisini yeşile boyayıp ayrı bir dosya almak için “İşaretli Excel'i Ver”e basın.", parent=self)

        pencereli_calistir(self, "Liste okunuyor", is_, bitince)

    def kunye_eslestir(self):
        """Yüklenen listede sunucudaki künyeleri bulur, bulunanları yeşile boyayıp yeni Excel olarak kaydeder."""
        if not self.depo:
            return
        kayitlar = self.depo.liste()
        if not any(kunye_norm(k.get("kunye_no")) for k in kayitlar):
            messagebox.showinfo("Künye Eşleştir", "Sunucuda künye numaralı kayıt yok.")
            return
        girdi = getattr(self, "eslestirme_girdi", "")
        if not girdi or not os.path.exists(girdi):
            messagebox.showinfo("Künye Eşleştir", "Önce “Liste Yükle” ile Excel listesini seçin.", parent=self)
            return
        ad, _uz = os.path.splitext(os.path.basename(girdi))
        cikti = filedialog.asksaveasfilename(
            parent=self, title="İşaretlenmiş Excel'i nereye kaydedelim?", defaultextension=".xlsx",
            initialdir=os.path.dirname(girdi), initialfile=f"{ad}_isaretli.xlsx",
            filetypes=[("Excel çalışma kitabı", "*.xlsx *.xlsm")])
        if not cikti:
            return

        def bitince(sonuc, hata):
            if hata:
                messagebox.showerror("Künye Eşleştir", hata, parent=self)
            else:
                self._eslestirme_sonucu(sonuc)

        pencereli_calistir(self, "Künye eşleştiriliyor",
                           lambda ilr: excel_kunye_isaretle(girdi, cikti, kayitlar, ilerleme=ilr), bitince)

    def _eslestirme_sonucu(self, s):
        yok = len(s["bulunamayan"])
        metin = (f"Sunucudaki künye sayısı: {s['sayim_kunye']}\n"
                 f"Excel listesinde bulunup yeşile boyanan: {s['eslesen']}\n"
                 f"Listede bulunamayan: {yok}"
                 + ("  (yeni “Listede Bulunamayan” sayfasında)" if yok else "") + "\n\n"
                 f"Kaydedildi:\n{s['cikti']}\n\nDosya açılsın mı?")
        if s.get("kaymis"):
            metin = (f"Not: {s['kaymis']} satırda sütunlar kaymıştı (ör. alanda “;” var); künye sağdaki hücrede bulunup boyandı.\n\n") + metin
        if s["isaretlenen"] > s["eslesen"]:
            metin = (f"Not: Listede bazı künyeler birden fazla satırda var ({s['isaretlenen']} hücre boyandı).\n\n") + metin
        self.bildir(f"{s['eslesen']} künye eşleşti ve yeşile boyandı")
        if messagebox.askyesno("Künye Eşleştir", metin, parent=self):
            dosya_ac(s["cikti"])

    def csv_aktar(self):
        if not self.depo or not self.depo.sayi():
            messagebox.showinfo("Bilgi", "Dışa aktarılacak kayıt yok.")
            return
        yol = filedialog.asksaveasfilename(
            parent=self, defaultextension=".csv", initialfile=f"Sayim_{datetime.now():%Y%m%d_%H%M}.csv",
            filetypes=[("CSV dosyası (Excel'de açılır)", "*.csv")])
        if not yol:
            return
        try:
            self.depo.csv_yaz(yol)
            self.bildir(f"CSV kaydedildi: {os.path.basename(yol)}")
        except Exception as e:
            log.exception("CSV hatası")
            messagebox.showerror("Hata", f"CSV yazılamadı:\n{e}")

    def yedek_al(self):
        if not self.depo:
            return
        try:
            klasor = self.depo.yedek_al()
        except Exception as e:
            messagebox.showwarning("Yedek", str(e))
            return
        self.bildir("Yedek alındı")
        if messagebox.askyesno("Yedek alındı", "Kayıtlar ve Excel yedeklendi.\n\nYedek klasörü açılsın mı?"):
            dosya_ac(klasor)

    def foto_klasoru_ac(self):
        if self.depo:
            dosya_ac(self.depo.foto_klasoru)

    def veri_klasoru_ac(self):
        if self.depo:
            dosya_ac(self.depo.klasor)

    def kopyala(self):
        if self.var_adres.get():
            self.clipboard_clear()
            self.clipboard_append(self.var_adres.get())
            self.bildir("Adres kopyalandı")

    def pin_kopyala(self):
        self.clipboard_clear()
        self.clipboard_append(str(self.ayar["pin"]))
        self.bildir("PIN kopyalandı")

    def tarayicida_ac(self):
        if self.var_adres.get():
            webbrowser.open(self.var_adres.get())

    # -- ayarlar --------------------------------------------------------------
    # -- tünel aracı (cloudflared) --------------------------------------------
    def tunel_araci_penceresi(self):
        pen = tk.Toplevel(self)
        pen.title("Tünel Aracı (cloudflared)")
        pen.configure(bg=RENK["bg"])
        pen.transient(self)
        pen.resizable(False, False)
        ic = ttk.Frame(pen, padding=16)
        ic.pack(fill="both", expand=True)
        KAYNAK_ADI = {"ozel": "Sizin seçtiğiniz dosya", "gomulu": "Gömülü sürüm (programın içinde)",
                      "klasor": "Program klasöründeki cloudflared.exe", "sistem": "Sistemde (PATH) bulunan cloudflared",
                      "": "Bulunamadı"}
        v_kaynak = tk.StringVar(value="…")
        v_yol = tk.StringVar(value="")
        v_surum = tk.StringVar(value="denetleniyor…")
        v_not = tk.StringVar(value="")
        v_uyari = tk.StringVar(value="")

        kul = ttk.LabelFrame(ic, text="ŞU AN KULLANILAN", padding=12)
        kul.pack(fill="x")
        ttk.Label(kul, text="Kaynak").grid(row=0, column=0, sticky="w", pady=3)
        ttk.Label(kul, textvariable=v_kaynak, font=(self.font_ad, 10, "bold")).grid(row=0, column=1, sticky="w", padx=8)
        ttk.Label(kul, text="Sürüm").grid(row=1, column=0, sticky="w", pady=3)
        ttk.Label(kul, textvariable=v_surum).grid(row=1, column=1, sticky="w", padx=8)
        ttk.Label(kul, text="Dosya").grid(row=2, column=0, sticky="w", pady=3)
        ttk.Entry(kul, textvariable=v_yol, width=62, state="readonly").grid(row=2, column=1, padx=8, sticky="w")
        ttk.Label(kul, textvariable=v_uyari, foreground=RENK["turuncu"], wraplength=int(600 * self.olcek),
                  justify="left").grid(row=3, column=0, columnspan=2, sticky="w", pady=(6, 0))

        def durumu_yukle():
            """Kullanılan dosyayı bulur ve sürümünü arka planda sorar (pencere donmasın)."""
            v_surum.set("denetleniyor…")
            def is_():
                try:
                    yol, kaynak = Tunel.exe_bul_ayrinti([BASE_DIR, self.ayar["kayit_klasoru"]], self.ayar)
                except Exception as e:
                    yol, kaynak = None, ""
                    hata = str(e)
                else:
                    hata = ""
                surum, ayrinti = (None, hata or "dosya yok")
                if yol:
                    surum, ayrinti = cloudflared_surum(yol)
                def goster():
                    try:
                        v_kaynak.set(KAYNAK_ADI.get(kaynak, kaynak))
                        v_yol.set(yol or "")
                        v_surum.set(surum if surum else ("okunamadı: " + ayrinti if yol else "—"))
                        v_uyari.set(eski_surum_uyarisi(surum) if surum else "")
                    except tk.TclError:
                        pass     # pencere kapanmış
                self.after(0, goster)
            threading.Thread(target=is_, daemon=True).start()

        def tunel_calisiyor():
            return bool(self.tunel.istenen)

        def degisiklik_sonrasi(mesaj):
            durumu_yukle()
            v_not.set(mesaj)
            self.bildir(mesaj, "yesil")

        def dosya_sec():
            yol = filedialog.askopenfilename(
                parent=pen, title="cloudflared.exe dosyasını seçin",
                filetypes=[("cloudflared (exe)", "*.exe"), ("Tüm dosyalar", "*.*")])
            if not yol:
                return
            if tunel_calisiyor() and not messagebox.askyesno(
                    "Tünel çalışıyor", "Tünel şu an açık. Değiştirmek için önce durdurulacak ve adres değişecek "
                                       "(telefonlar yeni QR'ı okutmalı).\n\nDevam edilsin mi?", parent=pen):
                return
            v_surum.set("seçilen dosya denetleniyor…")
            def is_():
                hata = ""
                surum = None
                try:
                    if not os.path.isfile(yol) or os.path.getsize(yol) < 1024 * 1024:
                        hata = "Dosya çok küçük; cloudflared.exe olmayabilir."
                    else:
                        with open(yol, "rb") as f:
                            if sys.platform == "win32" and f.read(2) != b"MZ":
                                hata = "Bu bir Windows programı (.exe) değil."
                    if not hata:
                        surum, ayrinti = cloudflared_surum(yol)
                        if not surum:
                            hata = "Dosya cloudflared olarak çalışmadı: " + ayrinti
                except Exception as e:
                    hata = str(e)
                self.after(0, lambda: devam(yol, surum, hata))
            threading.Thread(target=is_, daemon=True).start()

        def devam(yol, surum, hata):
            try:
                if hata:
                    durumu_yukle()
                    messagebox.showerror("Dosya kullanılamaz", hata, parent=pen)
                    return
                if tunel_calisiyor():
                    self.durdur()
                hedef = None
                son_hata = None
                for klasor in arac_klasorleri():
                    try:
                        os.makedirs(klasor, exist_ok=True)
                        hedef = os.path.join(klasor, "cloudflared_ozel.exe")
                        if os.path.abspath(yol) != os.path.abspath(hedef):
                            shutil.copy2(yol, hedef)
                        break
                    except OSError as e:
                        son_hata = e
                        hedef = None
                if not hedef:
                    messagebox.showerror("Kopyalanamadı", f"Dosya program klasörüne kopyalanamadı:\n{son_hata}", parent=pen)
                    durumu_yukle()
                    return
                self.ayar.update(cloudflared_kaynak="ozel", cloudflared_ozel=hedef)
                ayar_kaydet(self.ayar)
                degisiklik_sonrasi(f"Tünel aracı değiştirildi (sürüm {surum}). “Sistemi Başlat” ile yeniden başlatın.")
            except tk.TclError:
                pass

        def gomuluye_don():
            if not gomulu_var():
                messagebox.showinfo("Gömülü sürüm yok", "cloudflared_gomulu.py dosyası program klasöründe bulunamadı "
                                    "(veya Windows dışındasınız).", parent=pen)
                return
            if tunel_calisiyor() and not messagebox.askyesno(
                    "Tünel çalışıyor", "Tünel şu an açık. Değiştirmek için önce durdurulacak ve adres değişecek.\n\n"
                                       "Devam edilsin mi?", parent=pen):
                return
            if tunel_calisiyor():
                self.durdur()
            self.ayar.update(cloudflared_kaynak="gomulu")
            ayar_kaydet(self.ayar)
            degisiklik_sonrasi("Gömülü tünel aracına dönüldü. “Sistemi Başlat” ile yeniden başlatın.")

        dg = ttk.LabelFrame(ic, text="DEĞİŞTİR", padding=12)
        dg.pack(fill="x", pady=(10, 0))
        ttk.Button(dg, text="📂  Dosya Seç ve Değiştir…", style="Accent.TButton", command=dosya_sec).pack(side="left")
        ttk.Button(dg, text="↩  Gömülü Sürüme Dön", command=gomuluye_don).pack(side="left", padx=8)
        ttk.Button(dg, text="⟳  Sürümü Yenile", command=durumu_yukle).pack(side="left")
        ttk.Label(dg, textvariable=v_not, foreground=RENK["yesil"], wraplength=int(520 * self.olcek),
                  justify="left").pack(side="left", padx=10)

        nd = ttk.LabelFrame(ic, text="NEREDEN ALINIR?", padding=12)
        nd.pack(fill="x", pady=(10, 0))
        ttk.Label(nd, justify="left", wraplength=int(600 * self.olcek), text=(
            "Cloudflare'in resmî GitHub sayfasından ücretsiz indirilir. Çoğu bilgisayar için 64 bit dosya doğrudur:\n"
            "    cloudflared-windows-amd64.exe   (64 bit)      cloudflared-windows-386.exe   (eski 32 bit)\n"
            "İndirdiğiniz dosyanın adı önemli değil; yukarıdaki “Dosya Seç ve Değiştir” ile seçmeniz yeter. "
            "Program dosyayı kendi klasörüne kopyalar, orijinali silseniz de sorun olmaz.")).pack(anchor="w")
        ad = ttk.Frame(nd)
        ad.pack(fill="x", pady=(8, 0))
        ttk.Button(ad, text="🌐  İndirme Sayfasını Aç", command=lambda: webbrowser.open(CF_INDIR_SAYFA)).pack(side="left")
        ttk.Button(ad, text="⭳  64 bit'i İndir", command=lambda: webbrowser.open(CF_INDIR_64)).pack(side="left", padx=8)
        ttk.Button(ad, text="⭳  32 bit'i İndir", command=lambda: webbrowser.open(CF_INDIR_32)).pack(side="left")
        adres = tk.StringVar(value=CF_INDIR_SAYFA)
        ttk.Entry(nd, textvariable=adres, state="readonly", width=70).pack(anchor="w", pady=(8, 0))

        ttk.Label(ic, justify="left", foreground=RENK["soluk"], wraplength=int(620 * self.olcek), text=(
            "Not: Tünel her yeniden başladığında trycloudflare.com adresi değişir; telefonlar yeni QR'ı okutmalıdır. "
            "Virüs programı arac klasöründeki cloudflared.exe'yi silerse program bir sonraki başlatmada yeniden çıkarır.")
                  ).pack(anchor="w", pady=(10, 0))
        ttk.Button(ic, text="Kapat", command=pen.destroy).pack(anchor="e", pady=(10, 0))
        pen.bind("<Escape>", lambda e: pen.destroy())
        durumu_yukle()
        ortala(pen, self)
        try:
            pen.wait_visibility()
            pen.grab_set()
        except tk.TclError:
            pass

    def ayarlar_penceresi(self):
        pen = tk.Toplevel(self)
        pen.title("Ayarlar")
        pen.configure(bg=RENK["bg"])
        pen.transient(self)
        pen.resizable(False, False)
        v_klasor = tk.StringVar(value=self.ayar["kayit_klasoru"])
        v_port = tk.StringVar(value=str(self.ayar["port"]))
        v_pin = tk.StringVar(value=str(self.ayar["pin"]))
        v_kul = tk.StringVar(value=self.ayar.get("kullanicilar", ""))
        v_yerel = tk.BooleanVar(value=bool(self.ayar.get("yerel_ag")))
        v_prot = tk.StringVar(value=self.ayar.get("tunel_protokol", "auto"))
        v_foto = tk.StringVar(value=FOTO_MOD_ADLARI.get(self.ayar.get("foto_modu", "sor"), FOTO_MOD_ADLARI["sor"]))
        v_oturum = tk.BooleanVar(value=False)
        v_yedek2 = tk.StringVar(value=self.ayar.get("ikinci_yedek_klasoru", ""))
        v_qr_site = tk.StringVar(value=self.ayar.get("qr_izinli_siteler", ""))
        v_qr_sablon = tk.StringVar(value=self.ayar.get("qr_sayfa_sablonu", ""))
        v_tmod = tk.StringVar(value=TUNEL_MOD_ADLARI.get(self.ayar.get("tunel_modu"), TUNEL_MOD_ADLARI["gecici"]))
        v_ttoken = tk.StringVar(value=self.ayar.get("sabit_tunel_token", ""))
        v_tadres = tk.StringVar(value=self.ayar.get("sabit_adres", ""))
        v_access = tk.BooleanVar(value=bool(self.ayar.get("access_zorunlu")))

        ic = ttk.Frame(pen, padding=16)
        ic.pack(fill="both", expand=True)

        genel = ttk.LabelFrame(ic, text="GENEL", padding=12)
        genel.pack(fill="x")
        ttk.Label(genel, text="Kayıt klasörü").grid(row=0, column=0, sticky="w", pady=5)
        ttk.Entry(genel, textvariable=v_klasor, width=52).grid(row=0, column=1, padx=8)
        ttk.Button(genel, text="Seç...", command=lambda: v_klasor.set(filedialog.askdirectory(parent=pen) or v_klasor.get())
                   ).grid(row=0, column=2)
        ttk.Label(genel, text="Port").grid(row=1, column=0, sticky="w", pady=5)
        ttk.Entry(genel, textvariable=v_port, width=10).grid(row=1, column=1, sticky="w", padx=8)
        ttk.Label(genel, text="Fotoğraf").grid(row=2, column=0, sticky="w", pady=5)
        ttk.Combobox(genel, textvariable=v_foto, values=list(FOTO_MOD_ADLARI.values()), state="readonly", width=26
                     ).grid(row=2, column=1, sticky="w", padx=8)

        ttk.Label(genel, text="İkinci yedek klasörü\n(isteğe bağlı: USB disk / ağ)").grid(row=3, column=0, sticky="w", pady=5)
        ttk.Entry(genel, textvariable=v_yedek2, width=52).grid(row=3, column=1, padx=8)
        ttk.Button(genel, text="Seç...", command=lambda: v_yedek2.set(filedialog.askdirectory(parent=pen) or v_yedek2.get())
                   ).grid(row=3, column=2)

        guv = ttk.LabelFrame(ic, text="GÜVENLİK", padding=12)
        guv.pack(fill="x", pady=(10, 0))
        ttk.Label(guv, text="Sayım PIN'i").grid(row=0, column=0, sticky="w", pady=5)
        pin_s = ttk.Frame(guv)
        pin_s.grid(row=0, column=1, sticky="w", padx=8)
        ttk.Entry(pin_s, textvariable=v_pin, width=14).pack(side="left")
        ttk.Button(pin_s, text="Rastgele üret", command=lambda: v_pin.set(str(secrets.randbelow(900000) + 100000))
                   ).pack(side="left", padx=8)
        ttk.Label(guv, text="İzinli kullanıcılar\n(virgülle; boş = herkes)").grid(row=1, column=0, sticky="w", pady=5)
        ttk.Entry(guv, textvariable=v_kul, width=52).grid(row=1, column=1, columnspan=2, padx=8, sticky="w")
        ttk.Checkbutton(guv, text="Tüm telefon oturumlarını kapat (yeni gizli anahtar üretilir)", variable=v_oturum
                        ).grid(row=2, column=0, columnspan=3, sticky="w", pady=(6, 0))

        ag = ttk.LabelFrame(ic, text="AĞ", padding=12)
        ag.pack(fill="x", pady=(10, 0))
        ttk.Checkbutton(ag, text="Aynı Wi-Fi'daki telefonlar da bilgisayarın IP adresinden bağlanabilsin",
                        variable=v_yerel).grid(row=0, column=0, columnspan=2, sticky="w")
        ttk.Label(ag, text="Tünel protokolü").grid(row=1, column=0, sticky="w", pady=(8, 0))
        ttk.Combobox(ag, textvariable=v_prot, values=["auto", "http2", "quic"], width=10, state="readonly"
                     ).grid(row=1, column=1, sticky="w", padx=8, pady=(8, 0))
        ttk.Label(ag, text="QR izinli siteler\n(virgülle; boş = herkese açık adresler)").grid(row=2, column=0, sticky="w", pady=(8, 0))
        ttk.Entry(ag, textvariable=v_qr_site, width=52).grid(row=2, column=1, padx=8, pady=(8, 0), sticky="w")
        ttk.Label(ag, text="Künye sayfası şablonu\n({kunye} künye no yerine geçer)").grid(row=3, column=0, sticky="w", pady=(8, 0))
        ttk.Entry(ag, textvariable=v_qr_sablon, width=52).grid(row=3, column=1, padx=8, pady=(8, 0), sticky="w")

        tn = ttk.LabelFrame(ic, text="TÜNEL ADRESİ", padding=12)
        tn.pack(fill="x", pady=(10, 0))
        ttk.Label(tn, text="Adres türü").grid(row=0, column=0, sticky="w")
        ttk.Combobox(tn, textvariable=v_tmod, values=list(TUNEL_MOD_ADLARI.values()), width=50, state="readonly"
                     ).grid(row=0, column=1, sticky="w", padx=8)
        ttk.Label(tn, text="Tünel anahtarı (token)").grid(row=1, column=0, sticky="w", pady=(8, 0))
        ttk.Entry(tn, textvariable=v_ttoken, width=52, show="•").grid(row=1, column=1, padx=8, pady=(8, 0), sticky="w")
        ttk.Label(tn, text="Sabit adres").grid(row=2, column=0, sticky="w", pady=(8, 0))
        ttk.Entry(tn, textvariable=v_tadres, width=52).grid(row=2, column=1, padx=8, pady=(8, 0), sticky="w")
        ttk.Checkbutton(tn, text="Cloudflare Access (e-posta ile giriş) kullanıyorum: Access'ten geçmeyen istekleri reddet",
                        variable=v_access).grid(row=3, column=0, columnspan=2, sticky="w", pady=(8, 0))
        ttk.Label(tn, text=("Sabit adres için: 1) Cloudflare Zero Trust → Networks → Tunnels → tünel oluştur (Cloudflared). "
                            "2) Panelin gösterdiği komutu (ya da içindeki eyJ… ile başlayan anahtarı) yukarıya yapıştırın. "
                            "3) Tünele “Public hostname” ekleyin: kendi alt alan adınız, Service = HTTP, URL = 127.0.0.1:PORT "
                            "(PORT = yukarıdaki port). 4) Aynı adresi “Sabit adres” kutusuna yazın. "
                            "Access için: Zero Trust → Access → Applications → aynı adresi korumaya alın; oturum süresini uzun seçin."),
                  wraplength=int(640 * self.olcek), justify="left", foreground=RENK["soluk"]
                  ).grid(row=4, column=0, columnspan=2, sticky="w", pady=(8, 0))

        def kaydet(_=None):
            try:
                port = int(v_port.get())
                if not (1024 <= port <= 65535):
                    raise ValueError
            except ValueError:
                messagebox.showwarning("Hata", "Port 1024–65535 arasında bir sayı olmalı.", parent=pen)
                return
            pin = v_pin.get().strip()
            if len(pin) < 6:
                messagebox.showwarning("Hata", "PIN en az 6 karakter olmalı (adres internetten erişilebilir).", parent=pen)
                return
            if pin != str(self.ayar["pin"]) and pin_zayif_mi(pin) and not messagebox.askyesno(
                    "Zayıf PIN", "Bu PIN tahmin edilmesi çok kolay (tekrarlayan ya da ardışık karakterler).\n"
                                 "Adres internetten erişilebilir; “Rastgele üret” düğmesi önerilir.\n\n"
                                 "Yine de bu PIN kullanılsın mı?", parent=pen):
                return
            klasor = v_klasor.get().strip()
            if not klasor:
                messagebox.showwarning("Hata", "Kayıt klasörü boş olamaz.", parent=pen)
                return
            yedek2 = v_yedek2.get().strip()
            if yedek2:
                a2, a1 = os.path.abspath(yedek2), os.path.abspath(klasor)
                if a2 == a1 or a2.startswith(a1.rstrip("\\/") + os.sep):
                    messagebox.showwarning("Hata", "İkinci yedek klasörü kayıt klasörünün içinde olamaz; amaç farklı bir diske "
                                                   "(USB, ağ) kopya almaktır.", parent=pen)
                    return
                try:
                    os.makedirs(yedek2, exist_ok=True)
                except OSError as e:
                    if not messagebox.askyesno("Klasör açılamadı", f"İkinci yedek klasörü açılamadı:\n{e}\n\n"
                                                                   "(USB disk takılı mı?) Yine de kaydedilsin mi?", parent=pen):
                        return
            sablon = v_qr_sablon.get().strip()
            if sablon and not (re.match(r"^https?://", sablon, re.I) and "{kunye}" in sablon):
                messagebox.showwarning("Hata", "Künye sayfası şablonu http:// veya https:// ile başlamalı ve {kunye} içermeli.\n"
                                               "Kullanmayacaksanız alanı boş bırakın.", parent=pen)
                return
            foto_modu = next((k for k, v in FOTO_MOD_ADLARI.items() if v == v_foto.get()), "sor")
            tmod = next((k for k, v in TUNEL_MOD_ADLARI.items() if v == v_tmod.get()), "gecici")
            ttoken, tadres = token_ayikla(v_ttoken.get()) or v_ttoken.get().strip(), sabit_adres_duzelt(v_tadres.get())
            if tmod == "sabit":
                hata_t = sabit_tunel_hatasi({"sabit_tunel_token": ttoken, "sabit_adres": tadres})
                if hata_t:
                    messagebox.showwarning("Sabit adres", hata_t, parent=pen)
                    return
            degisti_klasor = os.path.abspath(klasor) != os.path.abspath(self.ayar["kayit_klasoru"])
            calisiyordu = self.sunucu.calisiyor
            if calisiyordu:
                self.durdur()
            self.ayar.update(kayit_klasoru=klasor, port=port, pin=pin, kullanicilar=v_kul.get().strip(),
                             yerel_ag=bool(v_yerel.get()), tunel_protokol=v_prot.get(), foto_modu=foto_modu,
                             qr_izinli_siteler=v_qr_site.get().strip(), qr_sayfa_sablonu=sablon,
                             ikinci_yedek_klasoru=yedek2, tunel_modu=tmod, sabit_tunel_token=ttoken, sabit_adres=tadres,
                             access_zorunlu=bool(v_access.get()))
            if v_oturum.get():
                self.ayar["gizli_anahtar"] = secrets.token_hex(32)
            try:
                ayar_kaydet(self.ayar)
                if degisti_klasor:
                    self._depo_ac()
                if self.depo:
                    self.depo.ikinci_yedek_ayarla(yedek2)
            except Exception as e:
                messagebox.showerror("Hata", f"Ayarlar kaydedilemedi:\n{e}", parent=pen)
                return
            self._pin_goster()
            pen.destroy()
            self.bildir("Ayarlar kaydedildi")
            if calisiyordu:
                messagebox.showinfo("Bilgi", "Ayarlar kaydedildi. Sistem durduruldu; yeniden başlatın.\n"
                                             "Not: Tünel adresi her başlatmada değişir, yeni QR'ı paylaşın.")

        btn = ttk.Frame(ic)
        btn.pack(fill="x", pady=(14, 0))
        ttk.Button(btn, text="İptal", command=pen.destroy).pack(side="right")
        ttk.Button(btn, text="Kaydet", style="Accent.TButton", command=kaydet).pack(side="right", padx=8)
        pen.bind("<Escape>", lambda e: pen.destroy())
        ortala(pen, self)
        try:
            pen.wait_visibility()
            pen.grab_set()
        except tk.TclError:
            pass

    # -- kapanış --------------------------------------------------------------
    def kapat(self):
        if self.sunucu.calisiyor and not messagebox.askyesno(
                "Çıkış", "Sistem çalışıyor. Kapatırsanız telefonlar kayıt gönderemez (kayıtlar telefonlarda bekler).\n\nÇıkılsın mı?"):
            return
        try:
            self.tunel.durdur()
            self.sunucu.durdur()
            if self.depo:
                self.depo.kapat()
        finally:
            self.destroy()


# ----------------------------------------------------------------------------
if __name__ == "__main__":
    log_kur()
    dpi_ayarla()
    try:
        Uygulama().mainloop()
    except Exception as e:
        log.exception("Program hatası")
        try:
            messagebox.showerror("Beklenmeyen hata", f"{e}\n\nAyrıntı: {LOG_YOLU}")
        except Exception:
            print(e)
